

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932002111 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q95")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932002111") 
val results = spark.sql ("SELECT  t1.p_size AS t1__p_size, t2.p_comment AS t2__p_comment, t1.p_name AS t1__p_name, t1.p_container AS t1__p_container, t1.ps_comment AS t1__ps_comment, LTRIM(t2.p_type) AS LTRIM__t2__p_type, MIN(t1.ps_availqty) AS MIN__t1__ps_availqty FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey  WHERE  t2.ps_availqty <>  9376  OR t1.p_container LIKE  '%P %' GROUP BY  t1.p_size , t2.p_comment , t1.p_name , t1.p_container , t1.ps_comment ,  LTRIM(t2.p_type)  HAVING   MIN(t1.ps_availqty) in (  (  SELECT  MIN(t1.ps_availqty) AS MIN__t1__ps_availqty  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_mfgr IN  ( 'Manufacturer#1', 'Manufacturer#1', 'Manufacturer#1', 'Manufacturer#2', 'Manufacturer#2', 'Manufacturer#2', 'Manufacturer#2', 'Manufacturer#3', 'Manufacturer#3', 'Manufacturer#3', 'Manufacturer#3', 'Manufacturer#3', 'Manufacturer#4', 'Manufacturer#4', 'Manufacturer#4', 'Manufacturer#5')   AND t1.p_name NOT IN  ( 'azure green deep sienna dim', 'bisque indian royal navajo cyan', 'burlywood frosted lemon goldenrod powder', 'chartreuse rose mint powder steel', 'coral white purple navajo sienna', 'dim lawn orange sky brown', 'floral bisque steel aquamarine ivory', 'honeydew lime wheat chartreuse aquamarine', 'hot powder coral purple blue', 'lace firebrick aquamarine metallic dodger', 'lemon orchid navy cornflower steel', 'maroon white honeydew black deep', 'medium brown burnished blue burlywood', 'orchid purple blush black medium', 'papaya beige orange dark purple', 'powder sienna smoke tomato drab', 'sandy violet puff peach cornsilk', 'sienna papaya chocolate lace burlywood', 'sienna tan floral firebrick black', 'thistle snow dark puff indian', 'wheat blanched medium indian ivory')   OR t2.ps_availqty <>  9376  OR t1.p_container LIKE  '%P %'  ) ,   (  SELECT  MIN(t1.ps_availqty) AS MIN__t1__ps_availqty  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_partkey <  49110811  AND BROUND(t1.ps_supplycost, 0)  BETWEEN  661 AND 770  OR t2.ps_availqty <>  9376  OR t1.p_container LIKE  '%P %'  ) ,   (  SELECT  MIN(t1.ps_availqty) AS MIN__t1__ps_availqty  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.ps_availqty =  2080  OR t2.ps_availqty <>  9376  OR t1.p_container LIKE  '%P %'  ) ,   (  SELECT  MIN(t1.ps_availqty) AS MIN__t1__ps_availqty  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t2.l_linenumber NOT BETWEEN  1 AND 5  OR t2.ps_availqty <>  9376  OR t1.p_container LIKE  '%P %'  ) ,   (  SELECT  MIN(t1.ps_availqty) AS MIN__t1__ps_availqty  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_size <=  27  AND t2.l_suppkey NOT BETWEEN  2938949 AND 9201900  OR t2.ps_availqty <>  9376  OR t1.p_container LIKE  '%P %'  ) ,   (  SELECT  MIN(t1.ps_availqty) AS MIN__t1__ps_availqty  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t2.l_linestatus <>  'F'  AND t1.ps_partkey >  23494128  AND t2.l_shipmode NOT IN  ( 'AIR', 'FOB', 'FOB', 'MAIL', 'MAIL', 'RAIL', 'RAIL', 'RAIL', 'REG AIR', 'REG AIR', 'REG AIR', 'SHIP', 'SHIP', 'SHIP', 'TRUCK', 'TRUCK', 'TRUCK', 'TRUCK', 'TRUCK')   OR t2.ps_availqty <>  9376  OR t1.p_container LIKE  '%P %'  ) ,   (  SELECT  MIN(t1.ps_availqty) AS MIN__t1__ps_availqty  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.ps_comment IN  ( 'about the carefully ironic requests. blithely ironic packages sleep carefully quickly fina', 'brave foxes sleep quickly unusual deposits. final ideas', 'fix fluffily around the final, ironic requests. slyly special f', 'ironic packages. carefully final dinos among the furiously final requests integr', 'long the blithely bold deposits. quickly special requests haggle furiously. furiously ironic dependencies play', 'ly pending accounts. slyly pending packages kindle blithely final pinto beans. furiously bold deposits wake final epitaphs. pending, final decoys aft', 'ously special pains haggle against the furiously ironic requests. furiously regular foxes cajole. blithely express deposits nag. final ideas use foxes. furiously regular courts need to wake f', 'quests. slyly ironic gifts boost. slyly ironic packages are slyly after the special, express accounts. slyly expr', 'sly pains. even accounts along the regular, ironic multipliers wake fluffily against the ironic requests. carefully final packages sleep slyly at the pending, final instructions. carefully', 'tegrate against the final packages. packages play fu', 'the slyly final ideas. slyly regular instructions according to the blithely special packages eat above the slyly regu', 'yly along the blithely ironic excuses. quickly unusual platelets use slyly ironic deposits. fluffily silent deposits can haggle furiously carefully pending platelets. pend')   AND t2.p_mfgr NOT LIKE  'Manufactu%'  OR t2.ps_availqty <>  9376  OR t1.p_container LIKE  '%P %'  ) ,   (  SELECT  MIN(t1.ps_availqty) AS MIN__t1__ps_availqty  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t2.p_partkey <=  49111400  AND t2.l_shipmode =  'RAIL'  OR t2.ps_availqty <>  9376  OR t1.p_container LIKE  '%P %'  ) ,   (  SELECT  MIN(t1.ps_availqty) AS MIN__t1__ps_availqty  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_brand >  'Brand#22'  AND t1.p_size BETWEEN  7 AND 37  AND t2.l_linestatus NOT BETWEEN  'F' AND 'O'  OR t2.ps_availqty <>  9376  OR t1.p_container LIKE  '%P %'  )  )")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
