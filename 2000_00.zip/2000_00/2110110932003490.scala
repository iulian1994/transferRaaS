

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932003490 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q147")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932003490") 
val results = spark.sql ("SELECT  RTRIM(nation.n_comment) AS RTRIM__nation__n_comment, LTRIM(supplier.s_comment) AS LTRIM__supplier__s_comment, supplier.s_nationkey AS supplier__s_nationkey, SUBSTR(supplier.s_name, 2, 57) AS SUBSTR__supplier__s_name__2__57, SUBSTR(supplier.s_address, 13, 75) AS SUBSTR__supplier__s_address__13__75, COUNT(lineitem.l_partkey) AS COUNT__lineitem__l_partkey, COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey, COUNT(supplier.s_suppkey) AS COUNT__supplier__s_suppkey, COUNT(LOG(4, lineitem.l_quantity)) AS COUNT__LOG__4__lineitem__l_quantity FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey GROUP BY   RTRIM(nation.n_comment) ,  LTRIM(supplier.s_comment) , supplier.s_nationkey ,  SUBSTR(supplier.s_name, 2, 57) ,  SUBSTR(supplier.s_address, 13, 75)  HAVING   COUNT(nation.n_nationkey) >=  8   or COUNT(LOG(10, lineitem.l_quantity)) in (  (  SELECT  COUNT(LOG(3, lineitem.l_quantity)) AS COUNT__LOG__3__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_suppkey <>  13859678  ) ,   (  SELECT  COUNT(LOG(2, lineitem.l_quantity)) AS COUNT__LOG__2__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_shipmode =  'MAIL'  AND nation.n_nationkey NOT IN  ( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24)   ) ,   (  SELECT  COUNT(LOG(3, lineitem.l_quantity)) AS COUNT__LOG__3__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE supplier.s_address <=  'fsm650GcK6ynJDkt5yDiCA4'  AND lineitem.l_orderkey <>  105720194  AND lineitem.l_extendedprice BETWEEN  3163.68 AND 50789.54  ) ,   (  SELECT  COUNT(LOG(3, lineitem.l_quantity)) AS COUNT__LOG__3__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE supplier.s_phone =  '10-809-737-1816'  AND nation.n_regionkey NOT BETWEEN  3 AND 4  ) ,   (  SELECT  COUNT(LOG(10, lineitem.l_quantity)) AS COUNT__LOG__10__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_returnflag <>  'R'  ) ,   (  SELECT  COUNT(LOG(2, lineitem.l_quantity)) AS COUNT__LOG__2__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_orderkey <>  105722694  AND lineitem.l_shipinstruct >=  'DELIVER IN PERSON'  ) ,   (  SELECT  COUNT(LOG(4, lineitem.l_quantity)) AS COUNT__LOG__4__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE ROUND(lineitem.l_tax, 2)  <=  0.06  ) ,   (  SELECT  COUNT(LOG(6, lineitem.l_quantity)) AS COUNT__LOG__6__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE SQRT(lineitem.l_partkey)  <=  8994.56958392118  AND lineitem.l_returnflag >=  'R'  ) ,   (  SELECT  COUNT(LOG(10, lineitem.l_quantity)) AS COUNT__LOG__10__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE partsupp.ps_suppkey NOT IN  ( 3493646, 3493842, 3493850, 3493856, 3494285, 8493963, 8494002, 8494405, 8494472, 8494664, 8494822, 13493582, 13493606, 13494014, 13494072, 13494335, 13494503, 13494513, 13494606, 18493592, 18493683, 18493954, 18494162, 18494758)   ) ,   (  SELECT  COUNT(LOG(3, lineitem.l_quantity)) AS COUNT__LOG__3__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE partsupp.ps_comment <>  'e daringly. ironic, even ideas affix about the carefully ironic asymptotes. final, ironic deposits about the qui'  AND lineitem.l_comment >=  'es. packages affix fluffil'  AND supplier.s_suppkey BETWEEN  3736967 AND 3737418  ) ,   (  SELECT  COUNT(LOG(6, lineitem.l_quantity)) AS COUNT__LOG__6__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE nation.n_comment <  'ic deposits are blithely about the carefully regular pa'  AND lineitem.l_quantity >  46  AND partsupp.ps_availqty IN  ( 2394, 2837, 5886, 7772)   ) ,   (  SELECT  COUNT(LOG(5, lineitem.l_quantity)) AS COUNT__LOG__5__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE supplier.s_comment NOT IN  ( 'against the theodolites. furiously final accounts about the gifts ha', 'furiously ironic, bold accounts. final, regular packages impress fu', 'use quickly above the blithely bold foxes. furiously unusual accounts are quickly. f', 'y unusual deposits cajole furiously alongside of the blithely unusual theodolites. quic')   ) ,   (  SELECT  COUNT(LOG(6, lineitem.l_quantity)) AS COUNT__LOG__6__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE partsupp.ps_comment IN  ( 'accounts. regular requests are quickly blithe dependencies. furiously pendin', 'long the blithely special requests. deposits cajole slyly against the blithely express excuses. qu', 'ular foxes wake slyly ironic instructions. furiously')   ) ,   (  SELECT  COUNT(LOG(9, lineitem.l_quantity)) AS COUNT__LOG__9__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_orderkey >  105720295  ) ,   (  SELECT  COUNT(LOG(3, lineitem.l_quantity)) AS COUNT__LOG__3__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE nation.n_regionkey BETWEEN  2 AND 4  AND lineitem.l_comment IN  ( '. furiously even in', 'al accounts aff', 'arefully final fo', 'carefully bold deposits. quickl', 'dependencies are.', 'deposits above t', 'egrate blithely against the', 'even pinto beans. fluffily express accou', 'final packages cajole furiously. car', 'iously ironic or', 'long the final foxes. even p', 'ly. fluffily special deposits a', 't the bold theodolites poac', 'unusual packages are b', 'uriously regular packages wake furiously')   ) ,   (  SELECT  COUNT(LOG(8, lineitem.l_quantity)) AS COUNT__LOG__8__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE partsupp.ps_partkey <=  23494358  AND lineitem.l_discount =  0.03  AND nation.n_nationkey =  13  ) ,   (  SELECT  COUNT(LOG(2, lineitem.l_quantity)) AS COUNT__LOG__2__lineitem__l_quantity  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE supplier.s_comment >  'odolites use sometimes. furiously unusual requests wake carefully about the'  )  )  or COUNT(lineitem.l_partkey) between  2 AND 6  ORDER BY  6 ASC, 3 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
