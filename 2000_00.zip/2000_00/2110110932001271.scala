

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932001271 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q51")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932001271") 
val results = spark.sql ("SELECT  LOWER(t2.ps_comment) AS LOWER__t2__ps_comment, t1.l_partkey AS t1__l_partkey, t1.l_returnflag AS t1__l_returnflag, MIN(t1.l_orderkey) AS MIN__t1__l_orderkey, SUM(t1.l_discount) AS SUM__t1__l_discount, SUM(t2.ps_availqty) AS SUM__t2__ps_availqty, MIN(t1.l_shipmode) AS MIN__t1__l_shipmode FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey  GROUP BY   LOWER(t2.ps_comment) , t1.l_partkey , t1.l_returnflag  HAVING   SUM(t1.l_discount) between  400000 AND 480000   or MIN(t1.l_shipmode) <=  'AIR'   and MIN(t1.l_orderkey) not in (  (  SELECT  MIN(t1.l_orderkey) AS MIN__t1__l_orderkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_suppkey <  18493802  AND LOG(5, t1.l_partkey)  BETWEEN  19.6963146584482 AND 19.7026335201282  AND t2.ps_partkey NOT BETWEEN  23493972 AND 23494140  ) ,   (  SELECT  MIN(t1.l_orderkey) AS MIN__t1__l_orderkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.l_linestatus <  'O'  ) ,   (  SELECT  MIN(t1.l_orderkey) AS MIN__t1__l_orderkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.l_linenumber NOT BETWEEN  2 AND 5  ) ,   (  SELECT  MIN(t1.l_orderkey) AS MIN__t1__l_orderkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1992  AND t1.l_partkey =  365913661  AND t1.l_orderkey >=  105720323  ) ,   (  SELECT  MIN(t1.l_orderkey) AS MIN__t1__l_orderkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE ABS(t2.ps_availqty)  BETWEEN  5524 AND 9259  AND t1.ps_supplycost NOT IN  ( 57.2, 172.69, 278.57, 310.14, 342.11, 346.04, 386.01, 613.05, 628.12, 649.41, 686.45, 702.64, 735.19, 735.96, 888.29, 898.61, 955.83)   ) ,   (  SELECT  MIN(t1.l_orderkey) AS MIN__t1__l_orderkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.l_returnflag <  'A'  AND SQRT(t1.l_linenumber)  <  2  AND t1.l_receiptdate NOT BETWEEN  DATE'1997-10-02' AND DATE'1998-04-16'  ) ,   (  SELECT  MIN(t1.l_orderkey) AS MIN__t1__l_orderkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.l_partkey <  148205256  AND t2.ps_partkey >=  23493957  AND t1.l_orderkey BETWEEN  105721568 AND 105724774  ) ,   (  SELECT  MIN(t1.l_orderkey) AS MIN__t1__l_orderkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.l_partkey =  84390798  AND t1.ps_supplycost NOT IN  ( 49.69, 76.44, 86.96, 195.58, 264.27, 272.43, 278.57, 492.21, 527.11, 620.24, 674.96, 690.49, 723.27, 793.83, 807.97, 832.44, 838.36, 954.16, 963.4)   AND t1.ps_comment NOT LIKE  '%%'  ) ,   (  SELECT  MIN(t1.l_orderkey) AS MIN__t1__l_orderkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.l_extendedprice <  79715.5  AND t2.ps_partkey <=  23493684  AND t1.l_linestatus IN  ( 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'O', 'O', 'O')   ) ,   (  SELECT  MIN(t1.l_orderkey) AS MIN__t1__l_orderkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey ) t1 FULL JOIN (SELECT * FROM  partsupp ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.l_comment >  'al instructions? furiously silent'  AND EXTRACT (DOW FROM t1.l_shipdate)  >=  6  )  ) ORDER BY  5 DESC, 3 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
