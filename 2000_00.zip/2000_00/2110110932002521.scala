

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932002521 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q104")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932002521") 
val results = spark.sql ("SELECT  t1.p_size AS t1__p_size, t1.p_brand AS t1__p_brand, t1.p_type AS t1__p_type, t2.ps_comment AS t2__ps_comment, MAX(ABS(t2.ps_availqty)) AS MAX__ABS__t2__ps_availqty FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey  WHERE  t1.ps_suppkey BETWEEN  8493684 AND 13493576  OR EXTRACT (DAY FROM t2.l_shipdate)  =  11  OR t1.p_name IN  ( 'aquamarine red midnight tan cornflower', 'beige firebrick puff sandy peach', 'bisque goldenrod green almond navajo', 'blanched dim rosy lawn snow', 'chiffon azure green gainsboro sienna', 'deep lawn coral medium goldenrod', 'dodger navajo moccasin brown lemon', 'hot white sky orange green', 'khaki aquamarine lace dark sienna', 'medium chocolate midnight blanched burlywood', 'metallic hot gainsboro chocolate tan', 'metallic purple magenta rosy plum', 'mint brown purple white seashell', 'peach dodger indian orange maroon', 'tan spring khaki ivory pale', 'thistle snow dark puff indian', 'yellow pink violet papaya forest')   OR t2.l_extendedprice IN  ( 23171.5, 23619.06, 28365.67, 31923.4, 36546.24, 37807.11, 38228.05, 49667.14, 63773.94, 68748.5)   OR t2.ps_comment IN  ( '. carefully pending deposits against the packages sleep carefully through the furiously spec', '. carefully quick deposits doubt above the theodolites. final deposits boost slyly furiously regular dep', 'accounts use slyly: carefully express hockey players detect furiously. deposits boost along the regular dependencies. slyly regular pinto beans was never across the deposits. carefully i', 'aggle after the deposits. slyly regular ideas against the even theodolites wake quickly across the unusu', 'al instructions. carefully pending packages sleep carefully. blithely regular waters hinder furiously according to the blithely ironic theodolites', 'boost blithely along the ironic, special requests. bold asymptotes wake furiously about the instructions. even deposits so', 'ctions sleep slyly silent patterns. thinly express platelets through the furiously express pearls nag quickly express reques', 'de of the furiously pending courts. furiously special accounts along the packages x-ray alongside of the final deposits. slyly', 'dependencies. close theodolites according to the bold tithes are slyly dolphins! furiously', 'es sleep according to the unusual ideas. furiously even asymptotes cajole after the unusual, even packages.', 'express asymptotes. even packages haggle permanently regular accounts. sl', 'fix blithely. slyly ironic packages wake blithely. even instructions use. fluffily pending courts after the carefully regular excuses', 'heodolites cajole ironic packages. unusual requests haggle sauternes. final, express accounts wake against the carefully regular somas! fluff', 'ipliers. bold, final instructions poach. slyly ironic foxes eat: deposits boost carefully after the even instructions. carefully final packages wake quickly quickly final requests. stealthil', 'ironic deposits boost furiously along the slyly regular theodolites. doggedly regular ideas sleep. silent, ironic ideas alongside of the blithely final accounts haggle b', 'ironic deposits. fluffily regular packages integrate q', 'nal packages nag along the furiously bold packages. slyly regular packages cajole accounts. fluffily regular asymptotes impress among the furiousl', 'nding asymptotes wake. foxes use blithely sly, spe', 'ng deposits cajole quickly final, ironic foxes. regular pinto beans haggle blithely. busily special deposi', 'odolites detect alongside of the slyly regular foxes. blithely bold packages are carefully enticingly bold pinto beans. carefully final pinto beans impress carefully fluffily even requests.', 'pinto beans. bold, regular warhorses haggle. carefully special dinos haggle', 'regular warthogs. boldly regular requests according to the even escapades be', 's the even packages. slyly pending decoys into the slyly', 'slyly regular packages breach blithely against the express, pending excuses. silent pinto beans sleep quickly. ironic excuses above the ironic, daring accounts boost carefully according to t', 'ully pending asymptotes along the fluffy accounts sleep quickly quickly special deposits. furiously ironic theodolites nag quickly among the regular instructions. slyly re')  GROUP BY  t1.p_size , t1.p_brand , t1.p_type , t2.ps_comment  HAVING   MAX(ABS(t2.ps_availqty)) in ( 1057, 1657, 1766, 1890, 2478, 2695, 3420, 3578, 3704, 4090, 4590, 4746, 7082, 7483, 7636, 8329, 8515, 8568, 8799, 9149, 9895 ) ORDER BY  4 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
