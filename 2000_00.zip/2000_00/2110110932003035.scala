

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932003035 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q129")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932003035") 
val results = spark.sql ("SELECT  part.p_container AS part__p_container, UPPER(part.p_mfgr) AS UPPER__part__p_mfgr, COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate, COUNT(EXTRACT (MONTH FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____MONTH__FROM__lineitem__l_shipdate, COUNT(EXTRACT (DOW FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____DOW__FROM__lineitem__l_shipdate FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey GROUP BY  part.p_container ,  UPPER(part.p_mfgr)  HAVING   COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) in (  (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE lineitem.l_quantity <=  16  AND lineitem.l_linenumber >=  1  AND part.p_type NOT IN  ( 'ECONOMY BRUSHED STEEL', 'ECONOMY POLISHED TIN', 'MEDIUM ANODIZED STEEL', 'MEDIUM ANODIZED TIN', 'MEDIUM BRUSHED COPPER', 'MEDIUM BRUSHED STEEL', 'PROMO BRUSHED COPPER', 'SMALL PLATED STEEL', 'SMALL PLATED TIN', 'STANDARD ANODIZED BRASS')   ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE lineitem.l_quantity <>  3  AND part.p_partkey <>  49111284  AND lineitem.l_tax BETWEEN  0.04 AND 0.06  ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE lineitem.l_linestatus NOT BETWEEN  'F' AND 'O'  ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_type NOT IN  ( 'ECONOMY ANODIZED NICKEL', 'ECONOMY BRUSHED BRASS', 'ECONOMY BRUSHED STEEL', 'ECONOMY BURNISHED COPPER', 'LARGE ANODIZED STEEL', 'LARGE BRUSHED NICKEL', 'MEDIUM BRUSHED STEEL', 'MEDIUM BURNISHED COPPER', 'MEDIUM POLISHED COPPER', 'PROMO BURNISHED STEEL', 'PROMO PLATED STEEL', 'SMALL ANODIZED COPPER', 'SMALL PLATED TIN', 'SMALL POLISHED BRASS')   ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE lineitem.l_shipinstruct <  'NONE'  AND EXTRACT (DAY FROM lineitem.l_receiptdate)  <=  23  AND part.p_retailprice >  1751.29  ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE lineitem.l_linenumber BETWEEN  3 AND 4  AND partsupp.ps_comment IN  ( 'are excuses. final packages cajole? ironic packages along the slyly final theodolites sleep quickly quickly e', 'cajole blithely final platelets. ironic packages among the deposits sleep slyly according to the busily regular packages. sentiments was. furiously fluffy pinto beans th', 'ckages cajole furiously fluffily ironic dependencies. regular, express foxes detect blithely regular, regular accounts. fluffily regular platelets cajole furiou', 'deposits wake slyly even packages. furiously final dependencies along the quickly bold accounts wake blithely furiously unusual accounts. furiously regular ideas nag blith', 'hrough the ironic dependencies. carefully unusual accounts according t', 'ly above the theodolites. special accounts engage carefully blithely silent packages. carefully even accounts against the p', 'ly express deposits wake across the ironic foxes. blithely final accounts cajole quickly for the blithely pending instructions. blithely pending accounts', 'ns sleep against the fluffily special dependencies. ironic deposits according to the blithely special', 'onic instructions across the furiously regular platelets boost after the carefully ironic packages. furiously even foxes haggle quickly blit', 'riously across the carefully pending accounts. fluffily unusual foxes nod carefully. fluffil', 'riously ironic asymptotes cajole blithely pending packages. slyly ironic theodolites', 'ses. fluffily even foxes about the final instructions u', 'ular courts. packages detect about the furiously even pinto beans. carefully pending theodolites poach. quickly regular instr')   ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_container <>  'MED JAR'  AND lineitem.l_partkey >=  96309191  ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE partsupp.ps_partkey =  23493726  AND lineitem.l_orderkey NOT BETWEEN  105722502 AND 105724003  AND lineitem.l_comment NOT LIKE  '%c%'  ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_type >=  'STANDARD POLISHED BRASS'  ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE FLOOR(lineitem.l_discount)  <>  0  ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE lineitem.l_linestatus <  'F'  AND part.p_type >=  'SMALL POLISHED NICKEL'  AND part.p_name NOT BETWEEN  'gainsboro aquamarine lace papaya midnight' AND 'violet peach orchid turquoise saddle'  ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE lineitem.l_shipinstruct IN  ( 'COLLECT COD', 'COLLECT COD', 'COLLECT COD', 'COLLECT COD', 'DELIVER IN PERSON', 'DELIVER IN PERSON', 'DELIVER IN PERSON', 'DELIVER IN PERSON', 'DELIVER IN PERSON', 'DELIVER IN PERSON', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', 'TAKE BACK RETURN', 'TAKE BACK RETURN', 'TAKE BACK RETURN', 'TAKE BACK RETURN', 'TAKE BACK RETURN', 'TAKE BACK RETURN')   AND SQRT(partsupp.ps_partkey)  IN  ( 4847.06034623049, 4847.06220302566, 4847.06725763115, 4847.07478795201, 4847.07901730516, 4847.10511542715, 4847.11223307239, 4847.12110432574)   ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE EXTRACT (DAY FROM lineitem.l_commitdate)  >  2  AND lineitem.l_tax IN  ( 0, 0, 0, 0.01, 0.01, 0.02, 0.02, 0.03, 0.03, 0.03, 0.04, 0.04, 0.05, 0.05, 0.06, 0.06, 0.07, 0.07, 0.08, 0.08)   AND partsupp.ps_availqty NOT BETWEEN  3283 AND 4541  ) ,   (  SELECT  COUNT(EXTRACT (YEAR FROM lineitem.l_shipdate)) AS COUNT__EXTRACT____YEAR__FROM__lineitem__l_shipdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE lineitem.l_partkey <=  347491021  AND part.p_mfgr NOT IN  ( 'Manufacturer#1', 'Manufacturer#1', 'Manufacturer#2', 'Manufacturer#2', 'Manufacturer#2', 'Manufacturer#2', 'Manufacturer#2', 'Manufacturer#2', 'Manufacturer#2', 'Manufacturer#2', 'Manufacturer#3', 'Manufacturer#3', 'Manufacturer#3', 'Manufacturer#3', 'Manufacturer#4', 'Manufacturer#4', 'Manufacturer#4', 'Manufacturer#4', 'Manufacturer#4', 'Manufacturer#4', 'Manufacturer#5', 'Manufacturer#5', 'Manufacturer#5', 'Manufacturer#5')   )  )  or COUNT(EXTRACT (DOW FROM lineitem.l_shipdate)) not between  4 AND 6 ")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
