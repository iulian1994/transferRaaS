

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2111060805003754 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q160")
spark.sparkContext.setLocalProperty("callSite.long", "Query2111060805003754") 
val results = spark.sql ("SELECT  LOWER(t2.r_comment) AS LOWER__t2__r_comment, SUBSTR(t2.n_comment, 7, 127) AS SUBSTR__t2__n_comment__7__127, UPPER(t2.n_name) AS UPPER__t2__n_name, COUNT(DISTINCT UPPER(t2.c_address)) AS COUNT__DISTINCT__UPPER__t2__c_address, COUNT(t2.o_totalprice) AS COUNT__t2__o_totalprice, COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment, COUNT(DISTINCT t2.l_returnflag) AS COUNT__DISTINCT__t2__l_returnflag FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey  WHERE  t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE' GROUP BY   LOWER(t2.r_comment) ,  SUBSTR(t2.n_comment, 7, 127) ,  UPPER(t2.n_name)  HAVING   COUNT(DISTINCT t2.c_mktsegment) not in (  (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.l_partkey <  66434320  OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t1.c_comment <=  'y bold accounts unwind permanently.'  AND t2.l_extendedprice NOT IN  ( 1087.66, 1872.26, 3971.36, 5291.55, 12554.63, 19308.41, 21510.09, 22181.04, 24076.05, 24766, 27872.1, 48527.04, 50448.47, 55253.28, 58467.42, 58536.15, 63675.05, 67498.56, 87374.24)   AND t2.l_linenumber NOT IN  ( 5, 6)   OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.o_orderdate >  DATE'1995-08-16'  OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.l_quantity <  50  AND t1.c_custkey IN  ( 12271314, 12271759, 12271779, 12272149, 12272673, 12272806, 12273380, 12273923, 12274241, 12274367, 12275282, 12275349)   OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t1.c_mktsegment <=  'MACHINERY'  AND t1.o_orderstatus >  'P'  OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.o_orderkey =  381840800  OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.c_custkey =  12271766  AND t2.l_comment IN  ( '. quickly regular requests sleep', 'express deposit', 'ges haggle across the slyly even requests?', 'inal package', 'pending pa', 'reful ideas. slyly even packag', 'regular frets. slyly even courts pri', 'sly accounts. even package', 'ts. blithely regular asymptotes')   AND EXTRACT (DAY FROM t2.o_orderdate)  NOT IN  ( 2, 4, 5, 6, 7, 8, 10, 11, 13, 14, 15, 16, 17, 19, 21, 23, 24, 27)   OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.l_shipmode =  'FOB'  OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.l_extendedprice <=  67494.66  AND t2.o_orderdate =  DATE'1997-10-17'  AND t2.c_phone IN  ( '11-692-911-6368', '12-825-695-6684', '13-874-182-4273', '14-124-325-5856', '15-123-861-4036', '15-456-808-5050', '15-992-700-7077', '15-993-993-4028', '17-471-659-7506', '17-585-202-6383', '19-660-940-3938', '25-584-836-2605', '25-761-666-7783', '26-362-299-2318', '26-392-460-2131', '26-745-168-5832', '28-737-248-6127', '32-183-875-5230', '34-169-679-2018', '34-705-824-8387')   OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t1.o_orderdate NOT BETWEEN  DATE'1993-03-07' AND DATE'1998-02-02'  OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.l_linenumber <=  6  OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.l_linenumber <=  3  AND t1.o_orderkey IN  ( 381828645, 381829058, 381830055, 381831685, 381832032, 381832196, 381832548, 381833091, 381833603, 381836517, 381836708, 381836711, 381839270, 381841219, 381841730, 381841889, 381843776, 381845031)   AND EXTRACT (DAY FROM t1.o_orderdate)  NOT IN  ( 1, 3, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17, 18, 20, 22, 23, 24, 25, 26, 27, 28, 29, 30)   OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t1.c_address BETWEEN  'E9zfdS5SnJ37x4XNs1j6N' AND 'NfkpUW5XjC'  AND t2.l_linestatus NOT IN  ( 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'F', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O')   AND t2.l_shipdate NOT IN  ( DATE'1992-10-07', DATE'1993-02-14', DATE'1993-08-30', DATE'1993-09-21', DATE'1993-12-22', DATE'1994-05-21', DATE'1994-10-06', DATE'1994-11-22', DATE'1994-12-01', DATE'1995-06-29', DATE'1995-11-14', DATE'1996-01-14', DATE'1996-04-21', DATE'1996-04-28', DATE'1996-06-19', DATE'1997-10-16', DATE'1997-12-01', DATE'1998-08-08')   OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.r_comment <=  'hs use ironic, even requests. s'  AND t2.l_comment NOT BETWEEN  'requests. furio' AND 'unusual platelets about the furiously fina'  OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.n_comment BETWEEN  'c dependencies. furiously express notornis sleep slyly regular accounts. ideas sleep. depos' AND 'y above the carefully unusual theodolites. final dugouts are quickly across the furiously regular d'  AND t2.o_custkey BETWEEN  10898756 AND 143768071  AND EXTRACT (DOW FROM t1.o_orderdate)  BETWEEN  6 AND 7  OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.n_comment NOT BETWEEN  'al foxes promise slyly according to the regular accounts. bold requests alon' AND 'nic deposits boost atop the quickly final requests? quickly regula'  OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.l_shipdate >  DATE'1992-12-20'  AND t1.o_orderdate NOT IN  ( DATE'1992-03-09', DATE'1992-04-18', DATE'1992-06-05', DATE'1992-09-21', DATE'1992-10-31', DATE'1992-12-21', DATE'1993-05-08', DATE'1993-09-08', DATE'1993-09-19', DATE'1994-12-04', DATE'1995-03-17', DATE'1995-04-20', DATE'1995-06-26', DATE'1996-02-03', DATE'1996-03-05', DATE'1996-05-23', DATE'1996-06-04', DATE'1997-11-05', DATE'1998-07-23', DATE'1998-07-29')   OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.o_orderkey <>  381841414  AND t2.o_custkey IN  ( 197575, 61047955, 83160014, 87927014, 98339012, 102475151, 110914181, 127982237, 132074074)   OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  ) ,   (  SELECT  COUNT(DISTINCT t2.c_mktsegment) AS COUNT__DISTINCT__t2__c_mktsegment  FROM  (SELECT * FROM  orders orders1 RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.l_shipinstruct BETWEEN  'COLLECT COD' AND 'DELIVER IN PERSON'  AND LOG(7, t2.l_partkey)  BETWEEN  18.5627771072716 AND 18.6971356671652  AND EXTRACT (YEAR FROM t2.l_commitdate)  NOT IN  ( 1993, 1994, 1996, 1996, 1996, 1996, 1997, 1998, 1998)   OR t2.n_name <  'UNITED STATES'  OR SQRT(t1.c_nationkey)  <=  4.47213595499958  OR t2.o_orderpriority >=  '3-MEDIUM'  OR t2.c_nationkey BETWEEN  1 AND 5  OR BROUND(t2.c_acctbal, 1)  BETWEEN  6549.7 AND 9931.4  OR t2.r_regionkey IN  ( 0, 0, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4)   OR t2.r_name NOT LIKE  '%EUROPE'  )  )  or COUNT(t2.o_totalprice) =  1   and COUNT(DISTINCT t2.l_returnflag) <=  3  ORDER BY  4 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
