

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2111060805001633 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q61")
spark.sparkContext.setLocalProperty("callSite.long", "Query2111060805001633") 
val results = spark.sql ("SELECT  UPPER(t2.n_name) AS UPPER__t2__n_name, UPPER(t2.s_comment) AS UPPER__t2__s_comment, MAX(SQRT(t2.n_nationkey)) AS MAX__SQRT__t2__n_nationkey, MAX(RTRIM(t1.ps_comment)) AS MAX__RTRIM__t1__ps_comment FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey  WHERE  t1.s_phone <  '27-797-601-2294'  OR t1.s_nationkey >=  2  OR t2.ps_availqty BETWEEN  2600 AND 5159 GROUP BY   UPPER(t2.n_name) ,  UPPER(t2.s_comment)  HAVING   MAX(SQRT(t2.n_nationkey)) not in ( 1.4142135623731, 1.73205080756888, 2, 2.23606797749979, 2.44948974278318, 2.64575131106459, 3.46410161513775, 4, 4.12310562561766, 4.47213595499958, 4.58257569495584 )  and MAX(RTRIM(t1.ps_comment)) in (  (  SELECT  MAX(RTRIM(t1.ps_comment)) AS MAX__RTRIM__t1__ps_comment  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.s_phone <  '27-797-601-2294'  AND t1.s_acctbal >=  8976.69  AND t2.ps_supplycost NOT BETWEEN  147.02 AND 649.76  OR t1.s_nationkey >=  2  OR t2.ps_availqty BETWEEN  2600 AND 5159  ) ,   (  SELECT  MAX(RTRIM(t1.ps_comment)) AS MAX__RTRIM__t1__ps_comment  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.s_phone <  '27-797-601-2294'  AND ROUND(t1.s_acctbal, 1)  <  2929  AND t2.ps_comment =  'ffily ironic instructions. foxes above the special, express requests cajole f'  AND t1.s_name IN  ( 'Supplier#006533216', 'Supplier#006533679', 'Supplier#006533747', 'Supplier#006534006', 'Supplier#006534068', 'Supplier#006534496', 'Supplier#006534520', 'Supplier#006534640', 'Supplier#006534940', 'Supplier#006535059', 'Supplier#006535330', 'Supplier#006535528', 'Supplier#006535600', 'Supplier#006536048', 'Supplier#006536194', 'Supplier#006536416', 'Supplier#006536901', 'Supplier#006537205', 'Supplier#006537419', 'Supplier#006537693', 'Supplier#006537758', 'Supplier#006537775', 'Supplier#006537948')   OR t1.s_nationkey >=  2  OR t2.ps_availqty BETWEEN  2600 AND 5159  ) ,   (  SELECT  MAX(RTRIM(t1.ps_comment)) AS MAX__RTRIM__t1__ps_comment  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.s_phone <  '27-797-601-2294'  AND t2.n_comment NOT IN  ( 'c dependencies. furiously express notornis sleep slyly regular accounts. ideas sleep. depos', 'eans boost carefully special requests. accounts are. carefull', 'eas hang ironic, silent packages. slyly regular packages are furiously over the tithes. fluffily bold', 'efully alongside of the slyly final dependencies.', 'haggle. carefully final deposits detect slyly agai', 'hely enticingly express accounts. even, final', 'ic deposits are blithely about the carefully regular pa', 'l platelets. regular accounts x-ray: unusual, regular acco', 'nic deposits boost atop the quickly final requests? quickly regula', 'ously. final, express gifts cajole a', 'pending excuses haggle furiously deposits. pending, express pinto beans wake fluffily past t', 'platelets. blithely pending dependencies use fluffily across the even pinto beans. carefully silent accoun', 'refully final requests. regular, ironi', 'requests against the platelets use never according to the quickly regular pint', 'rns. blithely bold courts among the closely regular packages use furiously bold platelets?', 's. ironic, unusual asymptotes wake blithely r', 'slyly express asymptotes. regular deposits haggle slyly. carefully ironic hockey players sleep blithely. carefull', 'ts. silent requests haggle. closely express packages sleep across the blithely', 'ular asymptotes are about the furious multipliers. express dependencies nag above the ironically ironic account', 'ven packages wake quickly. regu', 'y above the carefully unusual theodolites. final dugouts are quickly across the furiously regular d', 'y alongside of the pending deposits. carefully special packages are about the ironic forges. slyly special', 'y final packages. slow foxes cajole quickly. quickly silent platelets breach ironic accounts. unusual pinto be')   OR t1.s_nationkey >=  2  OR t2.ps_availqty BETWEEN  2600 AND 5159  ) ,   (  SELECT  MAX(RTRIM(t1.ps_comment)) AS MAX__RTRIM__t1__ps_comment  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.s_phone <  '27-797-601-2294'  AND t1.s_suppkey <=  6533199  AND t1.s_comment <>  'sly final dolphins. final,'  OR t1.s_nationkey >=  2  OR t2.ps_availqty BETWEEN  2600 AND 5159  )  ) ORDER BY  4 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
