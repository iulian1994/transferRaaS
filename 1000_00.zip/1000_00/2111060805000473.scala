

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2111060805000473 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q16")
spark.sparkContext.setLocalProperty("callSite.long", "Query2111060805000473") 
val results = spark.sql ("SELECT  RTRIM(t2.r_comment) AS RTRIM__t2__r_comment, t2.n_comment AS t2__n_comment, RTRIM(t2.n_name) AS RTRIM__t2__n_name, MIN(UPPER(t1.o_orderpriority)) AS MIN__UPPER__t1__o_orderpriority, MIN(EXTRACT (MONTH FROM t1.o_orderdate)) AS MIN__EXTRACT____MONTH__FROM__t1__o_orderdate, MIN(t2.c_custkey) AS MIN__t2__c_custkey, MIN(t2.o_custkey) AS MIN__t2__o_custkey FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey  WHERE  t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)  GROUP BY   RTRIM(t2.r_comment) , t2.n_comment ,  RTRIM(t2.n_name)  HAVING   MIN(EXTRACT (MONTH FROM t1.o_orderdate)) >=   (  SELECT  MIN(EXTRACT (MONTH FROM t1.o_orderdate)) AS MIN__EXTRACT____MONTH__FROM__t1__o_orderdate  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.c_address >  'icDvrNXIOeg6MCK'  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   )    and MIN(t2.o_custkey) not in (  (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_shippriority >=  0  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE SQRT(t2.n_regionkey)  <>  0  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t2.c_address NOT IN  ( '0pvHgYIsCj8jBBsYdAjsY4N', '2oTQFx6HCG0nwJ3m5', '4XKFCe93jb', '9CXK0JF8mKTO9Zt1Ji2IquK1Q2 n', 'CDDiZZiZHfpMzrG3NZe', 'cl5EuAVWRRwPhLkvzJni,0A2lY4y6ol', 'drBAvK3PdDbC2yWSs,rNpuSOiY1hIfo1pj', 'FD3g GPDFPFIt6EkZY w', 'hZoH,Kx7iyH0GR38 YoaB,lfxLhHo4YpCjLGZd', 'Kfclj0 R2yzZB6rEdN', 'p9Uv7lgfo8p55elbd7p M7hOZ7fcl', 'pFuUO7KbzWRaZukleeohadj,KYoxcoeBsk0A', 'sZ Oj6d5OdGWKrxcns8Zvcdgrwl8UX806XZI', 'uswAtH3jG tsFpBaflpt74ZnCtkBG', 'VaPk75hqgGcaTxySoVyJqHjji62MocMbrPWjDJe4', 'VZsFQRo9xvZ6oDUrObjqPBE0', 'wb36LAsZH4BWZ2,VNhsDJEc5qXtsYaLa', 'y aQ6sCYFOudYqn2Jq0D0uID5hqvX5hKD', 'yM7L3Pos9iDx', 'ZoxKE8kzEZPVSThNbN JJjORYEg,r2H0E14NCMTa')   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t1.o_orderstatus <>  'P'  AND t2.o_orderkey <>  381828099  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t2.r_name IN  ( 'MIDDLE EAST')   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t1.o_orderdate BETWEEN  DATE'1992-01-15' AND DATE'1996-06-25'  AND t1.o_totalprice BETWEEN  101400.51 AND 291808.4  AND t2.o_comment BETWEEN  'ith the notornis. quietly final instructions sleep. even deposits integrate' AND 'ly ironic dolphins: furiously final courts n'  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND EXTRACT (DOW FROM t1.o_orderdate)  NOT BETWEEN  4 AND 6  ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.c_comment <  'olphins integrate slyly besides the even platelets. unusual th'  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t2.o_comment NOT LIKE  '%%'  ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t2.c_custkey NOT IN  ( 12271076)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.r_comment <>  'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t1.o_totalprice IN  ( 4343.77, 7372.01, 7981.84, 17334.66, 46230.75, 46447.97, 65526.74, 67697.85, 95102.83, 103802.32, 111549.39, 112511.84, 115569.54, 132038.09, 135824.1, 151298.61, 164042.45, 289584.01, 291808.4, 306075.29)   AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.r_name <  'AFRICA'  AND t1.o_shippriority >  0  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t2.c_acctbal NOT IN  ( -851.48, -676.43, -532.71, -218.59, 158.15, 497.99, 1213.46, 1340.7, 1584.17, 2136.95, 2208.45, 2440.93, 4388.32, 4487.61, 4763.95, 5544.64, 5727, 8301.75, 8978.05, 9001.55)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.c_custkey <=  12274926  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t1.o_orderstatus BETWEEN  'O' AND 'P'  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE EXTRACT (MONTH FROM t2.o_orderdate)  =  12  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t1.o_orderstatus NOT BETWEEN  'F' AND 'O'  ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_custkey <  73926460  AND t2.c_name BETWEEN  'Customer#012272621' AND 'Customer#012274276'  AND t1.o_orderkey IN  ( 381826471, 381826818, 381828389, 381828423, 381831623, 381831940, 381832386, 381832517, 381835204, 381836327, 381836422, 381843265, 381843745, 381845856)   AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_custkey >  48711073  AND t1.o_orderkey >=  381829667  AND t1.o_comment IN  ( 'as. furiously final deposits cajole slyly after', 'ckages sleep above the package', 'courts. requests believe furiously. even instructions affix unusu', 'deposits nag alongside of', 'fully ironic accounts are. blithely special requests along the carefull', 'furiously regular requests wake. furiously final foxes are', 'he foxes. final pinto beans wake. flu', 'inal instructions. slyly ironic instructions doze slyly ironic, speci', 'ing epitaphs unwind furiously furious pint', 'ithely quiet requests against the slyly silent foxes cajole', 'kages affix among the furiously ironic packages. packages nag carefull', 'lar asymptotes boost about the accounts. permanently even requests', 'ld realms wake carefully slyly even deposits. even t', 'le blithely ironic requests. regular instru', 'ly blithely ironic ideas', 'ncies. closely sly courts are fluffily. carefully final excu', 'p blithely above the carefully sile', 're slyly carefully final foxes. careful acco', 'the fluffily regular acc', 'the furiously regular accounts. quickly final packages boost furious', 'ves are. blithely ironic asymptotes cajole carefully bold account')   AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.n_comment =  'haggle. carefully final deposits detect slyly agai'  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t1.o_clerk NOT BETWEEN  'Clerk#000876920' AND 'Clerk#000933241'  AND SQRT(t2.c_custkey)  NOT BETWEEN  3503.17299030465 AND 3503.43531408816  ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.n_name <=  'JAPAN'  AND t2.o_shippriority <=  0  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t1.o_custkey NOT IN  ( 1084951, 10848377, 141312295, 142197644)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_orderkey <=  381836099  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t1.o_orderdate NOT IN  ( DATE'1992-09-07', DATE'1992-12-18', DATE'1993-02-21', DATE'1993-04-10', DATE'1993-07-02', DATE'1993-07-05', DATE'1993-09-11', DATE'1993-12-09', DATE'1994-02-03', DATE'1994-05-03', DATE'1994-08-31', DATE'1994-11-16', DATE'1994-12-06', DATE'1995-05-24', DATE'1995-09-10', DATE'1995-11-14', DATE'1996-04-30', DATE'1997-02-17', DATE'1997-10-04', DATE'1997-11-05', DATE'1997-11-23', DATE'1998-05-16')   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t1.o_shippriority <  0  AND t2.r_name <  'EUROPE'  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t2.n_name LIKE  '%RU'  ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.c_address =  'OdXmg2C7vTPJq7P1ZTX7'  AND t1.o_shippriority >=  0  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t2.o_custkey NOT BETWEEN  4397504 AND 30323098  ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.c_acctbal >  7606.24  AND t2.n_regionkey BETWEEN  1 AND 3  AND t2.o_custkey BETWEEN  76494769 AND 142811633  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_orderpriority >  '5-LOW'  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   AND t1.o_comment NOT BETWEEN  'et accounts. fluffily unusual packages cajole above the unusual, pending the' AND 'l foxes wake carefully. unusual deposits nag never bra'  ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.r_regionkey >  3  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t1.o_clerk <  'Clerk#000762394'  AND t2.n_name IN  ( 'ALGERIA', 'BRAZIL', 'CANADA', 'INDIA', 'IRAN', 'KENYA', 'PERU', 'ROMANIA', 'RUSSIA', 'SAUDI ARABIA', 'VIETNAM')   AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   ) ,   (  SELECT  MIN(t2.o_custkey) AS MIN__t2__o_custkey  FROM  (SELECT * FROM  orders ) t1 INNER JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey RIGHT JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.c_custkey BETWEEN  12272187 AND 12274864  AND t2.n_nationkey IN  ( 0, 3, 4, 6, 7, 8, 10, 11, 12, 14, 16, 19)   )  ) ORDER BY  2 ASC, 3 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
