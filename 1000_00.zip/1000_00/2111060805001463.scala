

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2111060805001463 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q54")
spark.sparkContext.setLocalProperty("callSite.long", "Query2111060805001463") 
val results = spark.sql ("SELECT  t1.p_container AS t1__p_container, t2.p_partkey AS t2__p_partkey, COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty, MIN(t2.p_name) AS MIN__t2__p_name, MIN(UPPER(t2.p_mfgr)) AS MIN__UPPER__t2__p_mfgr, COUNT(t1.p_retailprice) AS COUNT__t1__p_retailprice FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey  GROUP BY  t1.p_container , t2.p_partkey  HAVING   MIN(t2.p_name) not between  'goldenrod blush ghost forest orchid' AND 'white plum dodger burlywood violet'   or COUNT(t1.p_retailprice) <>   (  SELECT  COUNT(t1.p_retailprice) AS COUNT__t1__p_retailprice  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_size IN  ( 1, 40, 42)   AND t1.p_comment NOT BETWEEN  'carefully after' AND 'the even warthogs. b'  )    or MIN(UPPER(t2.p_mfgr)) <>  'MANUFACTURER#5'   or COUNT(ABS(t2.ps_availqty)) not in (  (  SELECT  COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_retailprice NOT BETWEEN  1302.6 AND 1731.03  ) ,   (  SELECT  COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_comment <=  'luffily'  AND t1.p_retailprice <>  1022.33  AND t2.p_size NOT BETWEEN  24 AND 37  ) ,   (  SELECT  COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t2.p_brand IN  ( 'Brand#11', 'Brand#13', 'Brand#14', 'Brand#15', 'Brand#22', 'Brand#23', 'Brand#24', 'Brand#25', 'Brand#32', 'Brand#33', 'Brand#34', 'Brand#35', 'Brand#41', 'Brand#42', 'Brand#43', 'Brand#45', 'Brand#52', 'Brand#53', 'Brand#54', 'Brand#55')   ) ,   (  SELECT  COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_retailprice <=  1218.52  AND t2.p_type <>  'STANDARD PLATED NICKEL'  AND t2.ps_supplycost NOT BETWEEN  824.12 AND 832.6  ) ,   (  SELECT  COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_comment BETWEEN  'ourts. ironic pinto' AND 'y unusual asymptotes'  ) ,   (  SELECT  COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t2.p_size <>  7  AND t2.p_name >  'sky peach black burlywood chiffon'  AND t2.p_mfgr NOT IN  ( 'Manufacturer#1', 'Manufacturer#1', 'Manufacturer#2', 'Manufacturer#3', 'Manufacturer#4', 'Manufacturer#4', 'Manufacturer#5', 'Manufacturer#5')   ) ,   (  SELECT  COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t2.p_partkey <  115429592  ) ,   (  SELECT  COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_name >  'rose deep aquamarine light rosy'  ) ,   (  SELECT  COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE FLOOR(t2.p_retailprice)  IN  ( 995, 1002, 1016, 1153, 1201, 1241, 1264, 1274, 1340, 1387, 1449, 1497, 1538, 1634, 1652, 1670, 1781, 1806, 1822)   ) ,   (  SELECT  COUNT(ABS(t2.ps_availqty)) AS COUNT__ABS__t2__ps_availqty  FROM  (SELECT * FROM  part ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t2.p_brand <>  'Brand#33'  AND t1.p_brand LIKE  'Bran%'  AND SQRT(t2.ps_availqty)  NOT IN  ( 9.4339811320566, 27.258026340878, 42.5205832509386, 58.3523778435806, 58.7281874401041, 64.2650760522385, 66.2721661031236, 80.6907677494768, 83.5164654424503, 90.8074886779719, 93.0430008114528, 93.1826164045634, 94.841973830156, 98.2802116399838)   )  )")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
