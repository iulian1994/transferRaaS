

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2111060805004510 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q185")
spark.sparkContext.setLocalProperty("callSite.long", "Query2111060805004510") 
val results = spark.sql ("SELECT  t2.c_mktsegment AS t2__c_mktsegment, LOWER(t1.s_phone) AS LOWER__t1__s_phone, EXTRACT (YEAR FROM t2.o_orderdate) AS EXTRACT____YEAR__FROM__t2__o_orderdate, t2.c_name AS t2__c_name, COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber  WHERE  t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')  GROUP BY  t2.c_mktsegment ,  LOWER(t1.s_phone) , EXTRACT (YEAR FROM t2.o_orderdate) , t2.c_name  HAVING   COUNT(t2.c_nationkey) in (  (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.c_address =  'aHl8J9eXSftSxCG OBJp8xGgunO4kJsQ8UpAV5,G'  AND t2.o_orderkey =  381839140  AND t2.l_suppkey NOT IN  ( 216734, 572098, 687055, 1702293, 3278694, 4634011, 5498258, 5710469, 8898973, 9203075, 9204530, 9316787, 9671278)   OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE SQRT(t2.l_tax)  <=  0.14142135623731  OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE EXTRACT (MONTH FROM t2.l_receiptdate)  =  4  AND t2.l_comment >=  'uickly regular deposits. special pains h'  OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.s_suppkey <=  6534140  OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.l_linenumber <=  4  OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.l_shipmode >=  'REG AIR'  AND t2.c_mktsegment NOT BETWEEN  'AUTOMOBILE' AND 'BUILDING'  AND t1.l_comment NOT LIKE  'accounts. special %'  OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.o_shippriority IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.s_nationkey >=  13  AND LOG(2, t2.c_custkey)  NOT BETWEEN  16.3228669003731 AND 16.3229905844779  OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.l_commitdate <=  DATE'1992-09-22'  OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.o_orderpriority <=  '2-HIGH'  AND t1.s_address =  'aJ8 yq4eJ,,3AL2tkQkzzdbZOn6gNcElNxwr1gF8'  AND t1.l_orderkey BETWEEN  50250113 AND 50250657  OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.s_nationkey >  18  AND t2.l_shipdate NOT IN  ( DATE'1992-03-14', DATE'1992-03-31', DATE'1992-07-07', DATE'1992-11-14', DATE'1993-09-06', DATE'1994-07-27', DATE'1994-08-08', DATE'1994-10-18', DATE'1994-11-21', DATE'1996-04-14', DATE'1996-05-26', DATE'1996-11-09', DATE'1998-04-29', DATE'1998-05-02')   OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.l_tax NOT IN  ( 0.01, 0.01, 0.02, 0.02, 0.02, 0.02, 0.03, 0.04, 0.04, 0.05, 0.05, 0.05, 0.05, 0.05, 0.06, 0.06, 0.06, 0.06, 0.07, 0.07, 0.07, 0.08, 0.08, 0.08, 0.08)   AND ROUND(t1.ps_supplycost, 3)  NOT IN  ( 51.7, 185, 209.89, 391.49, 398.13, 410.06, 527.96, 584.56, 603.28, 657.66, 682.94, 740.98, 746.01, 803.67, 834.57, 856.62, 862.19)   OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   ) ,   (  SELECT  COUNT(t2.c_nationkey) AS COUNT__t2__c_nationkey  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE SQRT(t2.c_nationkey)  >=  2.82842712474619  AND t1.ps_partkey NOT IN  ( 18355217, 18355407, 18355668, 18355899, 18355923, 18356002, 18356019, 18356230, 18356294)   OR t1.ps_comment <  'equests. special requests are fluffily: special, close dependencies boost final, even packages. furiously pending instruction'  OR t2.o_totalprice <  95102.83  OR EXTRACT (YEAR FROM t1.l_receiptdate)  <>  1993  OR t1.l_shipinstruct LIKE  '% PERSON'  OR t1.s_phone LIKE  '%20-9564'  OR t2.c_acctbal NOT BETWEEN  7940.73 AND 9001.55  OR t1.s_name NOT IN  ( 'Supplier#006533185', 'Supplier#006533604', 'Supplier#006533642', 'Supplier#006534781', 'Supplier#006535330', 'Supplier#006535399', 'Supplier#006535415', 'Supplier#006535523', 'Supplier#006535702', 'Supplier#006535792', 'Supplier#006536196', 'Supplier#006536197', 'Supplier#006536235', 'Supplier#006536485', 'Supplier#006536512', 'Supplier#006536575', 'Supplier#006536717', 'Supplier#006537037', 'Supplier#006537769', 'Supplier#006537832', 'Supplier#006537858', 'Supplier#006537871', 'Supplier#006538001', 'Supplier#006538105')   )  ) ORDER BY  1 ASC, 4 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
