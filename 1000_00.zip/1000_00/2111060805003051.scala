

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2111060805003051 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q131")
spark.sparkContext.setLocalProperty("callSite.long", "Query2111060805003051") 
val results = spark.sql ("SELECT  t1.r_comment AS t1__r_comment, LTRIM(t1.r_name) AS LTRIM__t1__r_name, t2.n_comment AS t2__n_comment, COUNT(DISTINCT t2.c_nationkey) AS COUNT__DISTINCT__t2__c_nationkey, COUNT(DISTINCT t2.c_custkey) AS COUNT__DISTINCT__t2__c_custkey, COUNT(DISTINCT RTRIM(t2.c_mktsegment)) AS COUNT__DISTINCT__RTRIM__t2__c_mktsegment, COUNT(DISTINCT t2.n_regionkey) AS COUNT__DISTINCT__t2__n_regionkey FROM  (SELECT * FROM  nation nation1 INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 LEFT JOIN (SELECT * FROM  customer customer2 INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey  WHERE  t2.n_name <=  'UNITED KINGDOM'  AND SQRT(t1.r_regionkey)  >  2  AND t1.n_nationkey >=  16  OR t2.c_nationkey >  3 GROUP BY  t1.r_comment ,  LTRIM(t1.r_name) , t2.n_comment  HAVING   COUNT(DISTINCT t2.c_custkey) >=  6   and COUNT(DISTINCT RTRIM(t2.c_mktsegment)) in ( 2, 2, 2, 3, 3, 4, 4, 4 )  and COUNT(DISTINCT t2.c_nationkey) not in (  (  SELECT  COUNT(DISTINCT t2.c_nationkey) AS COUNT__DISTINCT__t2__c_nationkey  FROM  (SELECT * FROM  nation nation1 INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 LEFT JOIN (SELECT * FROM  customer customer2 INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.n_name <=  'UNITED KINGDOM'  AND SQRT(t1.r_regionkey)  >  2  AND t1.n_nationkey >=  16  AND t2.c_address NOT LIKE  '%vK3PdDbC2yWSs,rNpuSOiY1hIfo1pj'  OR t2.c_nationkey >  3  ) ,   (  SELECT  COUNT(DISTINCT t2.c_nationkey) AS COUNT__DISTINCT__t2__c_nationkey  FROM  (SELECT * FROM  nation nation1 INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 LEFT JOIN (SELECT * FROM  customer customer2 INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.n_name <=  'UNITED KINGDOM'  AND t1.n_comment =  's. ironic, unusual asymptotes wake blithely r'  AND SQRT(t1.r_regionkey)  >  2  AND t1.n_nationkey >=  16  AND t2.c_name NOT BETWEEN  'Customer#012272537' AND 'Customer#012274308'  AND t2.n_regionkey NOT BETWEEN  1 AND 3  OR t2.c_nationkey >  3  ) ,   (  SELECT  COUNT(DISTINCT t2.c_nationkey) AS COUNT__DISTINCT__t2__c_nationkey  FROM  (SELECT * FROM  nation nation1 INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 LEFT JOIN (SELECT * FROM  customer customer2 INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.n_name <=  'UNITED KINGDOM'  AND t2.n_regionkey >  0  AND SQRT(t1.r_regionkey)  >  2  AND t1.n_nationkey >=  16  AND t2.c_acctbal NOT BETWEEN  3431.47 AND 8733.09  AND t1.n_comment NOT LIKE  'ven packages wake quickly.%'  OR t2.c_nationkey >  3  ) ,   (  SELECT  COUNT(DISTINCT t2.c_nationkey) AS COUNT__DISTINCT__t2__c_nationkey  FROM  (SELECT * FROM  nation nation1 INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 LEFT JOIN (SELECT * FROM  customer customer2 INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE SQRT(t2.n_nationkey)  <  3  AND t1.n_name <=  'GERMANY'  AND t2.n_name <=  'UNITED KINGDOM'  AND SQRT(t1.r_regionkey)  >  2  AND t1.n_nationkey >=  16  AND t2.c_mktsegment >=  'FURNITURE'  OR t2.c_nationkey >  3  ) ,   (  SELECT  COUNT(DISTINCT t2.c_nationkey) AS COUNT__DISTINCT__t2__c_nationkey  FROM  (SELECT * FROM  nation nation1 INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 LEFT JOIN (SELECT * FROM  customer customer2 INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.n_name <=  'UNITED KINGDOM'  AND t2.c_acctbal =  7040.57  AND SQRT(t1.r_regionkey)  >  2  AND t1.n_nationkey >=  16  AND t2.c_name NOT IN  ( 'Customer#012271223', 'Customer#012271828', 'Customer#012271849', 'Customer#012271974', 'Customer#012272246', 'Customer#012272875', 'Customer#012272929', 'Customer#012273061', 'Customer#012273133', 'Customer#012273175', 'Customer#012273392', 'Customer#012273638', 'Customer#012273830', 'Customer#012273901', 'Customer#012274009', 'Customer#012274020', 'Customer#012274122', 'Customer#012274174', 'Customer#012274251', 'Customer#012274332', 'Customer#012274763', 'Customer#012274859', 'Customer#012275335', 'Customer#012275674', 'Customer#012275732')   OR t2.c_nationkey >  3  ) ,   (  SELECT  COUNT(DISTINCT t2.c_nationkey) AS COUNT__DISTINCT__t2__c_nationkey  FROM  (SELECT * FROM  nation nation1 INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 LEFT JOIN (SELECT * FROM  customer customer2 INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.n_name <=  'UNITED KINGDOM'  AND t1.n_name =  'CANADA'  AND SQRT(t1.r_regionkey)  >  2  AND t1.n_nationkey >=  16  AND t2.n_regionkey >=  1  AND t2.n_nationkey NOT IN  ( 7, 8, 10, 11, 15, 16, 17, 19, 22, 23, 24)   OR t2.c_nationkey >  3  ) ,   (  SELECT  COUNT(DISTINCT t2.c_nationkey) AS COUNT__DISTINCT__t2__c_nationkey  FROM  (SELECT * FROM  nation nation1 INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 LEFT JOIN (SELECT * FROM  customer customer2 INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.c_address <  'frzOfht3sGcMUfkgEwbshvKEilc'  AND t2.n_regionkey <  0  AND t2.n_name <=  'UNITED KINGDOM'  AND SQRT(t1.r_regionkey)  >  2  AND t1.n_nationkey >=  16  OR t2.c_nationkey >  3  ) ,   (  SELECT  COUNT(DISTINCT t2.c_nationkey) AS COUNT__DISTINCT__t2__c_nationkey  FROM  (SELECT * FROM  nation nation1 INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 LEFT JOIN (SELECT * FROM  customer customer2 INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.n_name <=  'UNITED KINGDOM'  AND t1.n_comment >  'eas hang ironic, silent packages. slyly regular packages are furiously over the tithes. fluffily bold'  AND SQRT(t1.r_regionkey)  >  2  AND t1.n_nationkey >=  16  AND t1.r_comment LIKE  '%inly even pinto beans ca'  OR t2.c_nationkey >  3  ) ,   (  SELECT  COUNT(DISTINCT t2.c_nationkey) AS COUNT__DISTINCT__t2__c_nationkey  FROM  (SELECT * FROM  nation nation1 INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 LEFT JOIN (SELECT * FROM  customer customer2 INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.r_comment <=  'ges. thinly even pinto beans ca'  AND t2.n_name <=  'UNITED KINGDOM'  AND t2.c_address <>  'EiRh0Y6l8fWojvkphNsDD8Nlv5VOwh'  AND t2.n_comment =  'ular asymptotes are about the furious multipliers. express dependencies nag above the ironically ironic account'  AND SQRT(t1.r_regionkey)  >  2  AND t1.n_nationkey >=  16  OR t2.c_nationkey >  3  )  )")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
