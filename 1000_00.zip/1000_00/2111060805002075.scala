

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2111060805002075 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q85")
spark.sparkContext.setLocalProperty("callSite.long", "Query2111060805002075") 
val results = spark.sql ("SELECT  nation.n_regionkey AS nation__n_regionkey, customer.c_name AS customer__c_name, SUBSTR(customer.c_comment, 15, 24) AS SUBSTR__customer__c_comment__15__24, COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey WHERE  orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED' GROUP BY  nation.n_regionkey , customer.c_name ,  SUBSTR(customer.c_comment, 15, 24)  HAVING   COUNT(DISTINCT RTRIM(orders.o_clerk)) in (  (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE SQRT(nation.n_regionkey)  =  1  AND orders.o_orderstatus >=  'F'  AND customer.c_comment LIKE  '%equests%'  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_custkey <=  12271789  AND BROUND(customer.c_acctbal, 3)  >  4314.95  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  AND customer.c_nationkey NOT IN  ( 1, 6, 7, 8, 12, 14, 18, 20, 22, 23)   ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_custkey >=  12274468  AND orders.o_shippriority IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_custkey >  131973445  AND nation.n_nationkey BETWEEN  3 AND 4  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_orderstatus <>  'P'  AND customer.c_phone >=  '15-677-711-5852'  AND nation.n_regionkey >=  3  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE nation.n_name <>  'ROMANIA'  AND orders.o_orderkey <>  381832358  AND customer.c_comment >=  'totes. quickly bold packages eat fluffily carefully pending instructions. quickly even depend'  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE nation.n_regionkey <  4  AND nation.n_name BETWEEN  'INDONESIA' AND 'ROMANIA'  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_phone LIKE  '2%'  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE SQRT(nation.n_regionkey)  <=  0  AND customer.c_nationkey IN  ( 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24)   AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE nation.n_regionkey =  2  AND orders.o_custkey IN  ( 804008, 15607330, 42325649, 45323707, 52272265, 54791387, 63744101, 85398223, 101472262, 102217142, 108258145)   AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE nation.n_name LIKE  'SAU%'  AND customer.c_comment NOT BETWEEN  'instructions after the slyly ironic requests promise regul' AND 's. special decoys cajole blit'  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  AND orders.o_clerk NOT IN  ( 'Clerk#000010131', 'Clerk#000071985', 'Clerk#000088825', 'Clerk#000100463', 'Clerk#000125502', 'Clerk#000153976', 'Clerk#000164572', 'Clerk#000201217', 'Clerk#000243893', 'Clerk#000278224', 'Clerk#000308472', 'Clerk#000375498', 'Clerk#000390352', 'Clerk#000398861', 'Clerk#000426588', 'Clerk#000613147', 'Clerk#000637677', 'Clerk#000648213', 'Clerk#000697669', 'Clerk#000748897', 'Clerk#000781075', 'Clerk#000906005', 'Clerk#000922027', 'Clerk#000923614')   ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE nation.n_comment LIKE  '%e quickly across the furiously regular d'  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_acctbal <>  1778.17  AND customer.c_address >  '7Uu101qAn5l4hwPWb5y5ISU,TMTgRl5NCctFSezt'  AND customer.c_mktsegment >=  'AUTOMOBILE'  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE LOG(9, orders.o_custkey)  BETWEEN  18.1202892343452 AND 18.50434384087  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_comment BETWEEN  'efully final, express accounts. furiously regular foxes cajole' AND 'express accounts. slyly bold pack'  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  AND nation.n_name NOT LIKE  '%PERU%'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  AND nation.n_name NOT IN  ( 'CANADA', 'ETHIOPIA', 'FRANCE', 'KENYA', 'UNITED KINGDOM', 'VIETNAM')   ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE EXTRACT (YEAR FROM orders.o_orderdate)  >  1994  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  ) ,   (  SELECT  COUNT(DISTINCT RTRIM(orders.o_clerk)) AS COUNT__DISTINCT__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_comment <=  'uriously pending packages about the regular pinto beans boost even theodolites. ironic forges detect carefully. ca'  AND orders.o_orderpriority NOT BETWEEN  '1-URGENT' AND '4-NOT SPECIFIED'  )  )")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
