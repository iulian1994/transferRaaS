

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949002042 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q79")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949002042") 
val results = spark.sql ("SELECT  SUBSTR(t1.r_name, 5, 46) AS SUBSTR__t1__r_name__5__46, t2.n_comment AS t2__n_comment, SUBSTR(t1.r_comment, 11, 142) AS SUBSTR__t1__r_comment__11__142, LOWER(t2.n_name) AS LOWER__t2__n_name, COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment, COUNT(LTRIM(t1.n_comment)) AS COUNT__LTRIM__t1__n_comment, COUNT(t2.n_nationkey) AS COUNT__t2__n_nationkey, COUNT(t1.s_name) AS COUNT__t1__s_name, COUNT(t2.s_nationkey) AS COUNT__t2__s_nationkey FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey  WHERE  t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)  GROUP BY   SUBSTR(t1.r_name, 5, 46) , t2.n_comment ,  SUBSTR(t1.r_comment, 11, 142) ,  LOWER(t2.n_name)  HAVING   COUNT(LTRIM(t1.s_comment)) not in (  (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.n_nationkey NOT BETWEEN  2 AND 12  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.s_phone <>  '26-280-219-5631'  AND t2.s_name >  'Supplier#002169203       '  AND t1.s_comment NOT LIKE  '%kindle dar'  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.s_phone <  '29-790-862-9831'  AND t1.r_regionkey =  3  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.s_name <  'Supplier#002400982       '  AND t2.n_comment =  'ully final deposits sleep fluffily. quickly regular braids are furiously slyly'  AND SQRT(t1.n_regionkey)  >  1.4142135623731  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.n_regionkey >  2  AND t1.s_acctbal >=  9923.53  AND t1.s_phone NOT BETWEEN  '16-852-338-7181' AND '25-159-499-4488'  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE SQRT(t2.n_nationkey)  <=  3.74165738677394  AND t2.s_acctbal <>  7816.61  AND t1.s_address NOT IN  ( '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000')   OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.s_address <  '0000000000'  AND t1.ps_comment NOT LIKE  'lar packages. even deposits against the never final accounts impress quickly across the regular, regular %'  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.s_suppkey <  1539951  AND t1.r_name >=  'EUROPE                   '  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.ps_comment NOT IN  ( ' ironic theodolites. final packages serve slyly bold accounts. slyly regular instructions lose carefully against the final theodolites. unusual theodolites nag slyly around the carefully reg', 'about the blithely even waters: quickly final requests above the slyly regular requests detect blithely regular, even requests. quickly ironic asymptotes sle', 'ackages. blithely regular packages cajole slyly express ideas. carefully silent instru', 'bold foxes. carefully ironic instructions integrate. regularly c', 'e deposits. slyly ironic instructions boost alongside of the i', 'eans across the furiously even packages sleep busily fluffily regular accounts. furiously ironic requests nag blithely along the r', 'ending sauternes haggle furiously furiously regular packages. quickly regular accounts across the blithely final accounts may are carefully among the furiously pending ', 'final deposits sleep final, regular instructions. furiously regular deposits w', 'g instructions about the bold, ironic theodolites nag carefully across the quickly even requests. regular deposits h', 'g orbits. ironic theodolites haggle. slyly final deposits integrate boldly at the fluffily silent frets. instructions according to the blithely ironic platelets sleep slyly regular pla', 'ges. furiously unusual foxes affix furiously: pending, fi', 'ial instructions according to the even, ironic deposits haggle against the special', 'inly: pending instructions nag slyly even ideas. quickly ironic deposits wake fluffily. quickly regular req', 'n requests. bold, special packages are blithely quickly r', 'ns. furiously regular deposits cajole. even requests around the ironic, special deposits sleep final, ironic instructions. fluffil', 'odolites. even, final epitaphs affix slyly even deposits? ironically regular requests cajole even requests. quickly regular foxes haggle blithely', 'requests. carefully regular ideas wake fluffily final packages: blithely regular packages unwind. final packages play among the express pearls-- quickly iro', 'rint. accounts would use about the blithely bold ideas. regular, bold pinto beans cajole silent, pending accounts. fluffily unusual deposits wake; furiously pending instructions ', 's. dependencies use fluffily against the slyly final accounts. furiously ironic packages are slyly ironic requests: fluffily express instructio', 'with the final requests. packages nag blithely slyly bold pinto beans. ironic accounts affix: fluffily final packages affix. e')   OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE SQRT(t1.s_nationkey)  =  4  AND t1.s_suppkey IN  ( 215410, 215421, 447154, 447159, 1308132, 1539932, 1539933, 1539937, 1539948, 1539956, 2169183, 2169191, 2169194, 2400954, 2400955, 2400985, 3261791, 3261811, 3493468, 3493470, 4122560, 4122574, 4122579, 4354346, 4586145)   AND t1.r_name LIKE  'AFRICA        %'  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.n_comment <  'wake quickly. unusual theodolites integrate quick'  AND t1.ps_supplycost >  903.12  AND t2.n_nationkey >  22  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.ps_availqty IN  ( 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)   AND t1.n_regionkey NOT BETWEEN  0 AND 3  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.s_phone <>  '14-517-275-4776'  AND t1.r_name BETWEEN  'AFRICA                   ' AND 'EUROPE                   '  AND t1.ps_partkey IN  ( 28018998, 28019006, 35636279, 35636288, 39444691, 39444696, 43253421, 47062569, 47062575, 47062579, 76114814, 76114815, 79923314, 79923315, 79923319, 87540780, 91349210, 91349217, 95157462, 95157464)   OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.n_comment >=  'fully express ideas. pending accounts sublate blithely. furiously re'  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.s_nationkey <  11  AND t2.n_regionkey <>  2  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.n_comment NOT LIKE  'ully final deposits sleep fluffily. quickly regular %'  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.n_name >  'IRAN                     '  AND t1.ps_availqty >=  1  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.s_phone <>  '33-394-627-6596'  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.n_regionkey <  3  AND t1.s_address <>  '0000000000'  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.n_nationkey <>  20  AND t1.s_name >  'Supplier#002400965       '  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE ROUND(t1.s_acctbal, 0)  >=  3489  AND t1.r_comment IN  ( 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg')   AND t2.n_nationkey NOT BETWEEN  14 AND 19  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   ) ,   (  SELECT  COUNT(LTRIM(t1.s_comment)) AS COUNT__LTRIM__t1__s_comment  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 FULL JOIN (SELECT * FROM  supplier supplier2 INNER JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE ROUND(t2.s_acctbal, 0)  BETWEEN  4253 AND 9758  AND t2.s_address LIKE  '%0'  OR t2.n_name >=  'JORDAN                   '  OR t2.s_nationkey NOT IN  ( 0, 3, 4, 14, 17, 18)   OR t2.s_suppkey NOT IN  ( 1539926)   )  ) ORDER BY  2 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
