

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949000508 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q19")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949000508") 
val results = spark.sql ("SELECT  t2.n_comment AS t2__n_comment, t1.c_phone AS t1__c_phone, LOWER(t1.c_comment) AS LOWER__t1__c_comment, RTRIM(t2.n_name) AS RTRIM__t2__n_name, COUNT(t2.o_totalprice) AS COUNT__t2__o_totalprice, MIN(t2.n_regionkey) AS MIN__t2__n_regionkey, MIN(t1.c_name) AS MIN__t1__c_name FROM  (SELECT * FROM  customer ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.c_custkey = t2.c_custkey  WHERE  t1.c_name IN  ( 'Customer#004753068', 'Customer#007694272', 'Customer#011960140', 'Customer#019165690', 'Customer#022106006', 'Customer#022106037', 'Customer#029311711', 'Customer#029311725', 'Customer#036517550', 'Customer#043724136', 'Customer#043724170', 'Customer#050929389', 'Customer#050929398', 'Customer#050929412', 'Customer#050929419', 'Customer#058135874', 'Customer#058135876', 'Customer#072546773', 'Customer#072546776', 'Customer#072546780', 'Customer#072546798')   OR t2.n_comment >  'fully express ideas. pending accounts sublate blithely. furiously re'  OR t2.o_comment NOT BETWEEN  'furiously special f' AND 'furiously special f'  OR t2.c_address NOT IN  ( ',vtKRq6VGE', '6yH8pW5HBVUY656VcAD', '9dvNZILMwXZJFG33wiz0nJpfOzXqHh2Ee', 'cmDwRzio3Ou7HvXOcrVAhHVXhB2Wok', 'e2oWNrcH 6mdJh', 'kfh46mmabbKWIaw2Ku uEMf', 'luSQbOMWVJKxfDRrFz', 'mBWzQH2gTJH', 'MZPx0EOcwOnVc3dc2JO3QxZY26DzKxiZNPf960', 'PBMdVQl7uSwXN', 'sF50lS6afaWzbCiyV2dKhk', 'VtrFcJY6jqHI', 'y2bTX1A3r3lIG8R', 'Z90lDe8UrzXpsSMhWs4npp')  GROUP BY  t2.n_comment , t1.c_phone ,  LOWER(t1.c_comment) ,  RTRIM(t2.n_name)  HAVING   MIN(t2.n_regionkey) <>   (  SELECT  MIN(t2.n_regionkey) AS MIN__t2__n_regionkey  FROM  (SELECT * FROM  customer ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t1.c_comment IN  ( ' packages run slyly across the foxes. even theodolites are quickly. packages dazzle qui', ' warhorses. carefully bold shea', 'deposits. slyly special packages grow across the slyly even requests. regular, regular asymptotes thrash. final pl', 'dly quickly regular accounts. final deposits according to the pending theodolites cajole slyly fina', 'eas sleep carefully across the unusual requests. carefully ironic accounts sleep slyly around the final', 'iously even deposits. regular packages sle', 'its. blithely even accounts nag after the deposits. even, final ideas are final, pending theodolites. ironic deposit', 'lyly blithely blithe dolphins. blith', 'nts are furiously theodolites. fluffily ironic platelets', 'posits wake blithely asymptotes. fluffily special accounts boost carefully furiously regular deposits. qui', 'r packages. final packages haggle above the q', 'regular courts use blithely against the slyly careful pinto beans. unusual, pending accounts print ruthles', 'ructions kindle carefully slyly pending packages. slyly bold war', 's the carefully special deposits? carefully even pack', 'thely. furiously unusual packages are slyly pending dolphins-- bold, special', 'uickly ironic theodolites haggle blithely regular ideas-- carefu', 'uickly unusual ideas. daringly special ', 'y alongside of the bold, slow attainments. quickly express ideas solve ')   AND t1.c_name IN  ( 'Customer#004753068', 'Customer#007694272', 'Customer#011960140', 'Customer#019165690', 'Customer#022106006', 'Customer#022106037', 'Customer#029311711', 'Customer#029311725', 'Customer#036517550', 'Customer#043724136', 'Customer#043724170', 'Customer#050929389', 'Customer#050929398', 'Customer#050929412', 'Customer#050929419', 'Customer#058135874', 'Customer#058135876', 'Customer#072546773', 'Customer#072546776', 'Customer#072546780', 'Customer#072546798')   OR t2.n_comment >  'fully express ideas. pending accounts sublate blithely. furiously re'  OR t2.o_comment NOT BETWEEN  'furiously special f' AND 'furiously special f'  OR t2.c_address NOT IN  ( ',vtKRq6VGE', '6yH8pW5HBVUY656VcAD', '9dvNZILMwXZJFG33wiz0nJpfOzXqHh2Ee', 'cmDwRzio3Ou7HvXOcrVAhHVXhB2Wok', 'e2oWNrcH 6mdJh', 'kfh46mmabbKWIaw2Ku uEMf', 'luSQbOMWVJKxfDRrFz', 'mBWzQH2gTJH', 'MZPx0EOcwOnVc3dc2JO3QxZY26DzKxiZNPf960', 'PBMdVQl7uSwXN', 'sF50lS6afaWzbCiyV2dKhk', 'VtrFcJY6jqHI', 'y2bTX1A3r3lIG8R', 'Z90lDe8UrzXpsSMhWs4npp')   )    and COUNT(t2.o_totalprice) >=   (  SELECT  COUNT(t2.o_totalprice) AS COUNT__t2__o_totalprice  FROM  (SELECT * FROM  customer ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.c_custkey = t2.c_custkey   WHERE t2.n_regionkey <>  0  AND t1.c_phone >  '10-106-446-4570'  AND t1.c_name IN  ( 'Customer#004753068', 'Customer#007694272', 'Customer#011960140', 'Customer#019165690', 'Customer#022106006', 'Customer#022106037', 'Customer#029311711', 'Customer#029311725', 'Customer#036517550', 'Customer#043724136', 'Customer#043724170', 'Customer#050929389', 'Customer#050929398', 'Customer#050929412', 'Customer#050929419', 'Customer#058135874', 'Customer#058135876', 'Customer#072546773', 'Customer#072546776', 'Customer#072546780', 'Customer#072546798')   OR t2.n_comment >  'fully express ideas. pending accounts sublate blithely. furiously re'  OR t2.o_comment NOT BETWEEN  'furiously special f' AND 'furiously special f'  OR t2.c_address NOT IN  ( ',vtKRq6VGE', '6yH8pW5HBVUY656VcAD', '9dvNZILMwXZJFG33wiz0nJpfOzXqHh2Ee', 'cmDwRzio3Ou7HvXOcrVAhHVXhB2Wok', 'e2oWNrcH 6mdJh', 'kfh46mmabbKWIaw2Ku uEMf', 'luSQbOMWVJKxfDRrFz', 'mBWzQH2gTJH', 'MZPx0EOcwOnVc3dc2JO3QxZY26DzKxiZNPf960', 'PBMdVQl7uSwXN', 'sF50lS6afaWzbCiyV2dKhk', 'VtrFcJY6jqHI', 'y2bTX1A3r3lIG8R', 'Z90lDe8UrzXpsSMhWs4npp')   )   ORDER BY  5 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
