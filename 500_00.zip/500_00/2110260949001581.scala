

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949001581 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q60")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949001581") 
val results = spark.sql ("SELECT  supplier.s_address AS supplier__s_address, MAX(UPPER(supplier.s_comment)) AS MAX__UPPER__supplier__s_comment, MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0, MAX(UPPER(lineitem.l_shipmode)) AS MAX__UPPER__lineitem__l_shipmode FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey WHERE  lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        ' GROUP BY  supplier.s_address  HAVING   MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) not in (  (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE SQRT(lineitem.l_tax)  =  0.14142135623731  AND partsupp.ps_availqty >=  1  AND lineitem.l_returnflag BETWEEN  'N' AND 'R'  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE SQRT(partsupp.ps_suppkey)  >  2136.02223771196  AND supplier.s_comment NOT LIKE  'ent, regular requests impress even request%'  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE partsupp.ps_comment IN  ( ' regular accounts around the quick asymptotes are furiously bold asymptotes. final dolphins wake sly', 'according to the furiously ironic platelets. quickly regular deposits along the spec', 'arefully regular ideas along the blithely final requests integrate against the ideas. slyly pending asymptotes sleep quickly regular deposits. furiously unusual pinto b', 'es. asymptotes affix. pending, ironic accounts among the blithely even platelets will wake slyly under the ironically final excuses', 'final theodolites integrate blithely at the final, final requ', 'fluffily regular ideas. ironic accounts sleep carefully. regular accounts haggle slyly final requests. slyly fin', 'gle slyly. furiously unusual excuses are blithely. unusual deposits use furiously! carefully final dinos cajo', 'hless, regular pinto beans. slyly unusual packages boost. fluffily special packages wake. quickl', 'ial requests. asymptotes engage blithely final asymptotes. accounts sleep blithely at ', 'inly: pending instructions nag slyly even ideas. quickly ironic deposits wake fluffily. quickly regular req', 'into beans boost slyly. carefully express theodolites run fluffily against the packages. carefully pending deposits haggle. final requests boost bl', 'lar packages. even deposits against the never final accounts impress quickly across the regular, regular packages. fluffily pending platelets wake carefully ideas. slyly pending', 'lithely ironic somas at the furiously special platelets wake quickly pending accounts. slyly final sauternes cajole special requests.', 'luffily across the final, even deposits. quickly unusual deposits haggle. silent decoys around the final deposits haggle according to the slyly express packages. carefully bold requests sleep ', 'ly alongside of the dinos. unusual platelets are quickly regular accounts. slyly ironic deposits integrate s', 'ndencies; deposits sleep special attainments. even packages nag slyly ironic instructions. quickly bold theodolites sleep blithely according', 'nto beans. even accounts haggle blithely according to the slyly bold packages. ironic deposits cajole slyly above the ', 'onic requests across the quickly regular platelets haggle fluffily along the fluffily unusual pinto bea', 'ously blithely close grouches. carefully even platelets affix blithely regular theodolites. final requests sleep quickly ironic ideas. blith', 'ously carefully regular packages: furiously bold asymptotes alongside of the instr', 'phins. unusual pinto beans about the even packages cajole near', 'regular deposits: furiously unusual accounts sleep. quickly silent accounts sleep carefully. blithely final dolphins haggle carefully. slyly pending deposits are across the carefully regular pa', 'sits sleep furiously about the special, special accounts. final pinto beans sleep carefully? slyly pending ')   OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE supplier.s_address <  '0000000000'  AND lineitem.l_shipmode NOT LIKE  '%IL    %'  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE supplier.s_comment <=  'uctions wake. silent, even theodolites u'  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE supplier.s_comment >  ' ironic accounts use blithely fluffily ironic instructions. carefully silent asymp'  AND FLOOR(lineitem.l_quantity)  BETWEEN  48 AND 49  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_discount <  0.05  AND lineitem.l_returnflag IN  ( 'A', 'A', 'A', 'N', 'N', 'N', 'R', 'R')   AND lineitem.l_shipmode IN  ( 'AIR       ', 'AIR       ', 'MAIL      ', 'RAIL      ', 'REG AIR   ', 'REG AIR   ', 'REG AIR   ', 'TRUCK     ', 'TRUCK     ')   OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_linenumber <>  1  AND lineitem.l_shipmode <>  'RAIL      '  AND lineitem.l_returnflag =  'R'  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE supplier.s_nationkey <=  4  AND supplier.s_suppkey <=  215409  AND lineitem.l_linenumber >  3  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_receiptdate BETWEEN  DATE'1993-06-03' AND DATE'1993-11-25'  AND partsupp.ps_partkey BETWEEN  28018998 AND 91349219  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE supplier.s_comment <>  'usual, furious deposits are carefully daringly '  AND supplier.s_phone >=  '28-674-748-8506'  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_receiptdate <=  DATE'1998-07-08'  AND lineitem.l_returnflag NOT BETWEEN  'A' AND 'N'  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE partsupp.ps_suppkey <  2003438  AND supplier.s_comment >=  'ccounts use slyly above the blithely pending accounts. blithely final accounts nag quickly. carefull'  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(SUBSTR(lineitem.l_returnflag, 1, 0)) AS MAX__SUBSTR__lineitem__l_returnflag__1__0  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_orderkey <  1071725475  AND supplier.s_comment <=  'usly ironic requests. furiously even dolphin'  AND lineitem.l_tax >  0.03  OR lineitem.l_linestatus <>  'O'  OR lineitem.l_partkey =  48615103  OR lineitem.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  )  )")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
