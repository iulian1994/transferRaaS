

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949001126 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q48")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949001126") 
val results = spark.sql ("SELECT  t1.r_name AS t1__r_name, t2.n_regionkey AS t2__n_regionkey, t1.n_regionkey AS t1__n_regionkey, UPPER(t2.n_comment) AS UPPER__t2__n_comment, t1.n_comment AS t1__n_comment, MAX(t2.ps_suppkey) AS MAX__t2__ps_suppkey, MIN(t2.l_tax) AS MIN__t2__l_tax, MIN(t1.ps_supplycost) AS MIN__t1__ps_supplycost, MAX(t2.l_commitdate) AS MAX__t2__l_commitdate, MAX(LOG(6, t1.ps_partkey)) AS MAX__LOG__6__t1__ps_partkey, MAX(LOG(6, t2.ps_partkey)) AS MAX__LOG__6__t2__ps_partkey FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey  WHERE  t2.l_shipinstruct <=  'DELIVER IN PERSON        ' GROUP BY  t1.r_name , t2.n_regionkey , t1.n_regionkey ,  UPPER(t2.n_comment) , t1.n_comment  HAVING   MAX(LOG(3, t1.ps_partkey)) in (  (  SELECT  MAX(LOG(3, t1.ps_partkey)) AS MAX__LOG__3__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t1.s_address =  '0000000000'  AND t2.n_name NOT BETWEEN  'IRAQ                     ' AND 'ROMANIA                  '  AND t1.ps_comment NOT IN  ( ' are quickly pinto beans. slyly close theodolites x-ray carefully above the fluffily final deposits. regular, reg', 'ackages cajole carefully carefully regular deposits. carefully pending sentiments wake against the carefully final deposits-- quickly final', 'blithely unusual packages. busily even platelets sleep ironic, silent foxes. slyly unusual packages doubt furiously among the even foxes. furiously exp', 'e blithely after the pending requests. even, bold frets wake slyly across the furiously express accounts. quickly pending asymptotes would wake carefully even deposi', 'nder; bold platelets nag fluffily across the furiously unusual deposits. pending requests are-- quickly express ins', 'sits sleep furiously about the special, special accounts. final pinto beans sleep carefully? slyly pending ', 't blithely about the pending, bold pinto beans; quickly even packages alongside of the regular accounts sleep blithely fin', 'tes are quickly ironic forges-- special accounts across the even courts believe furiously after the doggedly unusual asymptotes; slyly final accounts past the slyly final pinto beans wake slyly', 'ular dolphins boost furiously against the final theodolites. close, s', 'ves. furiously slow accounts about the slyly final excuses lose carefully slyly pen')   ) ,   (  SELECT  MAX(LOG(4, t1.ps_partkey)) AS MAX__LOG__4__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t2.l_linenumber <>  7  ) ,   (  SELECT  MAX(LOG(10, t1.ps_partkey)) AS MAX__LOG__10__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t2.l_quantity <>  14  AND t2.l_suppkey BETWEEN  695819 AND 3127477  ) ,   (  SELECT  MAX(LOG(3, t1.ps_partkey)) AS MAX__LOG__3__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t2.l_shipmode NOT IN  ( 'AIR       ', 'REG AIR   ')   AND t2.s_nationkey NOT IN  ( 0, 7, 8, 9, 13, 18, 20, 24)   ) ,   (  SELECT  MAX(LOG(7, t1.ps_partkey)) AS MAX__LOG__7__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND ROUND(t2.s_acctbal, 2)  =  2921.03  AND t2.l_quantity IN  ( 1, 2, 3, 7, 16, 17, 21, 22, 24, 31, 33, 34, 37, 39, 40, 47, 48)   ) ,   (  SELECT  MAX(LOG(5, t1.ps_partkey)) AS MAX__LOG__5__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t2.l_tax >  0  ) ,   (  SELECT  MAX(LOG(9, t1.ps_partkey)) AS MAX__LOG__9__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t2.l_discount IN  ( 0, 0, 0.01, 0.01, 0.02, 0.02, 0.05, 0.05, 0.06, 0.07, 0.07, 0.07, 0.08, 0.08, 0.09, 0.09, 0.1, 0.1, 0.1)   AND BROUND(t2.ps_supplycost, 2)  IN  ( 60.61, 160.15, 188.66, 252.55, 370.55, 487, 539.41, 629.7, 682.36, 758.32, 799.17, 887.88, 935.79, 955.28)   AND t1.ps_availqty NOT IN  ( 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)   ) ,   (  SELECT  MAX(LOG(6, t1.ps_partkey)) AS MAX__LOG__6__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.s_acctbal <  8012.16  AND t2.l_shipinstruct <=  'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(LOG(4, t1.ps_partkey)) AS MAX__LOG__4__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.n_comment <  'ogs x-ray fluffily special, fin'  AND t1.n_name <=  'FRANCE                   '  AND t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t2.s_suppkey =  2169171  ) ,   (  SELECT  MAX(LOG(8, t1.ps_partkey)) AS MAX__LOG__8__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t1.s_comment =  ' bold accounts integrate slyly. '  AND t2.l_returnflag >  'N'  ) ,   (  SELECT  MAX(LOG(3, t1.ps_partkey)) AS MAX__LOG__3__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND SQRT(t1.ps_suppkey)  >=  2218.85578621054  AND SQRT(t2.ps_suppkey)  >=  1110.07026804613  ) ,   (  SELECT  MAX(LOG(6, t1.ps_partkey)) AS MAX__LOG__6__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_linenumber <=  6  AND t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t2.l_shipmode NOT BETWEEN  'REG AIR   ' AND 'SHIP      '  ) ,   (  SELECT  MAX(LOG(4, t1.ps_partkey)) AS MAX__LOG__4__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t2.l_linestatus NOT BETWEEN  'F' AND 'O'  ) ,   (  SELECT  MAX(LOG(6, t1.ps_partkey)) AS MAX__LOG__6__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE SQRT(t2.l_linenumber)  <  2  AND t2.l_shipinstruct <=  'DELIVER IN PERSON        '  ) ,   (  SELECT  MAX(LOG(10, t1.ps_partkey)) AS MAX__LOG__10__t1__ps_partkey  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey RIGHT JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey   WHERE t1.s_acctbal <  -249.18  AND t1.n_regionkey <=  2  AND t2.l_shipinstruct <=  'DELIVER IN PERSON        '  AND t2.s_acctbal <>  7908.88  )  ) ORDER BY  7 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
