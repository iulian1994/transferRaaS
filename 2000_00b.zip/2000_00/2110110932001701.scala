

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932001701 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q72")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932001701") 
val results = spark.sql ("SELECT  LOWER(nation.n_comment) AS LOWER__nation__n_comment, supplier.s_address AS supplier__s_address, COUNT(DISTINCT SQRT(lineitem.l_orderkey)) AS COUNT__DISTINCT__SQRT__lineitem__l_orderkey, COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate, COUNT(DISTINCT EXTRACT (DAY FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____DAY__FROM__lineitem__l_receiptdate, COUNT(DISTINCT LTRIM(lineitem.l_shipinstruct)) AS COUNT__DISTINCT__LTRIM__lineitem__l_shipinstruct, MIN(lineitem.l_discount) AS MIN__lineitem__l_discount, COUNT(DISTINCT supplier.s_phone) AS COUNT__DISTINCT__supplier__s_phone FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey WHERE  SQRT(partsupp.ps_availqty)  =  96.8297474952816 GROUP BY   LOWER(nation.n_comment) , supplier.s_address  HAVING   COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) in (  (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE nation.n_comment <  'haggle. carefully final deposits detect slyly agai'  AND supplier.s_comment <=  'cajole about the slyly express requests. packages after the furiously final pinto bea'  AND supplier.s_nationkey NOT IN  ( 2, 7, 9, 12, 13, 14, 16, 17, 19, 20, 24)   OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_shipdate >=  DATE'1995-08-11'  AND partsupp.ps_suppkey IN  ( 8493599)   OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_commitdate <>  DATE'1994-12-18'  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE nation.n_name =  'PERU'  AND lineitem.l_linestatus NOT IN  ( 'F', 'F', 'F', 'F', 'F', 'F', 'O', 'O')   AND EXTRACT (MONTH FROM lineitem.l_commitdate)  NOT IN  ( 3, 4, 7, 10)   OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE nation.n_regionkey <=  1  AND ROUND(lineitem.l_quantity, 0)  >  15  AND supplier.s_acctbal NOT BETWEEN  1959.73 AND 6607.03  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(lineitem.l_tax)  BETWEEN  0 AND 0  AND lineitem.l_partkey NOT IN  ( 8116553, 12579578, 15923621, 26271383, 115682877, 227910503, 228084984, 285209124, 330478515, 341466032, 341577303, 348240203, 371836431)   OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_linestatus >=  'F'  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE supplier.s_address =  'xUhVrMWjNA5bOg,zcyJkgv9m'  AND SQRT(lineitem.l_suppkey)  =  3642.70970569987  AND partsupp.ps_partkey >  23494627  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE LOG(7, lineitem.l_linenumber)  IN  ( 0, 0, 0, 0.693147180559945, 0.693147180559945, 0.693147180559945, 1.09861228866811, 1.09861228866811, 1.09861228866811, 1.38629436111989, 1.6094379124341, 1.6094379124341, 1.6094379124341, 1.79175946922805, 1.79175946922805, 1.79175946922805, 1.79175946922805, 1.79175946922805, 1.79175946922805, 1.79175946922805, 1.94591014905531, 1.94591014905531)   AND lineitem.l_shipinstruct LIKE  'NONE%'  AND lineitem.l_shipmode LIKE  '%FOB%'  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE supplier.s_phone >=  '12-734-282-9022'  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE partsupp.ps_suppkey NOT BETWEEN  3494498 AND 8494599  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_suppkey <  13109394  AND lineitem.l_orderkey >=  105722722  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_tax <  0.08  AND nation.n_regionkey =  2  AND partsupp.ps_supplycost NOT BETWEEN  672.33 AND 697.38  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_comment <  'even requests eat pending ideas. bu'  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  ) ,   (  SELECT  COUNT(DISTINCT EXTRACT (MONTH FROM lineitem.l_receiptdate)) AS COUNT__DISTINCT__EXTRACT____MONTH__FROM__lineitem__l_receiptdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_comment LIKE  '%%'  AND SQRT(supplier.s_nationkey)  NOT IN  ( 0, 1, 1.4142135623731, 1.73205080756888, 2, 2.23606797749979, 2.44948974278318, 2.64575131106459, 2.82842712474619, 3, 3.16227766016838, 3.3166247903554, 3.46410161513775, 3.60555127546399, 3.74165738677394, 3.87298334620742, 4, 4.12310562561766, 4.24264068711928, 4.35889894354067, 4.47213595499958, 4.58257569495584, 4.69041575982343, 4.79583152331272, 4.89897948556636)   OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  )  )  and COUNT(DISTINCT LTRIM(lineitem.l_shipinstruct)) >   (  SELECT  COUNT(DISTINCT LTRIM(lineitem.l_shipinstruct)) AS COUNT__DISTINCT__LTRIM__lineitem__l_shipinstruct  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE lineitem.l_linenumber <=  4  OR SQRT(partsupp.ps_availqty)  =  96.8297474952816  )   ORDER BY  4 ASC, 3 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
