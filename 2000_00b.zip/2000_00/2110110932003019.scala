

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932003019 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q127")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932003019") 
val results = spark.sql ("SELECT  t2.n_name AS t2__n_name, UPPER(t1.s_name) AS UPPER__t1__s_name, t1.s_comment AS t1__s_comment, t2.n_nationkey AS t2__n_nationkey, MAX(t1.s_nationkey) AS MAX__t1__s_nationkey, MAX(t2.l_shipinstruct) AS MAX__t2__l_shipinstruct, MAX(t2.n_regionkey) AS MAX__t2__n_regionkey, COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity, COUNT(DISTINCT ROUND(t1.ps_supplycost, 0)) AS COUNT__DISTINCT__ROUND__t1__ps_supplycost__0, MAX(RTRIM(t2.l_linestatus)) AS MAX__RTRIM__t2__l_linestatus FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey  GROUP BY  t2.n_name ,  UPPER(t1.s_name) , t1.s_comment , t2.n_nationkey  HAVING   COUNT(DISTINCT ROUND(t1.ps_supplycost, 0)) <>  7   or COUNT(DISTINCT t2.l_quantity) in (  (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.s_suppkey =  3740600  AND LOG(8, t1.ps_suppkey)  BETWEEN  15.0667291917313 AND 15.9548546961571  ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.n_regionkey <=  4  AND ROUND(t2.l_tax, 0)  IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   AND t2.s_comment NOT IN  ( 'cuses among the final deposits boost carefully alongside of th', 'e slyly. quickly final accounts about the carefully silent courts', 'egular, special requests. slow instructions wake ironica', 'foxes. accounts boost carefully fl', 'ges hang regular, unusual requests. furiously special pack', 'gle quickly among the regular packages. slyly final packages cajo', 'hely pending deposits. furiously regular attainments ha', 'l, regular foxes against the carefully silent foxes detect alongside of the ironic requests.', 'lly pending pinto beans haggle blithely bravely enticing', 'ly ironic packages eat foxes. regular, even ideas affix unusual, ironic dolphins. quickly ironi', 'manent theodolites use blith', 'n platelets cajole sometimes. quickly re', 'pending excuses poach! carefully even instruct', 'posits. ironic frays are furiously according to the pinto beans. special, special', 'ter the silent excuses. furiously special requests sleep slyly above the carefully', 'uickly even instructions cajole furiously across the blithely final theodolites. fluf', 'usly final deposits: ironic pinto beans along the quickly ironic packages', 'y bold excuses. furiously ironic asymptotes wake furiously. ironic, final pa', 'y unusual requests are fluffily after t', 'yly ironic realms engage furiously. ironic, express requests eng')   ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.s_suppkey <  3739138  AND EXTRACT (DAY FROM t2.l_receiptdate)  <>  2  AND ROUND(t1.ps_availqty, 0)  >  7833  ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.l_orderkey IN  ( 105720805, 105721091, 105721158, 105721381, 105721795, 105721955, 105722113, 105722212, 105722467, 105722595, 105722626, 105722785, 105723110, 105723233, 105723814, 105724294, 105724514, 105724614, 105724710, 105724833)   ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.s_name LIKE  'Supp%'  ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.ps_comment <>  'old pinto beans haggle after the furiously bold ideas.'  ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.s_acctbal <  356.68  AND EXTRACT (MONTH FROM t2.l_commitdate)  >  11  AND t1.ps_partkey BETWEEN  23493694 AND 23494483  ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.ps_comment IN  ( 'according to the furiously pending theodolites. furiously silent accounts', 'as. slyly special requests boost furiously. express foxes cajole furiously against the fluff', 'ffily at the furiously special ideas. thin dependencies nag furiously carefully', 'ickly ironic dependencies. quickly final instructions cajole furiously across the regular, special theodolites; boldly daring foxes are carefully against the even deposits. fi', 'ly above the theodolites. special accounts engage carefully blithely silent packages. carefully even accounts against the p')   AND BROUND(t2.s_acctbal, 2)  IN  ( -269.14, -14.74, 838.76, 1115.97, 1367.68, 1556.39, 2072.44, 4120.64, 4364.24, 4609.18, 5002.16, 6059.18, 6148.08, 6429, 6910.32, 7069.24, 7888.47, 7919.75, 7967.58, 8386.36, 8591.79, 9372.62, 9689.01)   ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.ps_partkey <=  23494661  ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.l_linestatus =  'F'  ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.n_nationkey NOT IN  ( 0, 1, 3, 5, 8, 9, 10, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24)   ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.l_shipinstruct NOT LIKE  'D%'  ) ,   (  SELECT  COUNT(DISTINCT t2.l_quantity) AS COUNT__DISTINCT__t2__l_quantity  FROM  (SELECT * FROM  partsupp partsupp1 RIGHT JOIN supplier supplier1 ON partsupp1.ps_suppkey = supplier1.s_suppkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey RIGHT JOIN nation nation2 ON supplier2.s_nationkey = nation2.n_nationkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.n_name <>  'ROMANIA'  )  )  and MAX(t2.l_shipinstruct) >  'TAKE BACK RETURN'  ORDER BY  9 ASC, 8 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
