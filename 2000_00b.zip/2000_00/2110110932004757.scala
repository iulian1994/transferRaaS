

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932004757 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q192")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932004757") 
val results = spark.sql ("SELECT  LTRIM(t1.n_name) AS LTRIM__t1__n_name, UPPER(t1.c_comment) AS UPPER__t1__c_comment, t1.c_phone AS t1__c_phone, t1.n_comment AS t1__n_comment, t1.n_regionkey AS t1__n_regionkey, t1.c_nationkey AS t1__c_nationkey, COUNT(t1.o_custkey) AS COUNT__t1__o_custkey, COUNT(EXTRACT (MONTH FROM t2.l_commitdate)) AS COUNT__EXTRACT____MONTH__FROM__t2__l_commitdate, COUNT(LOWER(t2.l_linestatus)) AS COUNT__LOWER__t2__l_linestatus, COUNT(t1.c_address) AS COUNT__t1__c_address FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber  WHERE  t1.c_phone =  '25-394-906-8830'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619 GROUP BY   LTRIM(t1.n_name) ,  UPPER(t1.c_comment) , t1.c_phone , t1.n_comment , t1.n_regionkey , t1.c_nationkey  HAVING   COUNT(t1.c_address) not in (  (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_phone =  '25-394-906-8830'  AND EXTRACT (MONTH FROM t2.l_receiptdate)  =  5  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_phone =  '25-394-906-8830'  AND t2.o_orderstatus =  'F'  AND t2.l_quantity >  18  AND t2.l_returnflag BETWEEN  'A' AND 'N'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_phone =  '25-394-906-8830'  AND SQRT(t2.l_orderkey)  >  10282.2210149364  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.l_partkey <>  110689969  AND t1.c_phone =  '25-394-906-8830'  AND ROUND(t1.l_tax, 1)  >  0.1  AND t2.o_comment BETWEEN  'dependencies. carefully unusual excuses sleep slyly quick' AND 'uickly against the slyly unusual requests. express co'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_comment =  'he slyly regular instructions: regul'  AND t1.c_phone =  '25-394-906-8830'  AND t1.l_suppkey >  9234263  AND t1.l_linestatus NOT BETWEEN  'F' AND 'O'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_phone =  '25-394-906-8830'  AND t2.o_orderkey BETWEEN  72177729 AND 72186436  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  AND t2.o_clerk NOT IN  ( 'Clerk#000022386', 'Clerk#000038687', 'Clerk#000049721', 'Clerk#000138990', 'Clerk#000149858', 'Clerk#000218927', 'Clerk#000294262', 'Clerk#000330260', 'Clerk#000383547', 'Clerk#000499834', 'Clerk#000545164', 'Clerk#000663885', 'Clerk#000676878', 'Clerk#001005367', 'Clerk#001196784', 'Clerk#001247173', 'Clerk#001259314', 'Clerk#001309567', 'Clerk#001504007', 'Clerk#001539891', 'Clerk#001732012', 'Clerk#001783611', 'Clerk#001913926', 'Clerk#001951826', 'Clerk#001995326')   OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.n_comment <>  'pending excuses haggle furiously deposits. pending, express pinto beans wake fluffily past t'  AND t1.c_phone =  '25-394-906-8830'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.l_shipinstruct <  'TAKE BACK RETURN'  AND t1.n_nationkey <>  16  AND t1.c_phone =  '25-394-906-8830'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_phone =  '25-394-906-8830'  AND t2.o_orderkey >  72179428  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE EXTRACT (DAY FROM t2.l_receiptdate)  <  22  AND t1.c_phone =  '25-394-906-8830'  AND t2.o_orderstatus IN  ( 'F', 'F', 'F', 'F', 'F', 'F', 'O', 'O', 'O', 'O', 'O', 'O', 'P', 'P', 'P', 'P', 'P', 'P', 'P')   AND t1.o_orderpriority LIKE  '%NT'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_nationkey <>  2  AND t1.c_phone =  '25-394-906-8830'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_phone =  '25-394-906-8830'  AND SQRT(t2.l_suppkey)  IN  ( 347.318297819162, 1147.83230482506, 1675.52141138214, 1818.99175369214, 2164.49370523455, 2401.39792620882, 2513.78937065141, 2526.79342250212, 2527.54604310189, 2798.81224807953, 2815.44348194028, 2911.48570321065, 2912.1904127306, 3070.28532876018, 3288.39094391163, 3306.8061630522, 3604.79236572649, 3806.06660477717, 3892.90213080165, 3943.54688066466, 3953.58672599957, 4101.20640787561, 4168.8151794005, 4178.79085382363)   AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  AND ROUND(t2.l_quantity, 3)  NOT IN  ( 1, 3, 4, 12, 23, 33, 45, 47, 48)   OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_name <  'Customer#075726159'  AND t1.c_phone =  '25-394-906-8830'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  AND t1.l_suppkey NOT IN  ( 2682095, 5793064, 6374250, 6388489, 8470257, 9185667, 9560588, 15382722, 15706935, 17628887, 18188388, 18881170)   AND t2.l_comment NOT LIKE  '% requ'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_name <=  'Customer#075722737'  AND t1.c_phone =  '25-394-906-8830'  AND t1.l_comment =  'integrate f'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.o_orderkey <>  72190117  AND t1.c_phone =  '25-394-906-8830'  AND t1.l_returnflag >=  'N'  AND t1.o_totalprice >=  176640.34  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.l_comment <>  'nding deposits. final,'  AND t1.c_phone =  '25-394-906-8830'  AND t1.l_shipmode IN  ( 'MAIL', 'RAIL', 'RAIL', 'RAIL', 'REG AIR', 'REG AIR', 'SHIP', 'TRUCK')   AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  ) ,   (  SELECT  COUNT(t1.c_address) AS COUNT__t1__c_address  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey RIGHT JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey INNER JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN orders orders2 ON lineitem2.l_orderkey = orders2.o_orderkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.c_phone =  '25-394-906-8830'  AND t1.o_comment NOT BETWEEN  'egrate slyly regular instr' AND 'rding to the blithely bold p'  AND t1.l_linestatus NOT IN  ( 'F', 'F', 'F', 'F', 'F', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O', 'O')   OR t1.l_orderkey BETWEEN  105720838 AND 105723362  OR t1.l_extendedprice NOT BETWEEN  8346.4 AND 40214.4  OR t1.l_linenumber NOT BETWEEN  4 AND 5  OR SQRT(t1.n_regionkey)  NOT BETWEEN  1.73205080756888 AND 2  OR SQRT(t2.l_tax)  NOT BETWEEN  0.173205080756888 AND 0.282842712474619  )  )  and COUNT(LOWER(t2.l_linestatus)) not in ( 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2 ) ORDER BY  3 DESC, 10 ASC, 7 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
