

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932003959 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q164")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932003959") 
val results = spark.sql ("SELECT  UPPER(t2.c_phone) AS UPPER__t2__c_phone, t2.n_nationkey AS t2__n_nationkey, t1.l_discount AS t1__l_discount, t2.o_comment AS t2__o_comment, EXTRACT (YEAR FROM t2.o_orderdate) AS EXTRACT____YEAR__FROM__t2__o_orderdate, EXTRACT (MONTH FROM t2.o_orderdate) AS EXTRACT____MONTH__FROM__t2__o_orderdate, EXTRACT (DOW FROM t2.o_orderdate) AS EXTRACT____DOW__FROM__t2__o_orderdate, t1.l_tax AS t1__l_tax, t2.c_name AS t2__c_name, t1.l_shipmode AS t1__l_shipmode, t1.n_regionkey AS t1__n_regionkey, UPPER(t1.r_comment) AS UPPER__t1__r_comment, EXTRACT (MONTH FROM t1.l_receiptdate) AS EXTRACT____MONTH__FROM__t1__l_receiptdate, EXTRACT (DAY FROM t1.l_receiptdate) AS EXTRACT____DAY__FROM__t1__l_receiptdate, t2.c_custkey AS t2__c_custkey, t1.l_suppkey AS t1__l_suppkey, t1.o_orderkey AS t1__o_orderkey, LOWER(t1.c_mktsegment) AS LOWER__t1__c_mktsegment, t2.c_address AS t2__c_address, SUBSTR(t1.n_comment, 15, 217) AS SUBSTR__t1__n_comment__15__217, t1.o_totalprice AS t1__o_totalprice, SUBSTR(t1.r_name, 8, 38) AS SUBSTR__t1__r_name__8__38, t2.n_regionkey AS t2__n_regionkey, SUBSTR(t2.c_mktsegment, 6, 23) AS SUBSTR__t2__c_mktsegment__6__23, LTRIM(t1.l_linestatus) AS LTRIM__t1__l_linestatus, t1.c_comment AS t1__c_comment, t2.o_totalprice AS t2__o_totalprice, t2.n_name AS t2__n_name, t1.c_acctbal AS t1__c_acctbal, LOWER(t1.l_shipinstruct) AS LOWER__t1__l_shipinstruct, LTRIM(t1.o_orderstatus) AS LTRIM__t1__o_orderstatus, t1.c_nationkey AS t1__c_nationkey, t2.o_custkey AS t2__o_custkey, t1.n_nationkey AS t1__n_nationkey, t1.l_linenumber AS t1__l_linenumber, SUBSTR(t2.o_orderpriority, 1, 48) AS SUBSTR__t2__o_orderpriority__1__48 FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey INNER JOIN customer customer1 ON orders1.o_custkey = customer1.c_custkey RIGHT JOIN nation nation1 ON customer1.c_nationkey = nation1.n_nationkey INNER JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 RIGHT JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey ) t2 ON  t1.n_nationkey = t2.n_nationkey  ORDER BY  4 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
