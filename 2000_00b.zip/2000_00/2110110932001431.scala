

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932001431 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q60")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932001431") 
val results = spark.sql ("SELECT  t1.r_name AS t1__r_name, COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost, MIN(LOWER(t1.n_name)) AS MIN__LOWER__t1__n_name FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey  WHERE  t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7 GROUP BY  t1.r_name  HAVING   COUNT(DISTINCT FLOOR(t2.ps_supplycost)) not in (  (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE SQRT(t2.ps_supplycost)  <>  28.5566104431181  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t1.r_name LIKE  'E%'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.r_name <>  'EUROPE'  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.r_regionkey <  3  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t2.s_suppkey BETWEEN  3738948 AND 3740896  AND t2.s_comment NOT BETWEEN  'foxes along the regular, final ideas sleep quickly regular, bold foxes. pinto beans wake blit' AND 'oubt ideas. even requests try to wake. regular theodolites boost slyly above the care'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.s_suppkey <  3738208  AND t2.s_nationkey >=  19  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t1.r_name NOT LIKE  '%%'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t2.s_address NOT LIKE  '%QIkz'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t1.s_suppkey BETWEEN  3740885 AND 3741013  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.s_phone >=  '21-816-676-5485'  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t2.ps_suppkey BETWEEN  3494647 AND 8494766  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.s_name =  'Supplier#003738648'  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t1.n_comment NOT BETWEEN  'c dependencies. furiously express notornis sleep slyly regular accounts. ideas sleep. depos' AND 'efully alongside of the slyly final dependencies.'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.s_name <  'Supplier#003737274'  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t1.n_comment NOT LIKE  'platelets. blithely pen%'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.s_suppkey >  3741156  AND t1.n_name >=  'INDONESIA'  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE ABS(t1.s_acctbal)  <  1853.4  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t2.s_address NOT IN  ( 'i1Q UOgzvRiFdAnL6nB', 'o2lRmVkveljLC4', 'q6Bj,rksVNCzRyhuS, n3hX,Phkw', 'XwHehk9VbF9OwitZQ', 'YTsmBgzIXhiw2u', 'ZtgxmoHFGS 1GoH')   OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.n_comment >=  'eas hang ironic, silent packages. slyly regular packages are furiously over the tithes. fluffily bold'  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t2.s_comment IN  ( '. even, regular deposits aft', 'deposits kindle above the carefully final requests. packages promise. ironic', 'lly even accounts nag blithely even fo', 'ly ironic packages eat foxes. regular, even ideas affix unusual, ironic dolphins. quickly ironi', 'nd the final, regular deposits. regular ideas boost alongsi', 'ously ironic accounts. carefully unusual theodolites use thinly', 'phins boost carefully across the carefully unusual ideas', 'rding to the blithely bold theodolites cajole unusual so')   OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.r_regionkey <>  4  AND t1.s_suppkey <>  3739927  AND t2.s_acctbal >  5232.2  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.s_phone <  '34-503-135-8508'  AND BROUND(t2.s_acctbal, 3)  <  -366.89  AND t2.s_name >  'Supplier#003738332'  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.ps_comment =  'en accounts doze quickly regular, pending asymptotes. carefully regular pinto beans integrate blithely'  AND t2.s_address =  'h75taxjQEqcKkIv4RNwS23j85t9,1'  AND t1.s_comment >  'tect silently. blithely regular pint'  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.n_regionkey =  3  AND t2.ps_availqty =  4746  AND t2.s_comment >=  'e to boost according to the furiously'  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t2.s_suppkey <  3740257  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t1.r_name LIKE  '%%'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t1.n_name NOT IN  ( 'BRAZIL', 'CHINA', 'ETHIOPIA', 'FRANCE', 'GERMANY', 'INDONESIA', 'IRAN', 'SAUDI ARABIA', 'UNITED KINGDOM', 'UNITED STATES', 'VIETNAM')   OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t2.ps_comment NOT IN  ( '. carefully regular platelets doubt quickly. final, even realms wake furiously regular packages! regular attainments alongside of the account', 'according to the furiously pending theodolites. furiously silent accounts', 'accounts sleep furiously unusual pinto beans. ideas nag fluffily according to the express, pending asymptotes. ironically final dependencie', 'ctions sleep slyly silent patterns. thinly express platelets through the furiously express pearls nag quickly express reques', 'ent theodolites. slyly regular packages snooze carefully carefully special deposits. special deposits sleep blithely. asymptotes sleep about the stealthily un', 'es. quickly unusual requests haggle slyly alongside of the special deposits. accounts boost never. u', 'es. quiet, even dolphins nod blithely. furiously even asy', 'express asymptotes. carefully regular pinto beans boost slyly regular, regular requests. slyly ironic deposits nag furiously according to the carefully ironic pinto bea', 'fter the slyly express packages. even deposits nag. deposits sleep. brave packages snooze carefully bold foxes. furiously regular requests wake quickly alongside of t', 'hely bold foxes cajole. slyly unusual deposits haggle fluffily beside the carefu', 'iously quiet accounts. furiously regular ideas boost blithely. special, even packages affix fluffily. final theodolites along the blithely special platelets mold furiously', 'its nag. furiously special packages according to the blithely ironic deposits are slyly around the final instructions. slyly enticing sauternes wake blithely furiousl', 'long the blithely bold deposits. quickly special requests haggle furiously. furiously ironic dependencies play', 'onic instructions across the furiously regular platelets boost after the carefully ironic packages. furiously even foxes haggle quickly blit', 'osits nag carefully quickly ironic ideas. permanently regular pinto beans doubt. blithely regular pinto beans wake b', 'pinto beans. bold, regular warhorses haggle. carefully special dinos haggle', 'requests. packages use after the ruthlessly regular the', 's. carefully ironic instructions sleep furiously ironic theodolites. quickly ironic requests use in place of th', 'sits. slyly regular theodolites across the blithely pending theodolites nag blithely carefully ev', 'sits. slyly unusual deposits sleep furiously alongside of the blithely final foxes. furiously regular requests sublate furiously above the final, reg', 'sleep furiously slyly bold ideas. quickly pending ideas wake quickly bold pinto beans. even deposits n', 'the pending dependencies unwind quickly alongside of the slyly stealthy pinto beans. slyly even deposits lose ironically around the idly ironic packages-- s', 'xpress deposits. even instructions use. furiously bold accounts boost carefully even instructions. fluffily unusual')   OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.s_comment <>  'y alongside of the quickly enticing accounts. slyly unusual decoys are fluf'  AND t2.s_address >  'ay4KZwIAfWL fTVtGU18zmZhGxjgd'  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  AND t2.ps_availqty NOT BETWEEN  5465 AND 9619  AND t1.n_comment NOT LIKE  'hag%'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE SQRT(t1.r_regionkey)  <  2  AND ABS(t2.ps_availqty)  <=  2800  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  ) ,   (  SELECT  COUNT(DISTINCT FLOOR(t2.ps_supplycost)) AS COUNT__DISTINCT__FLOOR__t2__ps_supplycost  FROM  (SELECT * FROM  supplier supplier1 INNER JOIN nation nation1 ON supplier1.s_nationkey = nation1.n_nationkey RIGHT JOIN region region1 ON nation1.n_regionkey = region1.r_regionkey ) t1 INNER JOIN (SELECT * FROM  partsupp partsupp2 RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON  t1.s_suppkey = t2.s_suppkey   WHERE t1.n_nationkey >=  14  AND t1.r_comment BETWEEN  'hs use ironic, even requests. s' AND 'lar deposits. blithely final packages cajole. regular waters are final requests. regular accounts are according to'  OR t2.ps_partkey BETWEEN  23493973 AND 23494140  OR t1.s_nationkey NOT BETWEEN  3 AND 7  )  ) ORDER BY  1 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
