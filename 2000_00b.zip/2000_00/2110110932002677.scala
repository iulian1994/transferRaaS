

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932002677 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q110")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932002677") 
val results = spark.sql ("SELECT  RTRIM(part.p_comment) AS RTRIM__part__p_comment, SUBSTR(part.p_type, 3, 16) AS SUBSTR__part__p_type__3__16, COUNT(DISTINCT part.p_brand) AS COUNT__DISTINCT__part__p_brand, COUNT(DISTINCT part.p_partkey) AS COUNT__DISTINCT__part__p_partkey, COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60 FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey WHERE  part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %' GROUP BY   RTRIM(part.p_comment) ,  SUBSTR(part.p_type, 3, 16)  HAVING   COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) in (  (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE LOG(6, partsupp.ps_partkey)  <=  16.97226073504  AND part.p_container <>  'LG PKG'  AND partsupp.ps_comment NOT BETWEEN  'iously about the special packages. closely bold packages cajole according to the carefully regular requests. slyly ironic dolphins according to' AND 'ironic theodolites are. furiously final courts haggle blithely fluffily unusual packages. furiously regular packa'  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE ROUND(partsupp.ps_availqty, 3)  <=  6158  AND part.p_container <>  'WRAP BAG'  AND partsupp.ps_partkey BETWEEN  23493872 AND 23494050  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE partsupp.ps_comment =  'p quickly brave theodolites. final ideas about the pinto beans run blithely across the inst'  AND LOG(3, partsupp.ps_supplycost)  IN  ( 4.1890484976914, 4.67030228092587, 4.76890337797069, 5.3536574615812, 5.5032562132074, 5.6887703545357, 5.84406602010326, 5.84655437531217, 5.95586327586501, 6.09969095217885, 6.10557417739806, 6.14538662938024, 6.29223558410148, 6.40834755552695, 6.46002964215937, 6.65188190304501, 6.67686933252977, 6.73144760250496, 6.76598431988365, 6.79079440525799, 6.80108279195502, 6.8487480984021, 6.89362592817627)   AND part.p_size NOT BETWEEN  5 AND 28  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_container LIKE  'JUMB%'  AND part.p_partkey NOT IN  ( 49107420, 49107923, 49108101, 49109544, 49109853, 49110381, 49111122, 49111277, 49112136)   OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE ABS(part.p_retailprice)  <  1945.49  AND part.p_mfgr =  'Manufacturer#2'  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE ABS(partsupp.ps_supplycost)  IN  ( 18.65, 63.58, 77.96, 91.59, 100.84, 248.08, 260.52, 380.5, 423.72, 445.72, 611.46, 791.38, 844.31, 866.79, 927.57, 947.32)   OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE partsupp.ps_comment NOT IN  ( 'accounts integrate final excuses. regular, regular pinto beans mold fluffily pending platelets. quickly even ideas could have to boost furiously regular deposits. blithel', 'ackages nag after the quickly regular foxes. carefully even accounts cajole blithely instructions. requests sl', 'ages. carefully final accounts boost slyly ironic ideas. carefully pending accounts thrash blithely! silently final pains sle', 'ar requests. blithely pending platelets affix slyly slyly pending pinto beans. regular dugouts cajole pinto beans. bold dependencies cajole slyly. furiously ev', 'ckages haggle furiously. carefully pending foxes print slyly final instructions. carefully ironic platelet', 'es haggle furiously carefully bold packages: carefully regular accounts cajole quickly. pending, special decoys cajole fluffily. blithely regular dependencies sleep furiously. blithely even theodo', 'he furious, special theodolites. closely ironic packages use fluffily between the carefully pending instructions. silent requests cajole slyly. slyly', 'ironic deposits. fluffily sly packages affix fluffily carefully final accounts. special foxes after the carefully regular pearls cajole quickly about the', 'ironic theodolites. slyly thin packages nag carefu', 'lites sleep silently up the ideas. bravely pending warhorses cajole carefully blithely silent instructions? hockey playe', 'nts maintain quickly against the pending pinto beans. slyly special packages hang beyond the blithely ex', 'sits. slyly regular theodolites across the blithely pending theodolites nag blithely carefully ev', 'sly blithely pending orbits. escapades wake furiously. ideas cajo', 'slyly silent requests sleep carefully ironic dolphins. carefully unusual notornis maintain slyly against the special, ironic depend', 'ual instructions haggle quickly around the ironic, pending ideas. furiously final deposits wake carefully. bold, regular instructions wake fluffily. special deposits detect quickly thr')   OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE partsupp.ps_suppkey NOT IN  ( 3493944, 3494186, 3494599, 3494644, 8494269, 8494425, 8494609, 13493896, 18493629, 18493904, 18493974, 18494078, 18494094, 18494277, 18494317, 18494400)   OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_mfgr <>  'Manufacturer#5'  AND partsupp.ps_supplycost BETWEEN  723.27 AND 746.04  AND partsupp.ps_suppkey NOT IN  ( 3493763, 3493914, 3494104, 3494634, 3494661, 8493671, 8493903, 8493983, 8494515, 13493731, 13493991, 13494355, 18493959, 18494320, 18494472)   OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_container <=  'SM PACK'  AND partsupp.ps_partkey >=  23494578  AND partsupp.ps_comment IN  ( 'accounts sleep furiously unusual pinto beans. ideas nag fluffily according to the express, pending asymptotes. ironically final dependencie', 'asymptotes according to the regular, even dependencies cajole about the even requests. busily ironic courts use furiou', 'beans. furiously ironic pinto beans haggle final foxes. final, special dependencies about the slyly regular packages wake slyly silent excuses. carefully pending foxes nag bli', 'deposits breach carefully carefully ironic dugouts. regular, express deposits b', 'egular requests. express, final requests alongside of the quickly special excuses un', 'en, final theodolites. slyly regular theodolites integrate quickly. carefully final dinos sleep after the furiously express platelets. carefully bold pack', 'ions. furiously even ideas wake among the carefully unusual requests. final multipliers wake carefully final pinto beans. furiously final frays wake carefully carefully pe', 'key players except the slyly express accounts nag slyly inside the furiously special asymptotes. ironic, regular accounts are according to', 'nal packages boost slyly above the quickly final pinto beans. furiously regular pinto', 'regular deposits sleep furiously finally pending dependencies. silent deposits wake blithely at the furious', 'sits. slyly regular theodolites across the blithely pending theodolites nag blithely carefully ev', 'unusual pinto beans haggle furiously. carefully regular accounts are furiously ab', 'usly regular sauternes affix quickly. stealthily special dependencies boost blithely. bold, ironic foxes eat slyly across the excuses. slyly even accounts sle', 'y regular deposits. carefully ironic ideas promise furiously according to', 'yly ironic ideas. regular depths believe silent accounts. care')   OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_retailprice <>  1769.31  AND part.p_partkey IN  ( 49107382, 49108080, 49108113, 49108114, 49108496, 49108832, 49109823, 49110187, 49110719, 49111292, 49111855)   AND partsupp.ps_partkey NOT BETWEEN  23494254 AND 23494328  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE partsupp.ps_partkey <=  23494663  AND ROUND(part.p_retailprice, 2)  BETWEEN  1235.78 AND 1828.36  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE LOG(8, part.p_partkey)  =  17.709550553987  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_brand <  'Brand#14'  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE partsupp.ps_comment IN  ( 'about the carefully ironic requests. blithely ironic packages sleep carefully quickly fina', 'ecial deposits are. slyly even ideas cajole fluffily across the blithely express dugouts. ironic, even ideas kindle. foxes wake. deposits sleep', 'en deposits cajole quickly furiously even multipliers. final excuses along the s', 'en theodolites boost across the quickly express accounts. blithely regular deposits eat carefully-- quickly regular deposits above the carefully regular deposits use quickly slyly speci', 'eposits hinder alongside of the carefully close pinto beans. packages sleep idly after', 'es. quiet, even dolphins nod blithely. furiously even asy', 'final pinto beans wake slyly. furiously even foxes cajole atop the finally final pinto beans. final asymptotes sle', 'ges. ironic packages wake fluffily final requests. ir', 'ly furiously unusual accounts! quickly silent instructions promise. packages use across the carefully express foxes. fluffily pending deposits use fluffily. silent dolp', 'nt deposits by the carefully even accounts haggle across the slyly final foxes. slyly bold theodolites sleep after the express asymptotes. unusual packages boost furiously pen', 'of the even accounts affix according to the even theodolites. requests doubt above the regular, ir', 'quickly ironic deposits. bold dependencies about the furiously pending deposits haggle slyly final accounts. final packages af', 'rding to the furiously regular accounts will integrate carefully special accounts. quickly close courts above the regular, express requests cajole carefully about the bold, final pack', 'ys. fluffily special accounts shall boost across the iro')   AND partsupp.ps_suppkey NOT BETWEEN  8493985 AND 13494208  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE partsupp.ps_comment <=  'ests sleep above the final, final packages. deposits among the carefully unusual sentiments boost carefully final gro'  AND SQRT(part.p_retailprice)  >=  44.1075957177446  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_size >=  13  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE partsupp.ps_comment =  'have to promise quickly above the silent, ironic requests? regular, bold deposits wake blithely across the regul'  AND partsupp.ps_partkey >  23494606  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE FLOOR(part.p_retailprice)  NOT BETWEEN  1184 AND 1495  AND partsupp.ps_comment NOT LIKE  '%o bea'  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_brand <=  'Brand#52'  AND part.p_partkey NOT IN  ( 49108139, 49108602, 49110420, 49110465, 49110814, 49111601)   AND partsupp.ps_suppkey NOT IN  ( 3493999, 3494128, 3494177, 3494282, 3494551, 8493599, 8493664, 8494294, 8494765, 13493638, 13493689, 13493816, 13493849, 13493883, 13493884, 13494317, 13494367, 13494403, 13494577, 13494782, 18494210, 18494325, 18494362, 18494436, 18494758)   OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE SQRT(part.p_size)  >  5.29150262212918  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_partkey <  49109285  AND partsupp.ps_partkey <=  23493631  AND partsupp.ps_availqty IN  ( 184, 1122, 1209, 1227, 1988, 2667, 3045, 3578, 4460, 4880, 5042, 5869, 5937, 7437, 7533, 7636, 7815, 8054, 8582, 8785, 9051)   OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE BROUND(partsupp.ps_availqty, 1)  <  502  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE part.p_brand <  'Brand#53'  AND part.p_mfgr <=  'Manufacturer#1'  AND part.p_type >  'ECONOMY BRUSHED BRASS'  OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(part.p_name, 7, 60)) AS COUNT__DISTINCT__SUBSTR__part__p_name__7__60  FROM  partsupp INNER JOIN part ON partsupp.ps_partkey = part.p_partkey  WHERE partsupp.ps_supplycost <=  867.82  AND LOG(3, partsupp.ps_availqty)  IN  ( 6.96602418710611, 7.30114780585603, 7.85941315469358, 8.17046857833067, 8.31630024903685, 8.37031599555548, 8.42858053305963, 8.68575383296015, 8.72550732848445, 8.92038906008036, 9.13043098874788, 9.14601516141962)   OR part.p_name >  'snow medium blush blanched metallic'  OR part.p_comment LIKE  'ironic, bold %'  )  ) ORDER BY  3 ASC, 1 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
