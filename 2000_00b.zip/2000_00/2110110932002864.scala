

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932002864 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q117")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932002864") 
val results = spark.sql ("SELECT  RTRIM(supplier.s_comment) AS RTRIM__supplier__s_comment, supplier.s_nationkey AS supplier__s_nationkey, LTRIM(supplier.s_address) AS LTRIM__supplier__s_address, MAX(lineitem.l_linenumber) AS MAX__lineitem__l_linenumber, MAX(lineitem.l_comment) AS MAX__lineitem__l_comment, MAX(lineitem.l_linestatus) AS MAX__lineitem__l_linestatus, MIN(ABS(lineitem.l_tax)) AS MIN__ABS__lineitem__l_tax, MIN(partsupp.ps_supplycost) AS MIN__partsupp__ps_supplycost FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey WHERE  lineitem.l_returnflag =  'A'  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6 GROUP BY   RTRIM(supplier.s_comment) , supplier.s_nationkey ,  LTRIM(supplier.s_address)  HAVING   MAX(lineitem.l_comment) in (  (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE supplier.s_nationkey <  22  AND lineitem.l_returnflag =  'A'  AND lineitem.l_shipmode IN  ( 'AIR', 'AIR', 'AIR', 'AIR', 'FOB', 'FOB', 'FOB', 'FOB', 'MAIL', 'MAIL', 'MAIL', 'RAIL', 'RAIL', 'RAIL', 'REG AIR', 'REG AIR', 'REG AIR', 'REG AIR', 'REG AIR', 'REG AIR', 'SHIP', 'TRUCK', 'TRUCK', 'TRUCK')   AND supplier.s_address IN  ( 'cwJCeI63Ay4nkiKaUO', 'cYa3fUQ8N9xsZKdJOJSMLkdAyB91epBaYfLR', 'deFaiUpRlIux8250h9cOJXel', 'KqmMnPm3RwuJoGijGhF,U918Sf2', 'PyQt6nc5o5sLHWRuRzBSLGNgKWCZIyASyooi4', 's2b,duwGG8wMnJ6Hh4AWLL06')   OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE partsupp.ps_availqty <  9956  AND partsupp.ps_supplycost <  143.95  AND lineitem.l_returnflag =  'A'  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_quantity <>  36  AND lineitem.l_returnflag =  'A'  AND lineitem.l_orderkey IN  ( 105720390, 105721827, 105722310, 105722594, 105723427, 105724135, 105724485)   OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE SQRT(supplier.s_nationkey)  <  1.73205080756888  AND partsupp.ps_availqty <>  3420  AND lineitem.l_quantity =  26  AND lineitem.l_returnflag =  'A'  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_returnflag =  'A'  AND SQRT(partsupp.ps_partkey)  IN  ( 4847.03538258181, 4847.05467268526, 4847.06457559624, 4847.06653554498, 4847.06725763115, 4847.08252457084, 4847.08324665463, 4847.10325864841)   AND partsupp.ps_suppkey NOT IN  ( 3493999, 3494177, 3494371, 3494465, 3494551, 8494412, 8494517, 8494709, 13493606, 13493616, 13493731, 13494069, 13494367, 13494373, 18493974, 18494393, 18494563, 18494727)   OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_returnflag =  'A'  AND supplier.s_nationkey >=  14  AND supplier.s_suppkey NOT IN  ( 3737732, 3738280, 3739328, 3739965, 3740719)   OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE partsupp.ps_suppkey <  3493913  AND lineitem.l_linestatus <>  'F'  AND supplier.s_address <>  'YDBIQ5mcZqNG'  AND lineitem.l_returnflag =  'A'  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_returnflag =  'A'  AND supplier.s_suppkey =  3738948  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE partsupp.ps_supplycost <=  139.58  AND lineitem.l_returnflag =  'A'  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_returnflag =  'A'  AND lineitem.l_quantity BETWEEN  43 AND 49  AND EXTRACT (YEAR FROM lineitem.l_receiptdate)  BETWEEN  1994 AND 1996  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_returnflag =  'A'  AND lineitem.l_linenumber >  4  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_returnflag =  'A'  AND lineitem.l_orderkey >=  105723905  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE FLOOR(lineitem.l_extendedprice)  <  16573  AND lineitem.l_returnflag =  'A'  AND supplier.s_phone NOT BETWEEN  '15-640-321-8669' AND '19-294-296-4653'  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_returnflag =  'A'  AND ROUND(partsupp.ps_supplycost, 2)  >  746.04  AND supplier.s_nationkey NOT IN  ( 1, 2, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24)   OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_quantity <  36  AND lineitem.l_returnflag =  'A'  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_returnflag =  'A'  AND lineitem.l_linenumber NOT IN  ( 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 7, 7, 7)   AND lineitem.l_linestatus NOT IN  ( 'F', 'O', 'O')   AND partsupp.ps_partkey NOT IN  ( 23493775, 23493937, 23494194, 23494242, 23494256, 23494257, 23494296, 23494301, 23494308, 23494408, 23494536, 23494641)   OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_returnflag =  'A'  AND lineitem.l_shipmode LIKE  '%AIR%'  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_extendedprice <>  59347.6  AND lineitem.l_returnflag =  'A'  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  ) ,   (  SELECT  MAX(lineitem.l_comment) AS MAX__lineitem__l_comment  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey  WHERE lineitem.l_returnflag =  'A'  AND FLOOR(lineitem.l_discount)  IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   AND partsupp.ps_comment LIKE  '%%'  OR lineitem.l_partkey <  304651442  OR lineitem.l_comment =  'blithely under the ironic asymp'  OR lineitem.l_shipinstruct =  'DELIVER IN PERSON'  OR EXTRACT (MONTH FROM lineitem.l_shipdate)  =  6  )  )  and MIN(ABS(lineitem.l_tax)) >  0.03   and MIN(partsupp.ps_supplycost) between  590.2 AND 702.64   and MAX(lineitem.l_linestatus) not between  'F' AND 'O' ")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
