

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932001850 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q86")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932001850") 
val results = spark.sql ("SELECT  t1.p_name AS t1__p_name, RTRIM(t1.p_container) AS RTRIM__t1__p_container, COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey, MAX(SQRT(t1.l_tax)) AS MAX__SQRT__t1__l_tax FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey  GROUP BY  t1.p_name ,  RTRIM(t1.p_container)  HAVING   COUNT(DISTINCT t1.l_partkey) not in (  (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.l_tax <  0.04  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_mfgr =  'Manufacturer#3'  AND t1.l_discount BETWEEN  0.04 AND 0.1  AND EXTRACT (DAY FROM t1.l_shipdate)  BETWEEN  28 AND 30  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.l_tax <  0.06  AND SQRT(t1.l_suppkey)  BETWEEN  2971.79995962043 AND 3753.28109791953  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.l_returnflag <  'R'  AND t1.p_comment >=  'requests. deposits c'  AND t1.p_partkey BETWEEN  49108022 AND 49111063  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_comment <>  'ong the care'  AND t1.p_name IN  ( 'chartreuse rose hot mint green')   AND t1.l_linestatus NOT IN  ( 'F', 'F', 'F')   ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE BROUND(t1.p_retailprice, 2)  >  1954.49  AND t2.p_type NOT BETWEEN  'ECONOMY BURNISHED NICKEL' AND 'PROMO POLISHED BRASS'  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t2.p_mfgr NOT LIKE  '%1'  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.ps_partkey <>  23494411  AND LOG(10, t1.l_extendedprice)  <>  7.56414510981623  AND t2.p_mfgr BETWEEN  'Manufacturer#4' AND 'Manufacturer#5'  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.l_returnflag BETWEEN  'A' AND 'N'  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_size <  16  AND t1.p_mfgr <=  'Manufacturer#2'  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.l_shipmode <=  'SHIP'  AND t1.p_container >=  'JUMBO DRUM'  AND t2.ps_suppkey NOT IN  ( 3493880, 3494377, 3494478, 3494766, 8494002, 8494222, 8494366, 8494412, 8494705, 13493576, 13493594, 13493997, 13494207, 13494250, 13494259, 13494568, 13494731, 18493877, 18493889, 18494189, 18494407, 18494540, 18494582)   ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_container IN  ( 'JUMBO CAN', 'JUMBO DRUM', 'LG BAG', 'LG JAR', 'MED JAR', 'SM BOX', 'SM CAN', 'SM JAR', 'SM PKG', 'WRAP BAG', 'WRAP BOX', 'WRAP CAN', 'WRAP PACK', 'WRAP PKG')   AND EXTRACT (DOW FROM t1.l_shipdate)  IN  ( 1, 2, 3, 4, 4, 4, 4, 4, 5, 6, 7)   AND t1.l_comment NOT IN  ( 'arefully final fo', 'asymptotes. quickly s', 'e dependencies. de', 'e final theodolites. furiously pending d', 'endencies. blithely pendi', 'ess courts among the furiously c', 'fluffily mul', 'fully even depths are furiously: regular', 'ithely pending pinto beans grow furio', 'its according to the ironic, fin', 'ly. fluffily special deposits a', 'p carefully against the slyly special de', 'packages wake s', 'riously silent packages. pend', 'special requests. fin', 'ular, even inst', 'ully across the carefu', 'unts. special, special packages c', 'ven, ironic packages. ironic platelets', 'x fluffily bli', 'y among the carefully even dependen', 'y regular requests wake blithely special', 'y unusual theod')   ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_retailprice <=  1290.83  AND t2.p_type <>  'PROMO POLISHED STEEL'  AND t2.ps_supplycost >  765.76  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t2.p_name =  'sienna aquamarine peru lavender lawn'  AND t1.p_partkey NOT IN  ( 49107310, 49108366, 49108374, 49108636, 49108905, 49109184, 49109708, 49109993, 49110088, 49110347, 49110760, 49111043, 49111274, 49111450, 49111492, 49111546, 49111682, 49111855, 49112143)   ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.l_comment >=  'y unusual theod'  AND t1.l_suppkey IN  ( 375564, 505938, 1432566, 3979190, 4384909, 6940145, 7334335, 7491173, 8176924, 10690130, 12165170, 12546707, 14968122, 18801373)   ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t2.p_partkey <=  49109645  AND t1.l_linenumber >  1  AND t1.l_comment NOT LIKE  '% furiously pending platelets. ca'  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.l_orderkey <>  105720102  AND t1.l_returnflag <>  'R'  AND t1.p_name >=  'slate wheat beige aquamarine peach'  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.p_partkey >  49109121  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE ABS(t1.ps_availqty)  <  7586  AND t1.l_shipinstruct <=  'NONE'  AND SQRT(t1.ps_partkey)  >  4847.09490313528  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.l_comment <=  'y close deposits hagg'  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE LOG(5, t2.p_size)  <>  3.29583686600433  AND t1.ps_partkey NOT BETWEEN  23493747 AND 23493756  AND t1.ps_suppkey NOT BETWEEN  3494535 AND 13494346  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE SQRT(t1.ps_supplycost)  <  29.4587847678753  ) ,   (  SELECT  COUNT(DISTINCT t1.l_partkey) AS COUNT__DISTINCT__t1__l_partkey  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE t1.l_receiptdate IN  ( DATE'1996-02-25', DATE'1997-09-26', DATE'1998-07-27')   )  )  or MAX(SQRT(t1.l_tax)) <   (  SELECT  MAX(SQRT(t1.l_tax)) AS MAX__SQRT__t1__l_tax  FROM  (SELECT * FROM  lineitem lineitem1 INNER JOIN partsupp partsupp1 ON lineitem1.l_suppkey = partsupp1.ps_suppkey AND lineitem1.l_partkey = partsupp1.ps_partkey RIGHT JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 RIGHT JOIN (SELECT * FROM  partsupp partsupp2 INNER JOIN part part2 ON partsupp2.ps_partkey = part2.p_partkey ) t2 ON  t1.p_partkey = t2.p_partkey   WHERE FLOOR(t1.l_quantity)  <=  36  AND t2.p_type =  'MEDIUM POLISHED COPPER'  )   ORDER BY  4 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
