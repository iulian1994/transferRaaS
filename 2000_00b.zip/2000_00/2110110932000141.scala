

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110110932000141 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s2000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q4")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110110932000141") 
val results = spark.sql ("SELECT  UPPER(t2.r_comment) AS UPPER__t2__r_comment, t2.n_regionkey AS t2__n_regionkey, COUNT(t1.r_regionkey) AS COUNT__t1__r_regionkey, COUNT(t2.n_comment) AS COUNT__t2__n_comment, COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey  WHERE  t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%' GROUP BY   UPPER(t2.r_comment) , t2.n_regionkey  HAVING   COUNT(LOWER(t1.r_comment)) not in (  (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.c_name <  'Customer#075722760'  AND t2.n_comment NOT IN  ( 'hely enticingly express accounts. even, final', 'ic deposits are blithely about the carefully regular pa', 'l platelets. regular accounts x-ray: unusual, regular acco', 'nic deposits boost atop the quickly final requests? quickly regula', 'ously. final, express gifts cajole a', 'pending excuses haggle furiously deposits. pending, express pinto beans wake fluffily past t', 'refully final requests. regular, ironi', 'rns. blithely bold courts among the closely regular packages use furiously bold platelets?', 'slyly express asymptotes. regular deposits haggle slyly. carefully ironic hockey players sleep blithely. carefull', 'ss excuses cajole slyly across the packages. deposits print aroun', 'ular asymptotes are about the furious multipliers. express dependencies nag above the ironically ironic account', 'ven packages wake quickly. regu', 'y above the carefully unusual theodolites. final dugouts are quickly across the furiously regular d', 'y alongside of the pending deposits. carefully special packages are about the ironic forges. slyly special', 'y final packages. slow foxes cajole quickly. quickly silent platelets breach ironic accounts. unusual pinto be')   AND t2.n_nationkey NOT IN  ( 4, 5, 8, 9, 11, 12, 15, 17, 18, 19, 22, 23, 24)   OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.r_regionkey <=  1  AND t2.n_name NOT BETWEEN  'CANADA' AND 'GERMANY'  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t1.r_name <  'AFRICA'  AND t2.c_comment BETWEEN  'nusual asymptotes. final, regular foxes are into the unusual, ironic foxes. quickly regular packages against t' AND 'uickly according to the fluffily special excuses'  AND t2.c_phone NOT LIKE  '%7'  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.o_custkey =  145656617  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.n_nationkey NOT BETWEEN  1 AND 19  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.n_regionkey <=  4  AND t2.c_mktsegment <>  'MACHINERY'  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.c_comment IN  ( 'ages. regular, busy instructions haggle regular foxes. carefully bold theodolites wake q', 'al requests. furiously silent dependencies are blithely against the f', 'cajole furiously at the regular, special asymptotes-- blithely final theodolites cajole. unusual, ironi', 'carefully ironic dependencies haggle slyly slyly pending pint', 'cies sleep fluffily after the ironic deposits. furiously furious platelets are. quickly special ideas about th', 'e unusual deposits hinder besides the dependencies. ironic, regular instructions haggle furi', 'even packages are quickly: carefully even dolphins detect furiously according to the b', 'gside of the always ironic deposits. blithely bold dugouts according to the requests sleep carefu', 'ide of the ironic deposits cajole carefully slyly regular platelets. regular asymptotes affix carefull', 'inal, special deposits x-ray regularly. accounts are furiously. carefully ironic frays must cajole carefully', 'jole fluffily after the sheaves.', 'lent packages cajole furiously. pending, final deposits around the blithely final requests boost along the careful', 'packages after the slyly unus', 'quickly ironic pinto beans. accounts use quickly final asymptotes. furiously bold theod', 'refully regular deposits. blithely special accounts on the final, bold decoys nag furiously permanent requests.', 's above the pending requests ha', 's. slyly bold packages along the bold requests affix furiously slyly bold pack', 'ublate slyly alongside of the carefully even pinto beans. furiously furious accounts', 'uickly according to the fluffily special excuses', 'ven excuses. quickly final foxes are slyly. platelets are about the regular, ironic requests. furiou', 'xpress deposits are furiously about the ideas. slyly final dinos bel')   OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.n_name >=  'ROMANIA'  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.c_custkey >=  75724431  AND t2.n_name >=  'VIETNAM'  AND BROUND(t2.c_acctbal, 2)  NOT BETWEEN  3666.87 AND 7246.88  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.c_name <  'Customer#075724808'  AND t2.c_acctbal NOT BETWEEN  6482.47 AND 7549.57  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.o_custkey >  14690984  AND t1.r_regionkey IN  ( 0, 1, 1, 2, 2, 3, 4, 4)   OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.c_phone <=  '24-735-741-8457'  AND EXTRACT (DOW FROM t2.o_orderdate)  <=  3  AND t1.r_name NOT IN  ( 'AFRICA', 'AMERICA', 'ASIA', 'MIDDLE EAST')   OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t1.r_name BETWEEN  'AFRICA' AND 'ASIA'  AND t2.n_regionkey BETWEEN  1 AND 2  AND t2.c_address LIKE  '%Iwinb9'  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t1.r_regionkey <=  1  AND t2.c_mktsegment <=  'BUILDING'  AND t2.c_phone >=  '16-618-949-1765'  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.n_name LIKE  'IN%'  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t1.r_name <  'EUROPE'  AND t2.c_address NOT BETWEEN  'CGkxvQ85ZC0A' AND 'mKJOblfhSYrfggYxN,oStBFn5phmP95dK4iQYh8'  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.n_regionkey NOT IN  ( 0, 0, 0, 0, 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4)   OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.o_orderdate >  DATE'1992-03-15'  AND t2.n_regionkey >=  2  AND t2.c_phone IN  ( '10-718-490-4883', '11-340-153-6556', '11-361-604-2363', '11-560-903-4055', '13-626-997-9675', '16-618-949-1765', '17-492-303-4618', '22-322-929-3728', '22-821-817-8430', '23-179-789-3107', '23-243-730-9508', '23-967-842-8638', '24-735-741-8457', '25-983-223-2479', '26-407-192-7400', '26-590-920-8574', '26-915-247-3048', '27-888-975-4522', '27-926-153-4594', '30-327-800-6768', '34-214-138-5099')   OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.c_custkey <  75725528  AND t2.o_custkey <  153860972  AND SQRT(t1.r_regionkey)  NOT IN  ( 0, 0, 0, 1, 1, 1, 1, 1, 1.4142135623731, 1.4142135623731, 1.4142135623731, 1.73205080756888, 1.73205080756888, 1.73205080756888, 2, 2, 2, 2)   OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.o_orderstatus <  'O'  AND t2.c_acctbal =  4333.65  AND t2.o_custkey >  89306747  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.c_mktsegment <  'AUTOMOBILE'  AND LOG(3, t2.o_totalprice)  <>  11.7856064821068  AND t2.o_orderpriority >  '3-MEDIUM'  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.c_address <=  'tl1AaN1A10WFNyu1 yD2J4uc HfBI6iRvmLTgC'  AND t2.c_phone IN  ( '12-259-290-4356', '13-917-855-1816', '14-353-390-3807', '14-366-189-5602', '16-219-402-7587', '16-659-879-4725', '16-772-994-9308', '17-982-829-7268', '18-286-866-1124', '19-740-456-2317', '19-920-563-8739', '20-730-770-2806', '25-394-906-8830', '25-921-401-2449', '26-619-566-2409', '27-731-920-3367', '29-475-619-3022', '33-220-490-6278', '34-214-138-5099')   AND t2.o_orderdate IN  ( DATE'1992-02-11', DATE'1992-02-26', DATE'1992-04-26', DATE'1992-04-27', DATE'1992-05-17', DATE'1992-05-19', DATE'1992-06-08', DATE'1993-12-22', DATE'1994-07-03', DATE'1994-08-27', DATE'1994-09-06', DATE'1994-11-16', DATE'1994-11-29', DATE'1994-12-06', DATE'1995-01-23', DATE'1995-08-01', DATE'1995-09-24', DATE'1996-02-12', DATE'1996-02-19', DATE'1996-11-17', DATE'1997-04-25', DATE'1997-11-08', DATE'1998-03-07')   OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.c_mktsegment <  'AUTOMOBILE'  AND t2.c_comment =  'e carefully even ideas. furiously express deposits affix carefully about the ironic s'  AND FLOOR(t2.c_acctbal)  =  3140  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  ) ,   (  SELECT  COUNT(LOWER(t1.r_comment)) AS COUNT__LOWER__t1__r_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.c_address <=  ',IFKMauhWsR83EhwV3SNgbQ'  AND t1.r_name <>  'ASIA'  AND t2.r_regionkey NOT BETWEEN  2 AND 3  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  )  )  and COUNT(t2.n_comment) <=   (  SELECT  COUNT(t2.n_comment) AS COUNT__t2__n_comment  FROM  (SELECT * FROM  region ) t1 INNER JOIN (SELECT * FROM  orders orders2 INNER JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey RIGHT JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.r_regionkey = t2.r_regionkey   WHERE t2.n_comment NOT IN  ( 'al foxes promise slyly according to the regular accounts. bold requests alon', 'c dependencies. furiously express notornis sleep slyly regular accounts. ideas sleep. depos', 'eas hang ironic, silent packages. slyly regular packages are furiously over the tithes. fluffily bold', 'haggle. carefully final deposits detect slyly agai', 'hely enticingly express accounts. even, final', 'l platelets. regular accounts x-ray: unusual, regular acco', 'pending excuses haggle furiously deposits. pending, express pinto beans wake fluffily past t', 'rns. blithely bold courts among the closely regular packages use furiously bold platelets?', 's. ironic, unusual asymptotes wake blithely r', 'ss excuses cajole slyly across the packages. deposits print aroun', 'ts. silent requests haggle. closely express packages sleep across the blithely', 'ular asymptotes are about the furious multipliers. express dependencies nag above the ironically ironic account')   AND t2.c_comment NOT LIKE  'e regular, regular requests wa%'  OR t2.o_orderkey <=  72192295  OR t2.c_nationkey <>  20  OR t2.o_comment <>  'oxes believe furiously. carefu'  OR t1.r_comment NOT LIKE  'lar de%'  )   ORDER BY  2 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
