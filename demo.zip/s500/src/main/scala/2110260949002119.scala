

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949002119 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q86")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949002119") 
val results = spark.sql ("SELECT  UPPER(nation.n_name) AS UPPER__nation__n_name, supplier.s_phone AS supplier__s_phone, COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey WHERE  FLOOR(supplier.s_acctbal)  <  697 GROUP BY   UPPER(nation.n_name) , supplier.s_phone  HAVING   COUNT(nation.n_nationkey) in (  (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND supplier.s_address IN  ( '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000', '0000000000')   AND supplier.s_phone LIKE  '%90-6785'  ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND nation.n_comment <>  's. decoys detect carefully across the regular accounts. pinto beans across the'  AND supplier.s_suppkey >=  1539932  AND supplier.s_address NOT BETWEEN  '0000000000' AND '0000000000'  ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND supplier.s_address <=  '0000000000'  AND supplier.s_nationkey >  5  AND supplier.s_comment LIKE  '%kly enticing'  ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE supplier.s_address <  '0000000000'  AND FLOOR(supplier.s_acctbal)  <  697  AND SQRT(nation.n_regionkey)  =  2  AND nation.n_nationkey >=  3  ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND nation.n_comment =  'regular accounts against the slyly silent dependencies nag along the carefully slow foxes. daringly expre'  AND supplier.s_name IN  ( 'Supplier#000215439       ', 'Supplier#000447154       ', 'Supplier#002169165       ', 'Supplier#002400967       ', 'Supplier#004122552       ', 'Supplier#004122582       ')   ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND supplier.s_nationkey <>  9  AND supplier.s_address =  '0000000000'  ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND supplier.s_name >  'Supplier#002400958       '  AND nation.n_nationkey BETWEEN  13 AND 15  AND nation.n_comment LIKE  'st. silent, i%'  ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND supplier.s_phone <=  '22-211-354-2915'  AND nation.n_regionkey >=  2  ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND supplier.s_suppkey =  4122560  ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND supplier.s_phone <=  '16-156-653-6326'  AND supplier.s_name =  'Supplier#003493461       '  AND supplier.s_address NOT BETWEEN  '0000000000' AND '0000000000'  ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE supplier.s_suppkey <  1539956  AND FLOOR(supplier.s_acctbal)  <  697  AND supplier.s_address =  '0000000000'  AND supplier.s_comment IN  ( ' carefully blithe accounts above the ironic packages nag furiously after the furiously expr', 'al deposits are above the slyly final deposits. slyly even packages cajole along the fina', 'ckly slyly bold pinto bea', 'eans. final deposits doubt about the regular dependencie', 'ely special pinto beans. bold pinto beans along the bold dolphins do wake above the furiously carefu', 'equests: slyly final accounts nag. furiously i', 'es. theodolites sleep blithely regular theodolites. packages according to the carefully', 'even pinto beans. quickly regular excuses above the instructions promise carefully rut', 'hroughout the ironic excuses-- bold', 'le besides the instructions. closely permanent accounts b', 'ly blithely pending deposits. special, final deposits', 'onic deposits use against ', 'pecial deposits haggle. quickly unusual asymptotes sleep. ironic theodolites sleep s', 'riously unusual hockey players. carefully silent deposits poach fluffily ruthless waters. ironi', 's wake blithely ironic requests. pending, furious accounts are s', 'sits. permanently even instructions doubt. unu', 'to beans haggle slyly alongside of the carefully regular frays. final ideas use regular, ironic ', 'ts cajole ironically among the ironic excuses. carefully iro', 'ully regular ideas-- quickly unusual requests sleep furiously among the', 'unts impress idly against the theodolites. furio', 'y. ideas nod carefully. regular orbits wake f')   ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND supplier.s_phone NOT IN  ( '10-869-626-8898', '20-573-888-2643', '23-441-808-1991', '30-454-132-6535', '32-986-926-6501')   ) ,   (  SELECT  COUNT(nation.n_nationkey) AS COUNT__nation__n_nationkey  FROM  supplier INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey  WHERE FLOOR(supplier.s_acctbal)  <  697  AND nation.n_comment <=  'wake quickly. unusual theodolites integrate quick'  AND nation.n_nationkey <>  24  )  )")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
