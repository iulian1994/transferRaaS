

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949000421 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q15")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949000421") 
val results = spark.sql ("SELECT  region.r_name AS region__r_name, MIN(UPPER(customer.c_comment)) AS MIN__UPPER__customer__c_comment, MIN(SUBSTR(nation.n_comment, 14, 228)) AS MIN__SUBSTR__nation__n_comment__14__228, MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey WHERE  customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)  GROUP BY  region.r_name  HAVING   MIN(SUBSTR(nation.n_comment, 14, 228)) in ( ' carefully final excuses? foxes alongside of the deposits c', ' ideas. pending accounts sublate blithely. furiously re', ' unusual theodolites integrate quick', 'arefully depths. carefully ironic theodolites shall cajole: carefully ironic theodolites are careful', 'arefully unusual deposits! instructions serve slyly. ', 'bove the furiously final accounts are carefully across the unusual packages-- quickly ', 'ding to the carefully ironic accounts. furiously f', 'ect carefully across the regular accounts. pinto beans across the', 'ffily special, fin', 'haggle carefully above the ideas.', 'hely ironic pin', 'heodolites affix against the slyly eve', 'lar ideas. express, unusual requests nag slyly eve', 'le blithely about the ironic, final packages. deposits cajole carefully.', 'lites. carefully express pinto beans sleep. blit', 'nts against the slyly silent dependencies nag along the carefully slow foxes. daringly expre', 'packages cajole furiously carefully regular depos', 'requests. quickly ironic realms boost around the ironic, ironi', 'ress, final courts nod bravely slyly regular foxes. even deposits sleep quie', 'ronic packages nag. dogg', 'ully regular deposits sleep blith', 'y around the ironic, ironic packages. final, silent foxes are blithe', 'y ironic theodolites across the furiously regular theodoli' )  and MIN(UPPER(customer.c_comment)) in ( ' CAREFULLY FINAL DOLPHINS. BLITHELY EXPRESS TIRESIAS HAGGLE FURIOUSLY BUSY FOXES? CAREFULLY IRONIC EXCUSES CA', ' IDEAS USE SLYLY. FURIOUSLY SPECIAL DEPOSITS HAGGLE NEVER. DEPOSITS WA', 'ARE ALONG THE CAREFULLY IRONIC GROUCHES. EVEN COURTS NAG FURIOUSLY ALONG THE PENDING PATTERNS. FURIOUSLY EX', 'DEPOSITS. SLYLY SPECIAL PACKAGES GROW ACROSS THE SLYLY EVEN REQUESTS. REGULAR, REGULAR ASYMPTOTES THRASH. FINAL PL', 'DOLPHINS HAGGLE FURIOUSLY ACCORDING TO', 'ES. FURIOUSLY FINAL IDEAS INTEGRATE. QUICKLY SPECIAL DECOYS ARE IDEAS. DEPOSITS', 'EXCUSES SLEEP BLITHELY. FLUFFILY BOLD DEPOSI', 'FINAL PINTO BEANS. EXCUSES WAKE CAREFULLY AMONG THE QUICK', 'NS X-RAY SLYLY UNUSUAL DEPOSITS. SLYLY SILENT EPITAPHS CAJOLE BLITHELY. FLUFFILY REGULAR PACKAGES CAJO', 'OLE ACCORDING TO THE REGULAR, SILENT REQUESTS. CAREFULLY REGULAR ACCOUNT', 'PENDING DEPOSITS ABOUT THE PENDING, SPE', 'S. QUICKLY FINAL PACKAGES SLEEP: IRONIC, SPECIAL FOXES UNDER THE FLUFFY FOXES U', 'SLY IRONIC ACCOUNTS. BOLD, RUTHLESS PACKAGES ARE AC', 'UNUSUAL DEPOSITS-- FURIOUSLY QUICK TITHES WAKE FURIOUSLY', 'UNUSUAL PACKAGES SLEEP CAREFULLY SPECIAL DEPENDENCIES. FURIOUS', 'URTS. CAREFULLY IRONIC REQUESTS ' )  and MIN(customer.c_mktsegment) not in (  (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   AND nation.n_comment NOT LIKE  '%carefully final excuses? foxes alongside of %'  OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE customer.c_acctbal >=  9546.89  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   AND nation.n_name NOT IN  ( 'ARGENTINA                ', 'CANADA                   ', 'FRANCE                   ', 'IRAN                     ', 'IRAQ                     ', 'JAPAN                    ', 'KENYA                    ', 'RUSSIA                   ', 'UNITED STATES            ')   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE customer.c_comment >  'iously. blithely even platelets around the bli'  AND BROUND(customer.c_acctbal, 1)  BETWEEN  2360.3 AND 8597.5  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   AND nation.n_name NOT BETWEEN  'IRAQ                     ' AND 'UNITED STATES            '  OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE orders.o_shippriority <=  0  AND nation.n_name >  'BRAZIL                   '  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE customer.c_acctbal <  6319.95  AND customer.c_mktsegment =  'HOUSEHOLD '  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   AND nation.n_comment NOT BETWEEN  'regular accounts against the slyly silent dependencies nag along the carefully slow foxes. daringly expre' AND 'ully final deposits sleep fluffily. quickly regular braids are furiously slyly'  OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE customer.c_mktsegment <=  'FURNITURE '  AND customer.c_comment <>  'along the even requests cajole slyly slyly even multipliers. quickly bold deposits aga'  AND nation.n_regionkey >  4  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE nation.n_name <  'INDIA                    '  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   AND region.r_comment IN  ( 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg')   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE SQRT(nation.n_regionkey)  <  2  AND orders.o_orderpriority =  '4-NOT SPECIFIED'  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   AND LOG(6, customer.c_custkey)  NOT IN  ( 15.3742998102948, 15.3743040180988, 16.2970900957149, 16.5168990188666, 16.5169000926623, 16.5169004953354, 16.7686318940433, 17.1934970387589, 17.1934975163839, 17.413302812926, 17.5934115506719, 17.5934115735425, 17.745951251711, 17.8782936731564, 17.9951343242192, 17.9951343854362, 18.099742056636, 18.0997421393413, 18.0997425252991)   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE nation.n_regionkey <  3  AND customer.c_nationkey <=  0  AND customer.c_address BETWEEN  'k5qBbpoAbj,I 57E6BI8g4mMYc1Rp' AND 'P5mYsOifPM,MgsdGK'  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   AND orders.o_orderpriority LIKE  '5-%'  OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE ROUND(customer.c_acctbal, 2)  <=  6586.53  AND region.r_name <>  'AFRICA                   '  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE nation.n_name <  'UNITED KINGDOM           '  AND orders.o_comment <>  'furiously special f'  AND orders.o_orderkey =  1365577861  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE orders.o_orderkey <=  490777409  AND orders.o_orderpriority >  '4-NOT SPECIFIED'  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   AND region.r_name NOT BETWEEN  'AMERICA                  ' AND 'MIDDLE EAST              '  OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE orders.o_comment =  'furiously special f'  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   AND customer.c_mktsegment NOT BETWEEN  'AUTOMOBILE' AND 'FURNITURE '  AND orders.o_orderdate NOT IN  ( DATE'1992-04-03', DATE'1992-08-12', DATE'1992-09-16', DATE'1992-12-21', DATE'1993-06-22', DATE'1993-06-25', DATE'1993-08-20', DATE'1993-09-30', DATE'1994-03-03', DATE'1994-07-05', DATE'1994-07-07', DATE'1994-08-19', DATE'1994-10-07', DATE'1995-02-04', DATE'1995-05-18', DATE'1995-06-30', DATE'1995-09-06', DATE'1995-10-15', DATE'1996-05-30', DATE'1996-06-05', DATE'1996-06-06', DATE'1996-10-20', DATE'1997-04-12', DATE'1997-05-11', DATE'1998-01-01')   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   ) ,   (  SELECT  MIN(customer.c_mktsegment) AS MIN__customer__c_mktsegment  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE orders.o_shippriority <=  0  AND customer.c_nationkey =  0  AND customer.c_phone IN  ( '10-426-193-6204', '10-611-868-8636')   AND customer.c_address NOT IN  ( '7viPG V yLWwcc8tOnFVKU8hdhVITfm', '9dvNZILMwXZJFG33wiz0nJpfOzXqHh2Ee', 'CQGnyGk8UUHrHT9', 'E5WzBOt5Nzc2jUQB', 'EZxk2t27CtQ3iE', 'Hq7BetOKAWDWLHQgLUAZ OGxjIn', 'l32OCaeSva2OyuQlU44DI8Fx6dD', 'MZPx0EOcwOnVc3dc2JO3QxZY26DzKxiZNPf960', 'SNHhmDLsa2emx66tXdvqqjW6XS8A,ZtxUMF9', 'UT0WCmfrBV2coW0QvYcEfAJEaplL7keZ,A', 'X6,,sMJQlCZf9hohh,jZV3fcOMm87iJ,g', 'XIAGaTRZYXCyV5Ujukg0OcuLYvwNa49NJl', 'xrNn3rSjXrv9Z4WwuFsmYcHm1FBWMIWRxrjexq', 'YGOSzbzoBkn1UTGMlj6EA4R0RMTESnfRRooA8pGC')   OR ABS(orders.o_totalprice)  IN  ( 13962.44, 26122.42, 38053.34, 62586.91, 82381.52, 98387.46, 136310.22, 136871.97, 140538.3, 153288.71, 257325.86, 264925.06, 335434.16)   )  ) ORDER BY  4 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
