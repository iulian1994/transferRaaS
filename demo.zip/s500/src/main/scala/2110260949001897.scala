

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949001897 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q71")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949001897") 
val results = spark.sql ("SELECT  region.r_name AS region__r_name, region.r_regionkey AS region__r_regionkey, MIN(lineitem.l_linenumber) AS MIN__lineitem__l_linenumber, MIN(partsupp.ps_partkey) AS MIN__partsupp__ps_partkey, MIN(supplier.s_suppkey) AS MIN__supplier__s_suppkey, MIN(lineitem.l_partkey) AS MIN__lineitem__l_partkey, MIN(EXTRACT (YEAR FROM lineitem.l_commitdate)) AS MIN__EXTRACT____YEAR__FROM__lineitem__l_commitdate, MIN(EXTRACT (MONTH FROM lineitem.l_commitdate)) AS MIN__EXTRACT____MONTH__FROM__lineitem__l_commitdate, MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey WHERE  lineitem.l_orderkey <  1307542084  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5 GROUP BY  region.r_name , region.r_regionkey  HAVING   MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) in (  (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND partsupp.ps_supplycost BETWEEN  22.38 AND 175.31  AND supplier.s_comment LIKE  '%inal accounts nag quickly. carefull'  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND region.r_comment >  'furiously special foxes hagg'  AND nation.n_name NOT BETWEEN  'GERMANY                  ' AND 'MOROCCO                  '  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND lineitem.l_suppkey <  2526625  AND partsupp.ps_partkey >=  95157468  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  AND lineitem.l_linenumber NOT IN  ( 1, 1, 2, 2, 4, 5, 5, 6, 6, 6, 6, 7)   OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND lineitem.l_shipdate <  DATE'1995-05-25'  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND lineitem.l_shipinstruct =  'DELIVER IN PERSON        '  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  AND supplier.s_comment NOT LIKE  'eans. fina%'  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND lineitem.l_discount <>  0.03  AND supplier.s_phone =  '31-299-356-6428'  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND nation.n_comment <=  'round the express, final courts nod bravely slyly regular foxes. even deposits sleep quie'  AND nation.n_regionkey IN  ( 0, 0, 1, 1, 2, 2, 2, 3, 4, 4, 4, 4, 4)   AND partsupp.ps_comment LIKE  'iously pending requests wake quietly along the unusual, ex%'  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND partsupp.ps_partkey =  47062573  AND ROUND(supplier.s_acctbal, 1)  BETWEEN  1464.8 AND 6691.5  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  AND lineitem.l_partkey NOT IN  ( 5006373, 20293550, 24532314, 47548456, 54237062, 64256800, 65259651, 77695616, 83704195, 85017198, 85803720, 87926465, 96479483)   OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND EXTRACT (DAY FROM lineitem.l_shipdate)  >=  28  AND lineitem.l_suppkey NOT BETWEEN  4662272 AND 4767924  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND partsupp.ps_supplycost <=  537.64  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND nation.n_name <  'UNITED STATES            '  AND supplier.s_phone <=  '11-710-132-9051'  AND lineitem.l_shipmode =  'MAIL      '  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND nation.n_regionkey BETWEEN  0 AND 1  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND lineitem.l_returnflag <  'R'  AND supplier.s_phone =  '31-271-814-4049'  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  AND nation.n_regionkey NOT IN  ( 1, 2, 2, 3, 3, 3, 3, 4, 4)   OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND supplier.s_phone <>  '19-730-914-8356'  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND ROUND(lineitem.l_discount, 0)  <>  0  AND region.r_regionkey >  4  AND region.r_name BETWEEN  'AFRICA                   ' AND 'ASIA                     '  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND nation.n_comment <>  'ke even, regular ideas. express, unusual requests nag slyly eve'  AND lineitem.l_quantity >=  50  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND lineitem.l_suppkey =  870471  AND region.r_name >  'MIDDLE EAST              '  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND supplier.s_phone <=  '24-483-863-7232'  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND region.r_comment >=  'furiously special foxes hagg'  AND region.r_regionkey >=  3  AND lineitem.l_comment BETWEEN  'even accoun' AND 'ites are am'  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  ) ,   (  SELECT  MIN(EXTRACT (DAY FROM lineitem.l_commitdate)) AS MIN__EXTRACT____DAY__FROM__lineitem__l_commitdate  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND supplier.s_suppkey <  2169205  AND nation.n_nationkey =  18  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  )  )  or MIN(supplier.s_suppkey) =  2400975   or MIN(EXTRACT (MONTH FROM lineitem.l_commitdate)) <  3   or MIN(partsupp.ps_partkey) >   (  SELECT  MIN(partsupp.ps_partkey) AS MIN__partsupp__ps_partkey  FROM  lineitem INNER JOIN partsupp ON lineitem.l_suppkey = partsupp.ps_suppkey AND lineitem.l_partkey = partsupp.ps_partkey INNER JOIN supplier ON partsupp.ps_suppkey = supplier.s_suppkey INNER JOIN nation ON supplier.s_nationkey = nation.n_nationkey INNER JOIN region ON nation.n_regionkey = region.r_regionkey  WHERE lineitem.l_orderkey <  1307542084  AND supplier.s_phone <  '11-485-845-7931'  AND region.r_name <>  'EUROPE                   '  AND FLOOR(partsupp.ps_availqty)  NOT BETWEEN  1 AND 1  OR partsupp.ps_suppkey <=  2540777  OR lineitem.l_receiptdate <>  DATE'1995-06-12'  OR lineitem.l_extendedprice NOT BETWEEN  24626.28 AND 52990.5  )    or MIN(EXTRACT (YEAR FROM lineitem.l_commitdate)) in ( 1992, 1994, 1998 ) ORDER BY  5 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
