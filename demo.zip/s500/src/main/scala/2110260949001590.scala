

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949001590 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q61")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949001590") 
val results = spark.sql ("SELECT  t1.p_mfgr AS t1__p_mfgr, LOWER(t1.p_comment) AS LOWER__t1__p_comment, LTRIM(t2.ps_comment) AS LTRIM__t2__ps_comment, SUBSTR(t1.p_name, 7, 80) AS SUBSTR__t1__p_name__7__80, t1.p_partkey AS t1__p_partkey, MAX(RTRIM(t1.p_type)) AS MAX__RTRIM__t1__p_type, MIN(t2.s_acctbal) AS MIN__t2__s_acctbal FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey  WHERE  t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09' GROUP BY  t1.p_mfgr ,  LOWER(t1.p_comment) ,  LTRIM(t2.ps_comment) ,  SUBSTR(t1.p_name, 7, 80) , t1.p_partkey  HAVING   MAX(RTRIM(t1.p_type)) not in ( 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN', 'STANDARD ANODIZED TIN' )  and MIN(t2.s_acctbal) in (  (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.s_name =  'Supplier#002169194       '  AND t2.l_tax >  0.04  AND t2.l_partkey IN  ( 2672560, 6678466, 10861055, 12493290, 20392716, 24532314, 31609355, 37578135, 57632552, 57796279, 60770615, 66592893, 73591702, 73785212, 74020549, 97894913)   AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t2.s_suppkey NOT IN  ( 215397, 1308123, 1308128, 1308138, 2169166, 2169177, 2169188, 2169202, 3261769, 3493444, 3493447, 3493462, 3493469, 3493474, 4122573, 4122581, 4354317, 4354354, 4586165, 4586168)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND SQRT(t1.ps_suppkey)  BETWEEN  1612.2136955131 AND 2080.32665704211  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t2.l_suppkey NOT IN  ( 1015597, 1544946, 2320503, 2574512, 4440444, 4931838)   AND t2.ps_comment NOT IN  ( ' across the furiously even requests. blithely regular excuses doubt against the blithely regular deposits. foxes sleep packages. regular theodolites use. carefully regular theodolites cajole sly', '! furiously regular requests haggle furiously among the regular dolphins. furiously final requests sleep blithely about the furiously bold packages. unusual ideas h', 'ackages: boldly ironic warhorses are special deposits. unusual, regular dugouts hinder blithely. furiously final deposits wake quickly against the quickly ironi', 'after the slyly final requests. blithely regular ideas wake slyly dolphins. ', 'ake blithely furiously final warhorses. blithely silent packages alongside of the slyly unusual somas sleep abov', 'are. final instructions are. platelets doubt quickly after the carefully pending epitaphs. furiously special dolphins above the furiously regular requests engage carefully ironic, ', 'e special accounts. fluffily ironic foxes will are blithely regular deposits. carefully regular packages could have to ', 'es. carefully final packages cajole fluffily even theodolites. platelets haggle blithely even accounts. carefully regular theodolites wake slyly bold warhorses. carefully silent theodolites nag sl', 'final instructions haggle final pinto beans. slyly final theodolites wake ', 'foxes boost even accounts. carefully blithe theodo', 'ges wake blithely. express, pending excuses sleep quiet dependencies. blithely regular packages wake. permanently ironic warthogs nag slyly regular packages. final instructions cajole blith', 'lly regular foxes wake furiously: even deposits wake across the slyly regular requests. fluffily regular dinos affix at the', 'ns. furiously regular deposits cajole. even requests around the ironic, special deposits sleep final, ironic instructions. fluffil', 'ously carefully regular packages: furiously bold asymptotes alongside of the instr', 'out the carefully regular courts. blithely dogged foxes impress carefully. sometimes final deposits nag carefully. regular accounts cajole ironic accounts! f', 's are carefully unusual, final deposits-- carefully ironic deposits integrate above the blithely even packages. unusual deposits alongside of the unusual requests caj', 'slyly bold deposits haggle furiously above the furiously unusual excuses. pending, special packages sleep slyly. blithely iro', 'thely bold instructions. regularly final theodolites integrate across the blithely regular foxes. blithely special pinto beans after the stealthil', 'uffily slyly ironic accounts. furiously regular asymptotes haggle blithely quickly bold foxes. express packages are slyly after the fluffily special platelets. slyly regular excuses sle', 'y accounts. furiously ironic requests sleep. carefully regular accounts haggle furiou', 'y final instructions. slyly pending ideas beside the furiously regular deposits haggle against the blithely ironic packages. packages cajole. orbits haggle slyly around ', 'y ironic packages. always regular requests shall have to haggle. carefully ironic deposits above the slyly regular pi')   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND BROUND(t2.l_extendedprice, 3)  >=  47352.97  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t2.s_address LIKE  '0000%'  AND t1.p_container NOT LIKE  '% PACK   '  OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t2.l_shipmode NOT LIKE  '%AIR       %'  OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.ps_comment <>  ' regular accounts around the quick asymptotes are furiously bold asymptotes. final dolphins wake sly'  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t2.l_shipinstruct NOT LIKE  '%%'  OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE SQRT(t2.l_linenumber)  <=  1  AND t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t2.l_shipinstruct NOT BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t2.s_nationkey <=  14  AND t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND t2.l_partkey BETWEEN  55071316 AND 90508042  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t1.p_mfgr =  'Manufacturer#3           '  AND t2.l_tax >  0.04  AND t2.s_acctbal IN  ( -495.47, 959.11, 3057.99, 3306.58, 3431.99, 3740.99, 4262.46, 4273.65, 4355.36, 5872.71, 6337.56, 6435.74, 7684.69, 8120.2, 9383.28)   AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t1.ps_suppkey =  1886297  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND SQRT(t2.l_discount)  >  0.316227766016838  AND t2.s_nationkey IN  ( 0, 1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 24)   AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t2.l_suppkey <=  799321  AND t1.ps_partkey <>  76114815  AND t1.p_retailprice =  1287.83  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND t1.ps_availqty >=  1  AND t2.s_phone BETWEEN  '17-996-806-5890' AND '23-842-745-7051'  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t1.p_name NOT LIKE  '%arine azure beige'  OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.p_retailprice <=  1061.19  AND t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t1.ps_availqty =  1  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND t1.p_brand >=  'Brand#55  '  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.s_phone <>  '17-828-434-7924'  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t2.l_orderkey NOT IN  ( 993114214, 993114241, 993114242, 993114244, 1071725473, 1071725504, 1071725508, 1150334592, 1150334594, 1150334595, 1150334597, 1150334624, 1228932384, 1228932389, 1228932390, 1228932420, 1307542050, 1307542054, 1307542080)   AND ABS(t1.ps_supplycost)  NOT IN  ( 17.65, 187.54, 202.56, 219.54, 232.81, 269.38, 291.32, 374.87, 405.02, 537.64, 552.94, 561.38, 690.32, 773.37, 778.67, 849.45, 956.94)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND t2.s_nationkey >=  22  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t1.p_mfgr =  'Manufacturer#2           '  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.l_partkey =  83396087  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND ROUND(t2.l_discount, 3)  =  0.03  AND t2.l_tax >  0.04  AND t1.ps_comment >=  'l deposits across the slyly express deposits haggle along the furiously final requests. boldly even deposits use furiously even foxes; carefully pending packages are fluf'  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t2.l_linestatus NOT BETWEEN  'F' AND 'O'  OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t2.s_comment NOT IN  ( ' quickly bold instructions. boldly bold depos', 'es. slyly unusual packages haggle fluffily. ironic, ironic excus', 'fully unusual pinto beans aff', 'ously silent requests. even deposits across the furiously special packa', 'ully regular requests cajole carefully. blithely pending accounts hinder alongside of t')   OR t2.l_receiptdate =  DATE'1993-03-09'  ) ,   (  SELECT  MIN(t2.s_acctbal) AS MIN__t2__s_acctbal  FROM  (SELECT * FROM  partsupp partsupp1 INNER JOIN part part1 ON partsupp1.ps_partkey = part1.p_partkey ) t1 LEFT JOIN (SELECT * FROM  lineitem lineitem2 RIGHT JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey INNER JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.ps_partkey = t2.ps_partkey AND t1.ps_suppkey = t2.ps_suppkey   WHERE t1.ps_partkey <>  76114815  AND t2.l_tax >  0.04  AND FLOOR(t2.s_acctbal)  >  9935  AND t2.l_linenumber BETWEEN  1 AND 7  AND BROUND(t2.ps_supplycost, 0)  IN  ( 224, 400, 479, 695)   AND t1.p_mfgr NOT IN  ( 'Manufacturer#1           ', 'Manufacturer#1           ', 'Manufacturer#1           ', 'Manufacturer#1           ', 'Manufacturer#1           ', 'Manufacturer#1           ', 'Manufacturer#1           ', 'Manufacturer#1           ', 'Manufacturer#1           ', 'Manufacturer#3           ', 'Manufacturer#4           ', 'Manufacturer#4           ', 'Manufacturer#4           ', 'Manufacturer#4           ', 'Manufacturer#4           ', 'Manufacturer#4           ', 'Manufacturer#5           ', 'Manufacturer#5           ', 'Manufacturer#5           ', 'Manufacturer#5           ')   OR t2.l_receiptdate =  DATE'1993-03-09'  )  ) ORDER BY  7 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
