

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949002598 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q102")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949002598") 
val results = spark.sql ("SELECT  t2.r_name AS t2__r_name, t2.n_comment AS t2__n_comment, MAX(EXTRACT (YEAR FROM t2.o_orderdate)) AS MAX__EXTRACT____YEAR__FROM__t2__o_orderdate, MAX(EXTRACT (MONTH FROM t2.o_orderdate)) AS MAX__EXTRACT____MONTH__FROM__t2__o_orderdate, COUNT(DISTINCT t2.c_acctbal) AS COUNT__DISTINCT__t2__c_acctbal, COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey  GROUP BY  t2.r_name , t2.n_comment  HAVING   COUNT(DISTINCT t2.o_totalprice) in (  (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.n_nationkey >  21  AND t2.c_phone LIKE  '%8'  AND t2.o_shippriority NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_orderpriority NOT BETWEEN  '1-URGENT       ' AND '5-LOW          '  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_custkey <>  11473228  AND t2.c_comment IN  ( ' fluffily among the carefully bold accounts. blithely even requests wake carefully. asymptotes nag sile', '. packages sleep fluffily. slyly regular excuses wake. express, special pinto bean', 'ithely pending requests cajole above the carefully ironic courts. pending accounts about the even, express a', 'lar requests. carefully regular waters aroun', 'lly theodolites? ironic theodolites haggle blithely about t', 'ly? even requests haggle furiously. quickly express requests integrate against the carefull', 'lyly. deposits haggle against the special pl', 'nding packages affix quickly carefully ironic requests. f', 'o the deposits sublate blithely qui', 'rint fluffily according to the requests. express', 's the blithely unusual accounts. bold, unusual deposits detec', 'y express accounts will have to integrate. furiousl', 'yly unusual deposits. quickly bold requests use quickly. slyly regular requests cajole furiously. ironic ')   AND t2.r_comment IN  ( 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg', 'furiously special foxes hagg')   ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_shippriority <=  0  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.n_regionkey <  1  AND t2.c_acctbal <=  4920.75  AND t2.c_comment IN  ( ' foxes. ironic foxes are furiously after the careful pac', ' slyly even foxes. final accounts around the bol', '. carefully bold accounts nag about the express requests. carefully even packages sleep furiously-- busy ideas', 'cording to the final asymptotes. foxes de', 'd accounts. carefully bold epitaphs nag according to the slyly unusual instructions. furiously pending platelets h', 'des since the blithely ironic pack', 'e carefully special requests. accounts are after the ironic, final packages', 'e theodolites. unusual packages cajole furiously. furiously ironic deposits cajole furiously', 'g deposits are. brave ideas cajole. carefully regular accounts aga', 'ggle quickly. fluffily even pinto beans cajole quickly exp', 'ncies. thinly final requests against the slyly pending foxes are final ideas! even, express packages haggle slyly. ', 'ns: theodolites are furiously along the carefully ironic packages. slyly final sheaves ag', 's the carefully special deposits? carefully even pack', 'slyly even packages haggle ironically furious requests; stealthily ironic packages was. expre', 'usly unusual accounts. slyly regular requests against the ironic packages ought to use ironic instru')   ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_comment <  'furiously special f'  AND t2.c_name >  'Customer#022106021'  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE EXTRACT (DOW FROM t1.o_orderdate)  >  7  AND t2.o_orderkey BETWEEN  490777508 AND 782377504  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.r_comment <=  'furiously special foxes hagg'  AND t1.o_custkey NOT IN  ( 7825348, 7966012, 9623410, 13511287, 13742008, 16518244, 16773095, 24483100, 36686056, 37176949, 43876175, 50428586, 54429145, 71363792)   AND t2.c_address NOT IN  ( '0oHPNZciMGi4bzrc8gKM4Fl', '1GM fZHjL2Qc26sEDQGPu', '1lYlcEfosqE7', '1myJL,Y0Ycn,h9Gf6ljipKm9ibLQNmT0V11EI', '9aohXRUevS9,Q2GwEnKSgZgGTKcbREUpVR', 'AcuDmHOShulvzmCfhS1kX', 'aQrJ3spyenrP4GFq', 'bxG9Dvrh36IK4m', 'CFg07yKxoljN75sBe', 'Fyfk5dbkY6Vd8Yfu', 'GJOmTyeAFIPp8m9hOJTiwllaL1', 'KEB1U2 ndkpKQB2,cHFA4W2ZIt', 'KFOlYUjpOEUHOWScsh6Wh91eHvzAelR66', 'Ld2slDtA9Q8', 'Lgw9D1UbSnhzDjtcZ3Ze', 'MFEgtivqJ,qKcJQM,PjSK7j2T0PhGzUMIi', 'mKRX5k39bLJo4RYDjSU1HFZF2H7TJ TWEj', 'oJc8fnX 5NvvBDmKIik0Hb Zgm', 'qK4rFiAVUGsIh7RN,NWL 4bdC5nqmPR6w EUw', 'QzUGd5cJo3ITz9h0eX', 'uD8IXynWQLl,tUxKyuNVY', 'uspxFeu2xDn', 'UTQtKQuJN5AQ', 'wz4xJl14OJxeT zwZDEEmkN7R99XJR', 'xrNn3rSjXrv9Z4WwuFsmYcHm1FBWMIWRxrjexq')   ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.c_address <>  'VtrFcJY6jqHI'  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.n_regionkey <=  4  AND t2.n_comment BETWEEN  'ctions would haggle carefully above the ideas.' AND 'regular accounts against the slyly silent dependencies nag along the carefully slow foxes. daringly expre'  AND t1.o_orderpriority IN  ( '1-URGENT       ', '2-HIGH         ', '5-LOW          ')   ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.c_nationkey <>  0  AND t1.o_clerk =  'Clerk#000434623'  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.c_mktsegment <=  'BUILDING  '  AND t1.o_shippriority >=  0  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t1.o_orderstatus =  'F'  AND t2.c_phone =  '10-504-563-4725'  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_orderstatus <  'F'  AND t1.o_orderstatus >=  'P'  AND EXTRACT (DAY FROM t1.o_orderdate)  NOT BETWEEN  9 AND 21  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.r_name IN  ( 'AFRICA                   ', 'AFRICA                   ', 'AFRICA                   ', 'AFRICA                   ', 'AFRICA                   ', 'AFRICA                   ', 'AMERICA                  ', 'AMERICA                  ', 'AMERICA                  ', 'ASIA                     ', 'ASIA                     ', 'ASIA                     ', 'ASIA                     ', 'ASIA                     ', 'EUROPE                   ', 'EUROPE                   ', 'EUROPE                   ', 'EUROPE                   ', 'EUROPE                   ', 'EUROPE                   ', 'EUROPE                   ', 'MIDDLE EAST              ', 'MIDDLE EAST              ', 'MIDDLE EAST              ', 'MIDDLE EAST              ')   AND t2.o_clerk LIKE  'Clerk#%'  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t2.o_custkey <=  24348647  AND t2.c_acctbal BETWEEN  3045.81 AND 6368.97  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE t1.o_clerk NOT IN  ( 'Clerk#000069799', 'Clerk#000078094', 'Clerk#000127747', 'Clerk#000153496', 'Clerk#000161965', 'Clerk#000163082', 'Clerk#000165900', 'Clerk#000203573', 'Clerk#000206179', 'Clerk#000231914', 'Clerk#000303509', 'Clerk#000339881', 'Clerk#000349025', 'Clerk#000383906')   AND t2.c_address NOT LIKE  '%yewrv9IcDKs6QuAv'  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE EXTRACT (DAY FROM t1.o_orderdate)  <>  15  AND SQRT(t2.n_regionkey)  >=  2  ) ,   (  SELECT  COUNT(DISTINCT t2.o_totalprice) AS COUNT__DISTINCT__t2__o_totalprice  FROM  (SELECT * FROM  orders ) t1 FULL JOIN (SELECT * FROM  orders orders2 RIGHT JOIN customer customer2 ON orders2.o_custkey = customer2.c_custkey INNER JOIN nation nation2 ON customer2.c_nationkey = nation2.n_nationkey INNER JOIN region region2 ON nation2.n_regionkey = region2.r_regionkey ) t2 ON  t1.o_orderkey = t2.o_orderkey   WHERE SQRT(t2.r_regionkey)  <  1.4142135623731  AND t1.o_orderpriority NOT IN  ( '1-URGENT       ')   )  )  and MAX(EXTRACT (MONTH FROM t2.o_orderdate)) >=  3  ORDER BY  3 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
