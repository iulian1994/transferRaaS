

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949002056 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q81")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949002056") 
val results = spark.sql ("SELECT  SUBSTR(t2.s_comment, 15, 187) AS SUBSTR__t2__s_comment__15__187, t1.o_orderdate AS t1__o_orderdate, t1.o_custkey AS t1__o_custkey, t2.s_phone AS t2__s_phone, t1.o_shippriority AS t1__o_shippriority, MIN(t2.l_discount) AS MIN__t2__l_discount, MAX(t2.s_suppkey) AS MAX__t2__s_suppkey, MAX(t1.o_orderkey) AS MAX__t1__o_orderkey, MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160, MAX(SQRT(t1.l_suppkey)) AS MAX__SQRT__t1__l_suppkey FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber  WHERE  t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)  GROUP BY   SUBSTR(t2.s_comment, 15, 187) , t1.o_orderdate , t1.o_custkey , t2.s_phone , t1.o_shippriority  HAVING   MAX(SQRT(t1.l_suppkey)) >=  2233.79721550547   and MAX(SUBSTR(t2.ps_comment, 15, 160)) not in (  (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.l_returnflag <=  'R'  AND SQRT(t2.ps_availqty)  BETWEEN  1 AND 1  AND t2.s_comment LIKE  '%%'  OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.l_partkey IN  ( 3020979, 6853943, 49481433, 68145570, 70389193, 80863567, 85007880)   OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.l_discount <  0.04  AND t2.ps_partkey IN  ( 28019001, 35636285, 39444694, 43253413, 47062569, 47062570, 79923314, 79923317, 79923319, 91349214, 91349221, 95157461)   OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.l_shipinstruct BETWEEN  'DELIVER IN PERSON        ' AND 'DELIVER IN PERSON        '  OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.s_comment IN  ( ' packages. special instructions across the final, regular asymptotes affix re', ' use carefully quickly bold packages. permanent realms hag', '-ray slyly around the final, final theodolites. sl', '. furiously sly theodolites sleep', '. special theodolites use carefully above the ironic grouches. blithely unusual packages d', 'ans. stealthily slow account', 'c pinto beans use carefully quick accounts. deposits nag blithely ', 'e blithely even accounts lose car', 'e the slyly special foxes cajole carefully among the slyly even theodolites. deposits sleep furious', 'es. theodolites sleep blithely regular theodolites. packages according to the carefully', 'fully unusual pinto beans aff', 'ke. special, ironic excuses engage carefully furiously regular co', 'l ideas cajole furiously carefully unusual deposits. quickly even deposits against th', 'lly against the asymptotes. furiously pending accounts among the even, u', 'ly final foxes. special reques', 'ly ironic foxes print carefully regular asymptotes. ', 'posits haggle blithely sly accounts. pending, busy requests haggle carefully along the special i', 'sly express packages. ironic deposits cajole carefully silent foxes? carefully silent platelets abo', 'sts integrate carefully against the furiously regular packages. stealthy, ironic pattern', 'the bold accounts! ironic reques', 'theodolites cajole blithely around the quickly ironic packages. furiou', 'totes. quickly final theodolites a', 'ular foxes cajole. furiou', 'y bold epitaphs boost slyly? slyly final ideas haggle. quickly unusual requests nag quickly accord', 'ys bold accounts. foxes cajole quickly bold deposits. furiously pending packages wake')   OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE EXTRACT (YEAR FROM t1.l_commitdate)  =  1996  OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE SQRT(t1.l_partkey)  =  7684.57227176633  OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.l_returnflag <=  'R'  OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.l_suppkey <>  2160957  AND t1.o_shippriority <>  0  AND t2.l_returnflag >=  'R'  OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.l_receiptdate >  DATE'1998-07-29'  OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.o_comment LIKE  'furi%'  OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.o_orderdate <  DATE'1993-08-08'  AND t2.s_comment <  ' slyly. carefully final attai'  AND t2.l_commitdate IN  ( DATE'1992-11-14', DATE'1993-06-09', DATE'1994-03-15', DATE'1996-03-22', DATE'1996-07-29')   OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.l_returnflag IN  ( 'A', 'A', 'A', 'A', 'N', 'N', 'N', 'N', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R')   OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t2.s_suppkey <>  4122548  AND t1.o_shippriority =  0  OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   ) ,   (  SELECT  MAX(SUBSTR(t2.ps_comment, 15, 160)) AS MAX__SUBSTR__t2__ps_comment__15__160  FROM  (SELECT * FROM  lineitem lineitem1 RIGHT JOIN orders orders1 ON lineitem1.l_orderkey = orders1.o_orderkey ) t1 INNER JOIN (SELECT * FROM  lineitem lineitem2 INNER JOIN partsupp partsupp2 ON lineitem2.l_suppkey = partsupp2.ps_suppkey AND lineitem2.l_partkey = partsupp2.ps_partkey RIGHT JOIN supplier supplier2 ON partsupp2.ps_suppkey = supplier2.s_suppkey ) t2 ON t1.l_orderkey = t2.l_orderkey AND t1.l_linenumber = t2.l_linenumber   WHERE t1.o_shippriority <>  0  AND t2.ps_supplycost BETWEEN  188.26 AND 664.96  OR t1.o_orderstatus <=  'P'  OR t2.s_name <=  'Supplier#003493457       '  OR t1.o_totalprice =  23350.89  OR t2.ps_comment NOT BETWEEN  'about the regular, silent deposits run according to the pending deposits. slyly bold packages around the carefully regular accounts maintain slyly against the furiously even deposits. quickly iron' AND 'into beans. asymptotes about the even requests haggle special ideas. blithely regular requests nag slyly i'  OR EXTRACT (YEAR FROM t2.l_receiptdate)  NOT BETWEEN  1993 AND 1994  OR t2.s_acctbal NOT IN  ( -86.95, 1604.04, 1889.12, 2378.29, 2732.66, 2777.5, 3182.5, 3371.88, 3895.75, 4405.81, 5021.73, 6359.8, 7131.52, 7362.53, 8085.53, 9017.29, 9463.7)   OR FLOOR(t1.l_tax)  NOT IN  ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)   )  ) ORDER BY  10 DESC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
