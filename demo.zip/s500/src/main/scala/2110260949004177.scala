

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2110260949004177 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s500/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q170")
spark.sparkContext.setLocalProperty("callSite.long", "Query2110260949004177") 
val results = spark.sql ("SELECT  LTRIM(nation.n_name) AS LTRIM__nation__n_name, MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey GROUP BY   LTRIM(nation.n_name)  HAVING   MIN(RTRIM(orders.o_clerk)) not in (  (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_orderstatus <>  'O'  AND customer.c_nationkey =  0  ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_acctbal IN  ( -983.11, -489.73, -194.35, 154.55, 688.82, 722.95, 1148.76, 1491.67, 2246.38, 2439.03, 2644.58, 2851.69, 3885.17, 4312, 5220.77, 5551.16, 5848.88, 6068.05, 6368.97, 7444.79, 7521.55, 8353.01, 9039.12)   ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_comment <  ' furiously regular instructions. dolphins print enti'  AND nation.n_name <  'CANADA                   '  AND orders.o_orderstatus <>  'O'  ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_comment >  ' the final accounts. pending, express accounts promise quickly according to the regular deposi'  AND orders.o_totalprice >=  62586.91  AND SQRT(orders.o_shippriority)  NOT BETWEEN  0 AND 0  ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE LOG(3, customer.c_custkey)  <=  16.9113610251863  AND orders.o_orderdate NOT IN  ( DATE'1992-05-16', DATE'1992-07-06', DATE'1992-07-18', DATE'1993-08-09', DATE'1994-05-17', DATE'1995-02-14', DATE'1995-11-23', DATE'1997-09-28', DATE'1998-04-03')   ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_orderpriority NOT LIKE  '%LOW          '  ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_orderpriority <  '2-HIGH         '  AND customer.c_nationkey >  0  AND LOG(6, orders.o_totalprice)  IN  ( 8.71262674240094, 10.6991692092633, 11.3195905633239, 11.4916050924813, 11.5402809679432, 11.8939184928356, 12.0662816452328, 12.1568757836704, 12.2724520181355, 12.3003618042698, 12.4447525600934, 12.6759591429162, 12.819142019884)   ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_totalprice <  11474.15  AND customer.c_mktsegment <>  'AUTOMOBILE'  AND orders.o_custkey >  15440306  ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_mktsegment >=  'FURNITURE '  AND orders.o_orderkey BETWEEN  782377696 AND 1073977604  AND orders.o_custkey NOT IN  ( 16773095, 19129717, 26656634, 30593591, 34608628, 38634751, 43436360, 58680356, 59114095, 63892474, 69958672)   ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_phone <  '10-797-942-8151'  ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_orderdate =  DATE'1996-07-11'  ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_clerk NOT LIKE  'Clerk#0%'  ) ,   (  SELECT  MIN(RTRIM(orders.o_clerk)) AS MIN__RTRIM__orders__o_clerk  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_comment NOT IN  ( ' among the quickly regular foxes. permanent acco', ' the final accounts. pending, express accounts promise quickly according to the regular deposi', 'e according to the deposits: evenly silent accounts cajole along the even, regular accounts. silent instruction', 'eas. carefully unusual excuses sleep. slyly special packages affix furiously against the blithely regular ', 'endencies. special, pending theodolites according to the foxes hang blithely across the ironic ', 'eodolites across the final orbits detect slyly excuses. quickly even asymptotes are quick', 'express courts. furiously even packages sleep. ironic asymptot', 'o haggle instead of the express deposits. ironic ideas about the carefull', 's carefully even deposits-- even theodolites haggle c', 't blithely ironic packages. furiously bold deposits use furiously. carefully even theodolites slee')   )  ) ORDER BY  1 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
