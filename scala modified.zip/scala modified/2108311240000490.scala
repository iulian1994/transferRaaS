

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2108311240000490 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q17")
spark.sparkContext.setLocalProperty("callSite.long", "Query2108311240000490") 
val results = spark.sql ("SELECT  nation.n_regionkey AS nation__n_regionkey, LTRIM(customer.c_phone) AS LTRIM__customer__c_phone, MIN(nation.n_comment) AS MIN__nation__n_comment, MIN(RTRIM(customer.c_mktsegment)) AS MIN__RTRIM__customer__c_mktsegment FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey WHERE  customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_regionkey BETWEEN  3 AND 4 GROUP BY  nation.n_regionkey ,  LTRIM(customer.c_phone)  HAVING   MIN(nation.n_comment) not in (  (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_regionkey BETWEEN  3 AND 4  AND nation.n_comment NOT IN  ( 'rns. blithely bold courts among the closely regular packages use furiously bold platelets?')   AND nation.n_name NOT IN  ( 'ALGERIA', 'ARGENTINA', 'BRAZIL', 'CANADA', 'EGYPT', 'ETHIOPIA', 'GERMANY', 'INDIA', 'INDONESIA', 'IRAN', 'IRAQ', 'JAPAN', 'JORDAN', 'KENYA', 'MOROCCO', 'MOZAMBIQUE', 'PERU', 'ROMANIA', 'RUSSIA', 'SAUDI ARABIA', 'UNITED KINGDOM', 'UNITED STATES', 'VIETNAM')   ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND customer.c_mktsegment =  'AUTOMOBILE'  AND nation.n_nationkey =  12  AND nation.n_regionkey BETWEEN  3 AND 4  AND customer.c_name LIKE  '%Customer#012271760%'  AND nation.n_comment LIKE  '%gle slyly. carefully %'  ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_regionkey BETWEEN  3 AND 4  AND customer.c_nationkey IN  ( 1, 7, 14, 16, 20)   AND customer.c_comment NOT BETWEEN  'ctions sleep furiously along the foxes. blithely quiet dolphins are caref' AND 'sits. furiously regular packages affix carefully. carefully unusual tithes cajole furiously; ironic, pending'  ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_name >=  'ETHIOPIA'  AND nation.n_regionkey BETWEEN  3 AND 4  ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_name <>  'Customer#012275397'  AND customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_name BETWEEN  'BRAZIL' AND 'IRAQ'  AND nation.n_regionkey BETWEEN  3 AND 4  AND customer.c_custkey NOT IN  ( 12271128, 12271131, 12271277, 12271434, 12272448, 12272604, 12272812, 12272831, 12273398, 12273531, 12273710, 12273972, 12273977, 12274018, 12274404, 12274457, 12274494, 12274618, 12274809, 12275448, 12275472, 12275538)   ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND customer.c_nationkey BETWEEN  5 AND 8  AND nation.n_regionkey BETWEEN  3 AND 4  AND nation.n_name NOT LIKE  '%I AR%'  ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_nationkey <>  8  AND customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_regionkey BETWEEN  3 AND 4  AND customer.c_phone NOT IN  ( '13-295-601-6418', '16-999-168-3116', '17-103-591-4760', '19-335-657-2621', '19-572-214-8950', '19-835-745-3682', '19-853-258-7851', '20-668-996-4480', '20-957-239-4181', '21-677-685-5121', '22-230-737-9487', '23-541-648-2521', '24-320-916-1282', '24-709-641-6598', '26-787-402-1884', '28-969-261-5591', '29-183-116-1477', '32-465-865-5946', '33-482-221-9653')   AND customer.c_name NOT LIKE  '%879'  ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_comment <  'ts. daringly quiet foxes eat above the ironic realms. daringly ironic r'  AND customer.c_name <=  'Customer#012272122'  AND customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_regionkey BETWEEN  3 AND 4  AND nation.n_name LIKE  '%LGERI%'  ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_comment <  'theodolites are carefully. regular, express asymptotes sublate furiously about the carefully regular instructions.'  AND customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND customer.c_mktsegment BETWEEN  'BUILDING' AND 'FURNITURE'  AND nation.n_regionkey BETWEEN  3 AND 4  AND customer.c_phone NOT BETWEEN  '21-895-932-5424' AND '33-450-885-7508'  ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND customer.c_comment >  'ove the carefully final packages. r'  AND customer.c_nationkey >=  22  AND nation.n_regionkey BETWEEN  3 AND 4  AND customer.c_mktsegment NOT BETWEEN  'AUTOMOBILE' AND 'BUILDING'  ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_nationkey <  2  AND customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND customer.c_mktsegment >  'FURNITURE'  AND nation.n_regionkey BETWEEN  3 AND 4  AND customer.c_acctbal IN  ( -799.71, 2149.45, 6264.1, 6497.18, 9924.39)   ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_regionkey BETWEEN  3 AND 4  AND customer.c_acctbal NOT IN  ( 4444.88, 5557.22)   ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_custkey <  12271626  AND customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_regionkey BETWEEN  3 AND 4  ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_acctbal <=  853.16  AND customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_regionkey BETWEEN  3 AND 4  AND customer.c_name NOT BETWEEN  'Customer#012273194' AND 'Customer#012275362'  ) ,   (  SELECT  MIN(nation.n_comment) AS MIN__nation__n_comment  FROM  customer INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_phone <  '11-376-184-1549'  AND customer.c_address =  'RDhvTdFVgtnMts5UmbeRoWA85Sy9wjfZvFvw'  AND nation.n_nationkey =  12  AND nation.n_regionkey BETWEEN  3 AND 4  AND BROUND(customer.c_acctbal, 2)  IN  ( -679.92, 776.99, 1720.14, 4914.89, 5593.49, 6379.33, 7293.32, 7987.76, 8940.37, 8992.58)   )  )")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
