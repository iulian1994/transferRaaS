

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2108311240000673 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q24")
spark.sparkContext.setLocalProperty("callSite.long", "Query2108311240000673") 
val results = spark.sql ("SELECT  nation.n_regionkey AS nation__n_regionkey, MAX(SQRT(customer.c_nationkey)) AS MAX__SQRT__customer__c_nationkey, MAX(nation.n_name) AS MAX__nation__n_name, MAX(SUBSTR(customer.c_mktsegment, 5, 4)) AS MAX__SUBSTR__customer__c_mktsegment__5__4, MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey WHERE  orders.o_orderdate >  DATE'1998-06-03' GROUP BY  nation.n_regionkey  HAVING   MAX(SUBSTR(customer.c_mktsegment, 5, 4)) between  'EHOL' AND 'ITUR'   or MAX(SQRT(customer.c_nationkey)) not between  1.4142135623731 AND 4   and MAX(LOWER(customer.c_name)) in (  (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE FLOOR(customer.c_acctbal)  <  5162  AND orders.o_clerk <>  'Clerk#000790663'  AND orders.o_orderdate >  DATE'1998-06-03'  ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_comment =  'ans promise around the ironic, express deposits. r'  AND orders.o_orderdate >  DATE'1998-06-03'  AND nation.n_comment IN  ( 'c dependencies. furiously express notornis sleep slyly regular accounts. ideas sleep. depos', 'eans boost carefully special requests. accounts are. carefull', 'eas hang ironic, silent packages. slyly regular packages are furiously over the tithes. fluffily bold', 'efully alongside of the slyly final dependencies.', 'haggle. carefully final deposits detect slyly agai', 'hely enticingly express accounts. even, final', 'ic deposits are blithely about the carefully regular pa', 'l platelets. regular accounts x-ray: unusual, regular acco', 'nic deposits boost atop the quickly final requests? quickly regula', 'ously. final, express gifts cajole a', 'pending excuses haggle furiously deposits. pending, express pinto beans wake fluffily past t', 'platelets. blithely pending dependencies use fluffily across the even pinto beans. carefully silent accoun', 'refully final requests. regular, ironi', 'requests against the platelets use never according to the quickly regular pint', 'rns. blithely bold courts among the closely regular packages use furiously bold platelets?', 's. ironic, unusual asymptotes wake blithely r', 'ss excuses cajole slyly across the packages. deposits print aroun', 'ts. silent requests haggle. closely express packages sleep across the blithely', 'ular asymptotes are about the furious multipliers. express dependencies nag above the ironically ironic account', 'ven packages wake quickly. regu', 'y above the carefully unusual theodolites. final dugouts are quickly across the furiously regular d', 'y final packages. slow foxes cajole quickly. quickly silent platelets breach ironic accounts. unusual pinto be')   AND ABS(orders.o_totalprice)  IN  ( 217444.34, 291379.64)   ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_comment =  'fully quickly ironic requests. pending requests sleep above the slyly ev'  AND customer.c_comment >  'gular requests after the unusual, final pinto beans nag across the carefully regular package'  AND orders.o_orderdate >  DATE'1998-06-03'  AND customer.c_nationkey >=  11  ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_orderdate >  DATE'1998-06-03'  AND orders.o_shippriority >=  0  ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_orderdate >  DATE'1998-06-03'  AND customer.c_address BETWEEN  'lFyCXSEp,OUh,EedCKDPkHtKSYzt' AND 'RgGlj,Qgkx9MdjgD'  AND orders.o_comment BETWEEN  'bove the bold packages; slyly ironic pack' AND 'deposits believe careful'  ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_phone =  '15-310-834-1083'  AND orders.o_orderdate >  DATE'1998-06-03'  AND nation.n_nationkey NOT IN  ( 0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 16, 17, 18, 19, 21, 22, 23, 24)   AND orders.o_clerk NOT IN  ( 'Clerk#000058440', 'Clerk#000071247', 'Clerk#000547126', 'Clerk#000857415', 'Clerk#000940954', 'Clerk#001242975', 'Clerk#001705088', 'Clerk#002031962', 'Clerk#002513656', 'Clerk#002713540', 'Clerk#002801195', 'Clerk#002848463')   ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_custkey <>  258372770  AND orders.o_orderdate >  DATE'1998-06-03'  ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_clerk =  'Clerk#002668542'  AND orders.o_orderdate >  DATE'1998-06-03'  AND orders.o_shippriority >=  0  ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE nation.n_name <=  'VIETNAM'  AND orders.o_orderdate >  DATE'1998-06-03'  AND orders.o_comment IN  ( '. daringly final deposits integrate quickly. quickly blithe pac', 'according to the furiously final requests. close dolphins nag', 'cajole fluffily furiously unusual accounts. quickly express pint', 'cajole quickly about the blithely final de', 'equests. furiously unusual sheaves boost about the', 'final theodolites cajole carefully slyly express deposits; pending asymptot', 'nag along the furiously special instructions. furiously ruthless deposi', 'ording to the furiously expre', 'packages against the doggedly ironic requests wake around the platelets. qui', 'packages against the special accounts are even requests. enticingly b', 'pinto beans sleep slyly final courts. carefu', 't the foxes nag final instructions. blithely final instructi')   AND customer.c_nationkey NOT IN  ( 0, 1, 2, 5, 6, 7, 9, 10, 13, 15, 16, 17, 19, 20, 21, 22, 23, 24)   ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_comment <>  'e carefully ironic braids. regular'  AND orders.o_orderdate >  DATE'1998-06-03'  AND customer.c_custkey BETWEEN  12272073 AND 12275745  AND orders.o_custkey NOT IN  ( 61295074, 61915564, 100995478, 116991667, 187490009, 273518749, 281679169, 313894234, 334778473, 353595611, 362375473, 369557750, 401695859, 407683696, 423126745, 435703348)   ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_custkey <  12272831  AND customer.c_phone <>  '34-753-210-8232'  AND orders.o_orderdate >  DATE'1998-06-03'  AND orders.o_orderkey NOT BETWEEN  45104037 AND 45107074  ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE SQRT(nation.n_nationkey)  <>  3.16227766016838  AND orders.o_shippriority =  0  AND orders.o_orderdate >  DATE'1998-06-03'  AND customer.c_comment NOT IN  ( 'furiously regular packages. carefully regular accounts must have to sleep ir', 'lyly regular theodolites unwind carefully. quickly special deposits poach furiously--', 'slyly regular forges kindle furiously carefully final ideas. fluffily iro')   ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_phone =  '34-556-774-2430'  AND orders.o_orderdate >  DATE'1998-06-03'  AND nation.n_name BETWEEN  'INDIA' AND 'INDONESIA'  AND customer.c_custkey NOT IN  ( 12271014, 12271033, 12271131, 12271345, 12272394, 12272582, 12272831, 12272904, 12273350, 12274168, 12274243, 12274516, 12274709, 12274830, 12275368, 12275710, 12275881)   ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE customer.c_custkey <=  12272369  AND nation.n_name <>  'SAUDI ARABIA'  AND orders.o_orderdate >  DATE'1998-06-03'  AND SQRT(orders.o_totalprice)  IN  ( 138.241817117687, 193.425489530206, 207.392767472735, 219.559308616146, 225.891633311196, 262.087447238512, 276.122146884309, 291.951622704858, 386.278267574038, 392.89349701923, 393.088844919313, 396.481474977079, 399.383988161769, 429.518428009789, 471.418709853565, 516.582055437469, 538.401030831108)   ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_custkey >  126400624  AND orders.o_orderdate >  DATE'1998-06-03'  ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE nation.n_name <=  'ALGERIA'  AND orders.o_orderdate >  DATE'1998-06-03'  AND customer.c_comment NOT LIKE  'reque%'  ) ,   (  SELECT  MAX(LOWER(customer.c_name)) AS MAX__LOWER__customer__c_name  FROM  orders INNER JOIN customer ON orders.o_custkey = customer.c_custkey INNER JOIN nation ON customer.c_nationkey = nation.n_nationkey  WHERE orders.o_orderdate >  DATE'1998-06-03'  AND orders.o_orderkey IN  ( 45097830, 45098464, 45098823, 45098849, 45104646, 45105120, 45107079, 45107426, 45107975, 45108961, 45109506, 45110081, 45111298, 45111494, 45111586, 45113029, 45113602, 45113958, 45114247, 45114754, 45116866)   )  )  and MAX(nation.n_name) <  'VIETNAM'  ORDER BY  2 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
