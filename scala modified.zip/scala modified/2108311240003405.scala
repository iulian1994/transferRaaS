

 import org.apache.spark.sql.Row
 import org.apache.spark.sql.SparkSession
 import org.apache.spark.sql.types._

 object Query2108311240003405 {

 

  case class Customer(
                       c_custkey: Long,
                       c_name: String,
                       c_address: String,
                       c_nationkey: Long,
                       c_phone: String,
                       c_acctbal: Double,
                       c_mktsegment: String,
                       c_comment: String)

  case class Lineitem(
                       l_orderkey: Long,
                       l_partkey: Long,
                       l_suppkey: Long,
                       l_linenumber: Long,
                       l_quantity: Double,
                       l_extendedprice: Double,
                       l_discount: Double,
                       l_tax: Double,
                       l_returnflag: String,
                       l_linestatus: String,
                       l_shipdate: String,
                       l_commitdate: String,
                       l_receiptdate: String,
                       l_shipinstruct: String,
                       l_shipmode: String,
                       l_comment: String)

  case class Nation(
                     n_nationkey: Long,
                     n_name: String,
                     n_regionkey: Long,
                     n_comment: String)

  case class Order(
                    o_orderkey: Long,
                    o_custkey: Long,
                    o_orderstatus: String,
                    o_totalprice: Double,
                    o_orderdate: String,
                    o_orderpriority: String,
                    o_clerk: String,
                    o_shippriority: Long,
                    o_comment: String)

  case class Part(
                   p_partkey: Long,
                   p_name: String,
                   p_mfgr: String,
                   p_brand: String,
                   p_type: String,
                   p_size: Long,
                   p_container: String,
                   p_retailprice: Double,
                   p_comment: String)

  case class Partsupp(
                       ps_partkey: Long,
                       ps_suppkey: Long,
                       ps_availqty: Long,
                       ps_supplycost: Double,
                       ps_comment: String)

  case class Region(
                     r_regionkey: Long,
                     r_name: String,
                     r_comment: String)

  case class Supplier(
                       s_suppkey: Long,
                       s_name: String,
                       s_address: String,
                       s_nationkey: Long,
                       s_phone: String,
                       s_acctbal: Double,
                       s_comment: String)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Q x - Test")
      .master("spark://master:7077")
      .config("fs.defaultFS", "hdfs://master:9000")
      .config("spark.executor.memory","4G")
      .config("spark.driver.memory","4G")
      .config("spark.executor.cores","1")
      .config("spark.memory.offHeap.enabled","true")
      .config("spark.memory.offHeap.size","256M")
      .config("spark.driver.maxResultSize","20G")
      .config("spark.ui.retainedTasks","1000000")
      .getOrCreate()

    import spark.implicits._

    runBasicDataFrameExample(spark)

    spark.stop()
  }

 
                        
  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    import spark.implicits._
    //////////////////////////////////////////////////

    val dfMap = Map(
      "customer" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/customer.tbl").map(_.split( '|' )).map(p =>
        Customer(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim, p(7).trim)).toDF(),
      "lineitem" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/lineitem.tbl").map(_.split( '|' )).map(p =>
        Lineitem(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toLong, p(4).trim.toDouble, p(5).trim.toDouble, p(6).trim.toDouble, p(7).trim.toDouble, p(8).trim, p(9).trim, p(10).trim, p(11).trim, p(12).trim, p(13).trim, p(14).trim, p(15).trim)).toDF(),
      "nation" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/nation.tbl").map(_.split( '|' )).map(p =>
        Nation(p(0).trim.toLong, p(1).trim, p(2).trim.toLong, p(3).trim)).toDF(),
      "region" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/region.tbl").map(_.split( '|' )).map(p =>
        Region(p(0).trim.toLong, p(1).trim, p(2).trim)).toDF(),
      "order" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/orders.tbl").map(_.split( '|' )).map(p =>
        Order(p(0).trim.toLong, p(1).trim.toLong, p(2).trim, p(3).trim.toDouble, p(4).trim, p(5).trim, p(6).trim, p(7).trim.toLong, p(8).trim)).toDF(),
      "part" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/part.tbl").map(_.split( '|' )).map(p =>
        Part(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim, p(4).trim, p(5).trim.toLong, p(6).trim, p(7).trim.toDouble, p(8).trim)).toDF(),
      "partsupp" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/partsupp.tbl").map(_.split( '|' )).map(p =>
        Partsupp(p(0).trim.toLong, p(1).trim.toLong, p(2).trim.toLong, p(3).trim.toDouble, p(4).trim)).toDF(),
      "supplier" -> spark.sparkContext.textFile("hdfs://master:9000/user/ubuntu/s3000/supplier.tbl").map(_.split( '|' )).map(p =>
        Supplier(p(0).trim.toLong, p(1).trim, p(2).trim, p(3).trim.toLong, p(4).trim, p(5).trim.toDouble, p(6).trim)).toDF())

    val customer = dfMap.get("customer").get
    val lineitem = dfMap.get("lineitem").get
    val nation = dfMap.get("nation").get
    val region = dfMap.get("region").get
    val order = dfMap.get("order").get
    val part = dfMap.get("part").get
    val partsupp = dfMap.get("partsupp").get
    val supplier = dfMap.get("supplier").get

    dfMap.foreach {
      case (key, value) => value.createOrReplaceTempView(key)
    }

    customer.createOrReplaceTempView("customer")
    lineitem.createOrReplaceTempView("lineitem")
    region.createOrReplaceTempView("region")
    order.createOrReplaceTempView("orders")
    part.createOrReplaceTempView("part")
    partsupp.createOrReplaceTempView("partsupp")
    nation.createOrReplaceTempView("nation")
    supplier.createOrReplaceTempView("supplier")


spark.sparkContext.setLocalProperty("callSite.short", "Q140")
spark.sparkContext.setLocalProperty("callSite.long", "Query2108311240003405") 
val results = spark.sql ("SELECT  lineitem.l_suppkey AS lineitem__l_suppkey, lineitem.l_quantity AS lineitem__l_quantity, lineitem.l_orderkey AS lineitem__l_orderkey, COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13, COUNT(DISTINCT BROUND(lineitem.l_tax, 0)) AS COUNT__DISTINCT__BROUND__lineitem__l_tax__0 FROM  lineitem WHERE  lineitem.l_discount >  0.1  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR' GROUP BY  lineitem.l_suppkey , lineitem.l_quantity , lineitem.l_orderkey  HAVING   COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) in (  (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_returnflag =  'R'  AND lineitem.l_discount >  0.1  AND lineitem.l_linenumber IN  ( 4, 5)   AND lineitem.l_quantity NOT BETWEEN  20 AND 38  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_tax <=  0.08  AND lineitem.l_orderkey <>  68741730  AND lineitem.l_discount >  0.1  AND EXTRACT (DOW FROM lineitem.l_receiptdate)  NOT IN  ( 1, 1, 1, 1, 2, 2, 3, 3, 3, 3, 4, 5, 5, 7, 7, 7, 7, 7, 7)   OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_discount >  0.1  AND lineitem.l_orderkey >  68740289  AND ABS(lineitem.l_quantity)  >  41  AND lineitem.l_suppkey NOT BETWEEN  9852861 AND 21439365  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_discount >  0.1  AND lineitem.l_shipinstruct NOT LIKE  '%AKE BACK RETURN'  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_discount >  0.1  AND lineitem.l_extendedprice >  47395.2  AND lineitem.l_comment IN  ( 'arefully. carefully ironic requests wake.', 'around the carefully special', 'es. quickly unusual pinto beans', 'ial packages boost unusual, regular p', 'kages about the sly', 'refully re', 'sleep quickly ironically ir', 'the regular theodolites. always regular id', 'timents promise blithely furiously bu')   AND lineitem.l_returnflag IN  ( 'A', 'N', 'N', 'N', 'N', 'R', 'R', 'R', 'R', 'R')   OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_discount >  0.1  AND lineitem.l_shipinstruct BETWEEN  'COLLECT COD' AND 'TAKE BACK RETURN'  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_quantity <  32  AND lineitem.l_discount >  0.1  AND lineitem.l_linenumber NOT IN  ( 1, 1, 1, 2, 2, 2, 2, 3, 3, 5, 5, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7)   AND EXTRACT (MONTH FROM lineitem.l_commitdate)  NOT IN  ( 1, 2, 2, 2, 3, 3, 3, 5, 6, 6, 7, 7, 8, 9, 9, 11, 11, 11, 12, 12, 12)   OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_returnflag <>  'R'  AND lineitem.l_discount >  0.1  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_discount >  0.1  AND EXTRACT (MONTH FROM lineitem.l_commitdate)  NOT IN  ( 1, 3, 6, 7, 10, 11, 12)   OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_suppkey <>  1505758  AND lineitem.l_discount >  0.1  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_discount >  0.1  AND lineitem.l_extendedprice >  49097.7  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_discount >  0.1  AND lineitem.l_shipinstruct LIKE  '%ON'  AND lineitem.l_shipdate NOT BETWEEN  DATE'1995-09-20' AND DATE'1996-09-14'  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_shipinstruct <>  'COLLECT COD'  AND lineitem.l_discount >  0.1  AND lineitem.l_suppkey NOT IN  ( 5731053, 8258738, 15264278, 16481157, 18644665, 20939092, 23912112, 24607913, 24829740, 25171855, 25334380, 25384273, 28969770, 29593822, 29702698)   OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_returnflag =  'A'  AND lineitem.l_discount >  0.1  AND EXTRACT (DAY FROM lineitem.l_receiptdate)  >  26  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_commitdate >  DATE'1992-06-15'  AND lineitem.l_discount >  0.1  AND lineitem.l_comment >=  'fluffy foxes wake carefully. pi'  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_quantity <=  31  AND lineitem.l_discount >  0.1  AND lineitem.l_returnflag IN  ( 'A', 'A', 'A', 'N', 'R')   OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_shipinstruct <=  'TAKE BACK RETURN'  AND lineitem.l_discount >  0.1  AND lineitem.l_orderkey BETWEEN  68740355 AND 68741767  AND lineitem.l_commitdate IN  ( DATE'1992-05-23', DATE'1992-12-18', DATE'1993-01-20', DATE'1993-04-05', DATE'1994-08-27', DATE'1994-10-26', DATE'1995-05-06', DATE'1995-08-19', DATE'1995-11-01', DATE'1995-11-09', DATE'1995-11-27', DATE'1996-04-01', DATE'1996-05-27', DATE'1997-01-10', DATE'1997-05-29', DATE'1997-07-23', DATE'1997-12-24', DATE'1998-07-24')   OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_linenumber =  1  AND lineitem.l_discount >  0.1  AND lineitem.l_quantity NOT IN  ( 1, 6, 9, 21, 23, 24, 25, 27, 28, 31, 34, 38, 39, 41, 45, 46, 50)   OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE SQRT(lineitem.l_linenumber)  <>  2  AND lineitem.l_discount >  0.1  AND EXTRACT (YEAR FROM lineitem.l_receiptdate)  >  1994  AND EXTRACT (YEAR FROM lineitem.l_shipdate)  >  1996  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  ) ,   (  SELECT  COUNT(DISTINCT SUBSTR(lineitem.l_shipinstruct, 4, 13)) AS COUNT__DISTINCT__SUBSTR__lineitem__l_shipinstruct__4__13  FROM  lineitem  WHERE lineitem.l_discount >  0.1  AND lineitem.l_shipinstruct IN  ( 'COLLECT COD', 'COLLECT COD', 'NONE', 'NONE', 'NONE', 'TAKE BACK RETURN', 'TAKE BACK RETURN')   AND lineitem.l_comment NOT LIKE  '%e of the'  OR lineitem.l_linestatus <=  'O'  OR lineitem.l_partkey BETWEEN  78581238 AND 490934580  OR lineitem.l_shipmode NOT BETWEEN  'AIR' AND 'REG AIR'  )  ) ORDER BY  4 ASC")
spark.time(results.show())



 //////////////////////////////////////////////////
 
  }
}
  
